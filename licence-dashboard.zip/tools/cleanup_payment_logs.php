<?php
require_once __DIR__ . '/../config.php';

$months = get_payment_retention_months();
if ($months <= 0) {
    echo "Retention disabled; set a window via the admin dashboard before running this script.\n";
    exit(0);
}
$deleted = purge_payment_sync_logs($months);
record_payment_cleanup_run();
echo "Purged {$deleted} payment_sync records older than {$months} month" . ($months === 1 ? '' : 's') . ".\n";
