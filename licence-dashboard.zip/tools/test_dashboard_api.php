<?php
/**
 * Quick helper to exercise the licensing APIs.
 *
 * Usage: php tools/test_dashboard_api.php link_create <token>
 *        php tools/test_dashboard_api.php pay_renew <token>
 *        php tools/test_dashboard_api.php pay_upgrade <token> <plan_slug>
 *        php tools/test_dashboard_api.php payment_sync <token>
 */

$baseUrl = 'http://localhost/Control%20panel/Licance%20dashbord/api';
$cmd = $argv[1] ?? '';
$token = $argv[2] ?? '';

if (!$cmd || !$token) {
    echo "usage: php tools/test_dashboard_api.php <link_create|pay_renew|pay_upgrade|payment_sync> <token> [plan_slug]\n";
    exit(1);
}

function request(string $url, array $body = []): array {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    $out = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    return ['code' => $code, 'body' => json_decode($out ?: '', true)];
}

switch ($cmd) {
    case 'link_create':
        $payload = [
            'token' => $token,
            'title' => 'Sample Link',
            'amount' => 199.0,
            'description' => 'Test landing page',
            'purpose' => 'Testing',
            'fields' => ['name','email'],
        ];
        $resp = request("$baseUrl/link_create.php", $payload);
        break;
    case 'pay_renew':
        $resp = request("$baseUrl/pay_renew.php", ['token' => $token]);
        break;
    case 'pay_upgrade':
        $plan = $argv[3] ?? 'pro';
        $resp = request("$baseUrl/pay_upgrade.php", ['token' => $token, 'plan_slug' => $plan]);
        break;
    case 'payment_sync':
        $payload = [
            'token' => $token,
            'amount' => 199.0,
            'feature' => 'automations',
            'txn_id' => 'TEST-123',
            'payer_vpa' => 'payer@upi',
            'domain' => 'pay.example.com',
            'customer' => ['email' => 'sample@user.com', 'phone' => '9999999999'],
            'product' => 'Demo Link',
        ];
        $resp = request("$baseUrl/payment_sync.php", $payload);
        break;
    default:
        echo "unknown command\n";
        exit(1);
}

echo "HTTP {$resp['code']}\n";
print_r($resp['body']);
