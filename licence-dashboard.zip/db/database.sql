-- eGo Control Panel schema (expanded for license, domain and payment flows)

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(191) NOT NULL,
    email VARCHAR(191) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','customer') NOT NULL DEFAULT 'customer',
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE plans (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(64) NOT NULL UNIQUE,
    name VARCHAR(191) NOT NULL,
    description TEXT,
    billing_cycle ENUM('monthly','yearly') NOT NULL DEFAULT 'monthly',
    monthly_price DECIMAL(10,2) NOT NULL DEFAULT 0,
    annual_price DECIMAL(10,2) DEFAULT NULL,
    domain_limit INT UNSIGNED NOT NULL DEFAULT 1,
    landing_pages_limit INT UNSIGNED NOT NULL DEFAULT 3,
    payment_links_limit INT UNSIGNED NOT NULL DEFAULT 10,
    whitelist_domains_limit INT UNSIGNED NOT NULL DEFAULT 1,
    additional_domain_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    features JSON NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE subscriptions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    plan_id INT UNSIGNED NOT NULL,
    plan_slug VARCHAR(64) NOT NULL,
    license_key VARCHAR(64) NOT NULL UNIQUE,
    status ENUM('active','past_due','cancelled') NOT NULL DEFAULT 'active',
    auto_renew TINYINT(1) NOT NULL DEFAULT 1,
    valid_from DATETIME NOT NULL,
    valid_until DATETIME NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_subscription_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_subscription_plan FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE RESTRICT,
    INDEX ix_sub_plan (plan_slug),
    INDEX ix_sub_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE subscription_domains (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    subscription_id INT UNSIGNED NOT NULL,
    domain VARCHAR(255) NOT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    requested_at DATETIME NOT NULL,
    approved_at DATETIME NULL,
    admin_note VARCHAR(512) NULL,
    CONSTRAINT fk_domain_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE,
    UNIQUE KEY ux_subscription_domain (subscription_id, domain)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE payments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    subscription_id INT UNSIGNED NOT NULL,
    amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    currency VARCHAR(10) NOT NULL DEFAULT 'INR',
    provider VARCHAR(50) NOT NULL,
    provider_reference VARCHAR(191) NULL,
    type ENUM('initial','renewal') NOT NULL DEFAULT 'initial',
    status ENUM('pending','completed','failed') NOT NULL DEFAULT 'pending',
    metadata JSON NULL,
    executed_at DATETIME NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_payment_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE hosted_links (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    subscription_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    slug VARCHAR(64) NOT NULL UNIQUE,
    title VARCHAR(191) NOT NULL,
    description TEXT,
    amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    purpose VARCHAR(191) DEFAULT '',
    image_url VARCHAR(512) DEFAULT NULL,
    domain VARCHAR(255) DEFAULT NULL,
    payload JSON NULL,
    status ENUM('active','archived') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_link_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE,
    INDEX idx_subscription (subscription_id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE payment_sync_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    subscription_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    license_key VARCHAR(64) NOT NULL,
    source ENUM('app','plugin','dashboard') NOT NULL DEFAULT 'app',
    feature VARCHAR(64) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    txn_id VARCHAR(191) DEFAULT NULL,
    payer_vpa VARCHAR(191) DEFAULT NULL,
    customer_email VARCHAR(191) DEFAULT NULL,
    customer_phone VARCHAR(64) DEFAULT NULL,
    domain VARCHAR(255) DEFAULT NULL,
    product VARCHAR(191) DEFAULT NULL,
    metadata JSON NULL,
    recorded_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_payment_sync_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE payment_requests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    subscription_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    feature VARCHAR(64) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'INR',
    plan_slug VARCHAR(64) DEFAULT NULL,
    cycle ENUM('monthly','annual') DEFAULT 'monthly',
    callback_url VARCHAR(512) DEFAULT NULL,
    metadata JSON NULL,
    deeplink VARCHAR(1024) NOT NULL,
    state ENUM('pending','completed','failed') NOT NULL DEFAULT 'pending',
    txn_id VARCHAR(191) DEFAULT NULL,
    response_json JSON NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_payment_request_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE api_tokens (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    token VARCHAR(191) NOT NULL UNIQUE,
    scopes VARCHAR(191) NOT NULL DEFAULT 'wp_plugin,app',
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    last_used_at DATETIME NULL,
    CONSTRAINT fk_token_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE settings (
    setting_key VARCHAR(128) PRIMARY KEY,
    setting_value TEXT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed plans for quick start
INSERT INTO plans (slug, name, description, billing_cycle, monthly_price, annual_price, domain_limit, landing_pages_limit, payment_links_limit, whitelist_domains_limit, additional_domain_fee, features, created_at, updated_at)
VALUES
    ('basic', 'Basic', 'App & plugin access with one whitelisted domain and entry-level features.', 'monthly', 999.00, 9990.00, 1, 2, 5, 1, 0.00, '[\"app_access\",\"wp_gateway\"]', NOW(), NOW()),
    ('pro', 'Pro', 'Landing pages, links, custom domains, analytics, and automation for growing stores.', 'monthly', 1999.00, 19990.00, 3, 10, 25, 3, 199.00, '[\"app_access\",\"wp_gateway\",\"landing_builder\",\"custom_domain\",\"analytics\",\"automations\",\"api_tokens\"]', NOW(), NOW()),
    ('elite', 'Elite', 'Everything plus priority support and expanded limits for high-volume merchants.', 'monthly', 3999.00, 39990.00, 5, 25, 100, 5, 149.00, '[\"app_access\",\"wp_gateway\",\"landing_builder\",\"custom_domain\",\"analytics\",\"automations\",\"api_tokens\",\"priority_support\",\"manual_review\"]', NOW(), NOW());

-- NOTE: Import the schema, then create at least one admin user manually:
--   INSERT INTO users (name, email, password_hash, role, status, created_at, updated_at)
--   VALUES ('Admin', 'admin@example.com', '<password_hash>', 'admin', 'active', NOW(), NOW());
