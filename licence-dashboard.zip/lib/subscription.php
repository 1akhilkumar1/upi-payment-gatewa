<?php

function current_timestamp()
{
    return date('Y-m-d H:i:s');
}

function generate_license_key($length = 32)
{
    $bytes = ceil($length / 2);
    $sequence = bin2hex(random_bytes($bytes));
    return strtoupper(substr($sequence, 0, $length));
}

function decode_features($plan)
{
    if (empty($plan['features'])) {
        return [];
    }
    $decoded = json_decode($plan['features'], true);
    return is_array($decoded) ? $decoded : [];
}

function available_features()
{
    return [
        'wp_gateway' => 'WooCommerce Gateway',
        'domain_whitelisting' => 'Domain Whitelisting',
        'ego_gateway' => 'eGo Payment Gateway',
    ];
}

function feature_label($slug)
{
    $features = available_features();
    if (isset($features[$slug])) {
        return $features[$slug];
    }
    return str_replace('_', ' ', ucfirst($slug));
}

function sanitize_selected_features(array $features)
{
    $available = array_keys(available_features());
    return array_values(array_intersect($available, $features));
}

function list_plans($activeOnly = true)
{
    $sql = "SELECT * FROM plans";
    $params = [];
    if ($activeOnly) {
        $sql .= " WHERE is_active = 1";
    }
    $sql .= " ORDER BY monthly_price ASC";
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function create_plan($slug, $name, $description, $billingCycle, $monthlyPrice, $annualPrice, $domainLimit, $landingPagesLimit = 3, $paymentLinksLimit = 10, $whitelistDomainsLimit = 1, $additionalDomainFee = 0.00, array $features = [], $isActive = true)
{
    // Add default backend features
    $defaultFeatures = ['app_access', 'landing_builder', 'landing_page_builder', 'payment_link_builder', 'payment_page_builder', 'custom_domain', 'api_tokens', 'multi_installs', 'automations', 'analytics', 'priority_support'];
    $features = array_unique(array_merge($features, $defaultFeatures));
    $features = sanitize_selected_features($features);
    $json = json_encode(array_values($features));
    $now = current_timestamp();
    $stmt = db()->prepare("INSERT INTO plans (slug, name, description, billing_cycle, monthly_price, annual_price, domain_limit, landing_pages_limit, payment_links_limit, whitelist_domains_limit, additional_domain_fee, features, is_active, created_at, updated_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $slug,
        $name,
        $description,
        $billingCycle,
        $monthlyPrice,
        $annualPrice,
        $domainLimit,
        $landingPagesLimit,
        $paymentLinksLimit,
        $whitelistDomainsLimit,
        $additionalDomainFee,
        $json,
        $isActive ? 1 : 0,
        $now,
        $now,
    ]);
    return db()->lastInsertId();
}

function update_plan($planId, $slug, $name, $description, $billingCycle, $monthlyPrice, $annualPrice, $domainLimit, $landingPagesLimit = 3, $paymentLinksLimit = 10, $whitelistDomainsLimit = 1, $additionalDomainFee = 0.00, array $features = [], $isActive = true)
{
    // Add default backend features
    $defaultFeatures = ['app_access', 'landing_builder', 'landing_page_builder', 'payment_link_builder', 'payment_page_builder', 'custom_domain', 'api_tokens', 'multi_installs', 'automations', 'analytics', 'priority_support'];
    $features = array_unique(array_merge($features, $defaultFeatures));
    $features = sanitize_selected_features($features);
    $json = json_encode(array_values($features));
    $now = current_timestamp();
    $stmt = db()->prepare("UPDATE plans SET slug = ?, name = ?, description = ?, billing_cycle = ?, monthly_price = ?, annual_price = ?, domain_limit = ?, landing_pages_limit = ?, payment_links_limit = ?, whitelist_domains_limit = ?, additional_domain_fee = ?, features = ?, is_active = ?, updated_at = ? WHERE id = ?");
    $stmt->execute([
        $slug,
        $name,
        $description,
        $billingCycle,
        $monthlyPrice,
        $annualPrice,
        $domainLimit,
        $landingPagesLimit,
        $paymentLinksLimit,
        $whitelistDomainsLimit,
        $additionalDomainFee,
        $json,
        $isActive ? 1 : 0,
        $now,
        $planId,
    ]);
    return $planId;
}

function delete_plan($planId)
{
    $stmt = db()->prepare("DELETE FROM plans WHERE id = ?");
    return $stmt->execute([$planId]);
}

function set_plan_active($planId, $isActive)
{
    $stmt = db()->prepare("UPDATE plans SET is_active = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$isActive ? 1 : 0, $planId]);
}

function get_plan_by_slug($slug)
{
    $stmt = db()->prepare("SELECT * FROM plans WHERE slug = ? LIMIT 1");
    $stmt->execute([$slug]);
    return $stmt->fetch();
}

function get_plan_by_id($planId)
{
    $stmt = db()->prepare("SELECT * FROM plans WHERE id = ? LIMIT 1");
    $stmt->execute([$planId]);
    return $stmt->fetch();
}

function plan_allows_feature($planSlug, $feature)
{
    $plan = get_plan_by_slug($planSlug);
    if (!$plan) {
        return false;
    }
    $features = decode_features($plan);
    return in_array($feature, $features, true);
}

function get_active_subscription_for_user($user_id)
{
    $stmt = db()->prepare("SELECT s.*, u.email AS user_email, u.name AS user_name,
                                  p.slug AS plan_slug, p.name AS plan_name, p.description AS plan_description,
                                  p.domain_limit, p.features, p.landing_pages_limit AS plan_landing_pages_limit,
                                  p.payment_links_limit AS plan_payment_links_limit,
                                  p.whitelist_domains_limit AS plan_whitelist_domains_limit,
                                  p.additional_domain_fee AS plan_additional_domain_fee,
                                  p.monthly_price AS plan_monthly_price, p.annual_price AS plan_annual_price
                             FROM subscriptions s
                           JOIN users u ON u.id = s.user_id
                           JOIN plans p ON p.id = s.plan_id
                           WHERE s.user_id = ? AND s.status = 'active'
                             AND (s.valid_until IS NULL OR s.valid_until >= NOW())
                           ORDER BY s.valid_until DESC LIMIT 1");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

function build_subscription_payload($subscription)
{
    if (!$subscription) {
        return null;
    }

    $features = decode_features($subscription);
    $approved = count_subscription_domains($subscription['id'], 'approved');
    $pending = count_subscription_domains($subscription['id'], 'pending');
    $domains = get_domains_for_subscription($subscription['id']);
    $usedLinks = count_hosted_links($subscription['id']);
    $planPaymentLinksLimit = intval($subscription['plan_payment_links_limit'] ?? $subscription['payment_links_limit'] ?? 0);
    $planLandingPagesLimit = intval($subscription['plan_landing_pages_limit'] ?? $subscription['landing_pages_limit'] ?? 0);
    $planWhitelistLimit = intval($subscription['plan_whitelist_domains_limit'] ?? $subscription['whitelist_domains_limit'] ?? 0);
    $quotas = [
        'payment_links_limit' => $planPaymentLinksLimit,
        'payment_links_used' => $usedLinks,
        'payment_links_remaining' => $planPaymentLinksLimit > 0 ? max(0, $planPaymentLinksLimit - $usedLinks) : -1,
        'landing_pages_limit' => $planLandingPagesLimit,
        'landing_pages_used' => $usedLinks,
        'landing_pages_remaining' => $planLandingPagesLimit > 0 ? max(0, $planLandingPagesLimit - $usedLinks) : -1,
        'whitelist_domains_limit' => $planWhitelistLimit,
        'whitelist_domains_used' => $approved,
        'whitelist_domains_remaining' => $planWhitelistLimit > 0 ? max(0, $planWhitelistLimit - $approved) : -1,
    ];

    return [
        'id' => $subscription['id'],
        'user_email' => $subscription['user_email'] ?? null,
        'user_name' => $subscription['user_name'] ?? null,
        'license_key' => $subscription['license_key'],
        'plan' => [
            'slug' => $subscription['plan_slug'],
            'name' => $subscription['plan_name'],
            'description' => $subscription['plan_description'],
            'domain_limit' => $subscription['domain_limit'],
            'landing_pages_limit' => $planLandingPagesLimit,
            'payment_links_limit' => $planPaymentLinksLimit,
            'whitelist_domains_limit' => $planWhitelistLimit,
            'additional_domain_fee' => $subscription['plan_additional_domain_fee'] ?? $subscription['additional_domain_fee'] ?? 0,
            'features' => $features,
            'pricing' => [
                'monthly' => $subscription['plan_monthly_price'] ?? null,
                'annual' => $subscription['plan_annual_price'] ?? null,
            ],
        ],
        'status' => $subscription['status'],
        'auto_renew' => (bool)$subscription['auto_renew'],
        'valid_from' => $subscription['valid_from'],
        'valid_until' => $subscription['valid_until'],
        'approved_domains_count' => $approved,
        'pending_domains_count' => $pending,
        'domains' => $domains,
        'usage' => [
            'hosted_links' => $usedLinks,
            'links' => $usedLinks,
            'landing_pages' => $usedLinks,
            'domains' => $approved,
        ],
        'used_links' => $usedLinks,
        'used_landing_pages' => $usedLinks,
        'quotas' => $quotas,
        'is_active' => subscription_is_active($subscription),
        'features' => $features,
    ];
}

function get_last_subscription_for_user($user_id)
{
    $stmt = db()->prepare("SELECT s.*, u.email AS user_email, u.name AS user_name,
                                  p.slug AS plan_slug, p.name AS plan_name, p.description AS plan_description,
                                  p.domain_limit, p.features, p.landing_pages_limit AS plan_landing_pages_limit,
                                  p.payment_links_limit AS plan_payment_links_limit,
                                  p.whitelist_domains_limit AS plan_whitelist_domains_limit,
                                  p.additional_domain_fee AS plan_additional_domain_fee,
                                  p.monthly_price AS plan_monthly_price, p.annual_price AS plan_annual_price
                           FROM subscriptions s
                           JOIN users u ON u.id = s.user_id
                           JOIN plans p ON p.id = s.plan_id
                           WHERE s.user_id = ?
                           ORDER BY s.created_at DESC LIMIT 1");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

function get_subscription_by_id($subscription_id)
{
    $stmt = db()->prepare("SELECT s.*, u.email AS user_email, u.name AS user_name,
                                  p.slug AS plan_slug, p.name AS plan_name, p.description AS plan_description,
                                  p.domain_limit, p.features, p.landing_pages_limit AS plan_landing_pages_limit,
                                  p.payment_links_limit AS plan_payment_links_limit,
                                  p.whitelist_domains_limit AS plan_whitelist_domains_limit,
                                  p.additional_domain_fee AS plan_additional_domain_fee,
                                  p.monthly_price AS plan_monthly_price, p.annual_price AS plan_annual_price
                           FROM subscriptions s
                           JOIN users u ON u.id = s.user_id
                           JOIN plans p ON p.id = s.plan_id
                           WHERE s.id = ? LIMIT 1");
    $stmt->execute([$subscription_id]);
    return $stmt->fetch();
}

function get_subscription_by_license($license_key)
{
    $stmt = db()->prepare("SELECT s.*, u.email AS user_email, u.name AS user_name,
                                  p.slug AS plan_slug, p.name AS plan_name, p.description AS plan_description,
                                  p.domain_limit, p.features, p.landing_pages_limit AS plan_landing_pages_limit,
                                  p.payment_links_limit AS plan_payment_links_limit,
                                  p.whitelist_domains_limit AS plan_whitelist_domains_limit,
                                  p.additional_domain_fee AS plan_additional_domain_fee,
                                  p.monthly_price AS plan_monthly_price, p.annual_price AS plan_annual_price
                           FROM subscriptions s
                           JOIN users u ON u.id = s.user_id
                           JOIN plans p ON p.id = s.plan_id
                           WHERE s.license_key = ? LIMIT 1");
    $stmt->execute([$license_key]);
    return $stmt->fetch();
}

function subscription_is_active($subscription)
{
    if (!$subscription) {
        return false;
    }
    if ($subscription['status'] !== 'active') {
        return false;
    }
    if (!empty($subscription['valid_until']) && $subscription['valid_until'] < current_timestamp()) {
        return false;
    }
    return true;
}

function list_subscriptions()
{
    $stmt = db()->query("SELECT s.*, u.email, u.name, p.name AS plan_name, p.slug AS plan_slug, p.description AS plan_description,
                                p.monthly_price AS plan_monthly_price, p.annual_price AS plan_annual_price,
                                p.domain_limit, p.landing_pages_limit, p.payment_links_limit, p.whitelist_domains_limit,
                                p.additional_domain_fee,
                                (SELECT COUNT(*) FROM subscription_domains sd WHERE sd.subscription_id = s.id AND sd.status = 'approved') AS approved_domains,
                                (SELECT COUNT(*) FROM subscription_domains sd WHERE sd.subscription_id = s.id AND sd.status = 'pending') AS pending_domains
                         FROM subscriptions s
                         JOIN users u ON u.id = s.user_id
                         JOIN plans p ON p.id = s.plan_id
                         ORDER BY s.created_at DESC");
    return $stmt->fetchAll();
}

function create_subscription($user_id, $plan_slug, $valid_until = null, $auto_renew = 1, $status = 'active')
{
    $plan = get_plan_by_slug($plan_slug);
    if (!$plan) {
        throw new InvalidArgumentException('Plan not found: ' . $plan_slug);
    }
    $licenseKey = generate_license_key(32);
    $now = current_timestamp();
    $stmt = db()->prepare("INSERT INTO subscriptions (user_id, plan_id, plan_slug, license_key, status, auto_renew, valid_from, valid_until, created_at, updated_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $user_id,
        $plan['id'],
        $plan['slug'],
        $licenseKey,
        $status,
        $auto_renew ? 1 : 0,
        $now,
        $valid_until,
        $now,
        $now,
    ]);
    $id = db()->lastInsertId();
    ensure_primary_domain_whitelisted($id, $user_id);
    return $id;
}

function update_subscription_status($id, $status)
{
    $stmt = db()->prepare("UPDATE subscriptions SET status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$status, $id]);
}

function set_subscription_validity($id, $valid_until, $status = 'active')
{
    $stmt = db()->prepare("UPDATE subscriptions SET valid_until = ?, status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$valid_until, $status, $id]);
    $domains = get_subscription_domains($id);
    licd_push_gateway_license_status($status, $domains);
}

function renew_subscription($subscription_id, $valid_until, $status = 'active')
{
    $stmt = db()->prepare("UPDATE subscriptions SET valid_until = ?, status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$valid_until, $status, $subscription_id]);
    $domains = get_subscription_domains($subscription_id);
    licd_push_gateway_license_status($status, $domains);
}

function set_subscription_status($id, $status)
{
    $stmt = db()->prepare("UPDATE subscriptions SET status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$status, $id]);
}

function ensure_subscription_from_request($req)
{
    $userId = $req['user_id'] ?? null;
    $planSlug = $req['plan_slug'] ?? null;
    $cycle = $req['cycle'] ?? 'monthly';
    if (!$userId || !$planSlug) {
        return null;
    }
    $plan = get_plan_by_slug($planSlug);
    if (!$plan) {
        return null;
    }
    $months = strtolower($cycle) === 'yearly' ? 12 : 1;
    $now = current_timestamp();
    $validUntil = date('Y-m-d H:i:s', strtotime("+{$months} month", strtotime($now)));
    $id = create_subscription($userId, $planSlug, $validUntil, 1, 'active');
    return $id;
}

function activate_subscription_from_payment($subscription_id, $cycle = 'monthly')
{
    $subscription = get_subscription_by_id($subscription_id);
    if (!$subscription) {
        return false;
    }
    $months = strtolower($cycle) === 'yearly' ? 12 : 1;
    $now = strtotime(current_timestamp());
    $currentValidity = !empty($subscription['valid_until']) ? strtotime($subscription['valid_until']) : $now;
    $base = max($currentValidity, $now);
    $newUntil = date('Y-m-d H:i:s', strtotime("+{$months} month", $base));
    $stmt = db()->prepare("UPDATE subscriptions SET status = 'active', valid_until = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$newUntil, $subscription_id]);
    $domains = get_subscription_domains($subscription_id);
    licd_push_gateway_license_status('active', $domains);
    if (function_exists('licd_send_mail')) {
        $planName = $subscription['plan_name'] ?? $subscription['plan_slug'] ?? 'Plan';
        $cycleLabel = strtolower($cycle) === 'yearly' ? 'Yearly' : 'Monthly';
        $body = '<p>Hi ' . esc_html($subscription['user_name'] ?? '') . ',</p>'
              . '<p>Your ' . esc_html($planName) . ' subscription is active.</p>'
              . '<p><strong>Cycle:</strong> ' . esc_html($cycleLabel) . '<br>'
              . '<strong>Valid until:</strong> ' . esc_html($newUntil) . '<br>'
              . '<strong>License key:</strong> ' . esc_html($subscription['license_key'] ?? '') . '</p>';
        licd_send_mail($subscription['user_email'], 'Subscription activated', $body);
    }
    if (function_exists('licd_log_event')) {
        licd_log_event('subscription_activated', 'Subscription activated', [
            'subscription_id' => $subscription_id,
            'plan' => $subscription['plan_slug'] ?? '',
            'cycle' => $cycle,
            'valid_until' => $newUntil,
        ]);
    }
    return true;
}

function update_subscription_details($id, $plan_slug, $valid_until = null, $auto_renew = 1, $status = 'active')
{
    $plan = get_plan_by_slug($plan_slug);
    if (!$plan) {
        throw new InvalidArgumentException('Plan not found: ' . $plan_slug);
    }
    $stmt = db()->prepare("UPDATE subscriptions SET plan_id = ?, plan_slug = ?, valid_until = ?, auto_renew = ?, status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([
        $plan['id'],
        $plan['slug'],
        $valid_until,
        $auto_renew ? 1 : 0,
        $status,
        $id,
    ]);
    $domains = get_subscription_domains($id);
    licd_push_gateway_license_status($status, $domains);
}

function delete_subscription($id)
{
    // Clean up child rows to avoid orphaned records in dashboards.
    $stmt = db()->prepare("DELETE FROM subscription_domains WHERE subscription_id = ?");
    $stmt->execute([$id]);
    $stmt = db()->prepare("DELETE FROM hosted_links WHERE subscription_id = ?");
    $stmt->execute([$id]);
    $stmt = db()->prepare("DELETE FROM payment_requests WHERE subscription_id = ?");
    $stmt->execute([$id]);
    $stmt = db()->prepare("DELETE FROM subscriptions WHERE id = ?");
    $stmt->execute([$id]);
}

function count_subscription_domains($subscription_id, $status = null)
{
    $sql = "SELECT COUNT(*) FROM subscription_domains WHERE subscription_id = ?";
    $params = [$subscription_id];
    if ($status) {
        $sql .= " AND status = ?";
        $params[] = $status;
    }
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function get_domains_for_subscription($subscription_id, $status = null)
{
    $sql = "SELECT * FROM subscription_domains WHERE subscription_id = ?";
    $params = [$subscription_id];
    if ($status) {
        $sql .= " AND status = ?";
        $params[] = $status;
    }
    $sql .= " ORDER BY requested_at DESC";
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function is_subscription_domain_allowed($subscription_id, $domain)
{
    $domain = normalize_domain($domain);
    if ($domain === '') {
        return false;
    }
    $stmt = db()->prepare("SELECT COUNT(*) FROM subscription_domains WHERE subscription_id = ? AND domain = ? AND status = 'approved'");
    $stmt->execute([$subscription_id, $domain]);
    return (int)$stmt->fetchColumn() > 0;
}

function request_domain_for_subscription($subscription_id, $domain, &$reason = null)
{
    $domain = normalize_domain($domain);
    if ($domain === '') {
        $reason = 'invalid_domain';
        return false;
    }

    $plan = get_subscription_plan($subscription_id);
    if ($plan && $plan['domain_limit'] > 0) {
        $approved = count_subscription_domains($subscription_id, 'approved');
        if ($approved >= $plan['domain_limit']) {
            $reason = 'domain_limit_reached';
            return false;
        }
    }

    $stmt = db()->prepare("INSERT INTO subscription_domains (subscription_id, domain, status, requested_at)
                           VALUES (?, ?, 'pending', NOW())
                           ON DUPLICATE KEY UPDATE status = 'pending', admin_note = NULL, approved_at = NULL, requested_at = NOW()");
    $stmt->execute([$subscription_id, $domain]);
    return true;
}

function update_domain_request($domain_id, $status, $admin_note = null)
{
    $allowed = ['pending', 'approved', 'rejected'];
    if (!in_array($status, $allowed, true)) {
        throw new InvalidArgumentException('Invalid domain status');
    }
    $approvedAt = $status === 'approved' ? current_timestamp() : null;
    $stmt = db()->prepare("UPDATE subscription_domains SET status = ?, admin_note = ?, approved_at = ? WHERE id = ?");
    $stmt->execute([$status, $admin_note, $approvedAt, $domain_id]);
}

function ensure_primary_domain_whitelisted($subscription_id, $user_id)
{
    try {
        $profile = get_user_profile($user_id);
    } catch (\Throwable $e) {
        return;
    }
    $domain = normalize_domain($profile['website_url'] ?? '');
    if ($domain === '') {
        return;
    }
    $stmt = db()->prepare("INSERT INTO subscription_domains (subscription_id, domain, status, requested_at, approved_at, admin_note)
                           VALUES (?, ?, 'approved', NOW(), NOW(), 'Primary domain')
                           ON DUPLICATE KEY UPDATE status = 'approved', approved_at = NOW(), admin_note = 'Primary domain'");
    $stmt->execute([$subscription_id, $domain]);
    if (function_exists('licd_log_event')) {
        licd_log_event('domain_primary', 'Primary domain whitelisted', [
            'subscription_id' => $subscription_id,
            'domain' => $domain,
        ]);
    }
}

function auto_approve_pending_domains($minutes = 5)
{
    $minutes = max(1, (int)$minutes);
    $stmt = db()->prepare("SELECT sd.*, s.plan_id, p.domain_limit
                           FROM subscription_domains sd
                           JOIN subscriptions s ON s.id = sd.subscription_id
                           JOIN plans p ON p.id = s.plan_id
                           WHERE sd.status = 'pending' AND sd.requested_at <= DATE_SUB(NOW(), INTERVAL ? MINUTE)
                           ORDER BY sd.requested_at ASC");
    $stmt->execute([$minutes]);
    $rows = $stmt->fetchAll();
    foreach ($rows as $row) {
        $limit = (int)($row['domain_limit'] ?? 0);
        if ($limit > 0) {
            $approved = count_subscription_domains($row['subscription_id'], 'approved');
            if ($approved >= $limit) {
                continue;
            }
        }
        $stmt2 = db()->prepare("UPDATE subscription_domains SET status = 'approved', approved_at = NOW(), admin_note = 'Auto-approved' WHERE id = ?");
        $stmt2->execute([$row['id']]);
        if (function_exists('licd_log_event')) {
            licd_log_event('domain_auto_approved', 'Domain auto-approved', [
                'subscription_id' => $row['subscription_id'],
                'domain' => $row['domain'],
            ]);
        }
    }
}

function list_pending_domain_requests()
{
    $stmt = db()->query("SELECT sd.*, s.license_key, s.plan_slug, u.email AS user_email
                         FROM subscription_domains sd
                         JOIN subscriptions s ON s.id = sd.subscription_id
                         JOIN users u ON u.id = s.user_id
                         WHERE sd.status = 'pending'
                         ORDER BY sd.requested_at DESC");
    return $stmt->fetchAll();
}

function get_subscription_plan($subscription_id)
{
    $stmt = db()->prepare("SELECT p.* FROM subscriptions s JOIN plans p ON p.id = s.plan_id WHERE s.id = ? LIMIT 1");
    $stmt->execute([$subscription_id]);
    return $stmt->fetch();
}

function create_payment_record($subscription_id, $amount, $provider, $status = 'pending', $type = 'initial', $metadata = null, $currency = 'INR', $provider_reference = null, $executed_at = null)
{
    $now = current_timestamp();
    $stmt = db()->prepare("INSERT INTO payments (subscription_id, amount, currency, provider, provider_reference, type, status, metadata, executed_at, created_at, updated_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $subscription_id,
        $amount,
        $currency,
        $provider,
        $provider_reference,
        $type,
        $status,
        $metadata ? json_encode($metadata) : null,
        $executed_at,
        $now,
        $now,
    ]);
    return db()->lastInsertId();
}

function get_subscription_payments($subscription_id)
{
    $stmt = db()->prepare("SELECT * FROM payments WHERE subscription_id = ? ORDER BY created_at DESC");
    $stmt->execute([$subscription_id]);
    return $stmt->fetchAll();
}

function count_hosted_links($subscription_id)
{
    $stmt = db()->prepare("SELECT COUNT(*) FROM hosted_links WHERE subscription_id = ? AND status = 'active'");
    $stmt->execute([$subscription_id]);
    return (int)$stmt->fetchColumn();
}

function upcoming_renewals($days = 2)
{
    $stmt = db()->prepare("SELECT s.id AS subscription_id, s.license_key, s.valid_until, s.status,
                                  u.id AS user_id, u.email, u.name,
                                  p.name AS plan_name, p.slug AS plan_slug
                           FROM subscriptions s
                           JOIN users u ON u.id = s.user_id
                           JOIN plans p ON p.id = s.plan_id
                           WHERE s.status = 'active' AND s.valid_until IS NOT NULL
                             AND s.valid_until <= DATE_ADD(NOW(), INTERVAL ? DAY)
                             AND s.valid_until >= NOW()
                           ORDER BY s.valid_until ASC");
    $stmt->execute([$days]);
    return $stmt->fetchAll();
}

function hosted_link_stats()
{
    $stmt = db()->query("SELECT p.name AS plan_name, p.slug AS plan_slug, p.payment_links_limit,
                                COUNT(h.id) AS used_links
                         FROM hosted_links h
                         JOIN subscriptions s ON s.id = h.subscription_id
                         JOIN plans p ON p.id = s.plan_id
                         WHERE h.status = 'active'
                         GROUP BY p.id
                         ORDER BY used_links DESC");
    return $stmt->fetchAll();
}

function recent_payment_syncs($limit = 10)
{
    $stmt = db()->prepare("SELECT l.*, s.plan_slug, u.email
                           FROM payment_sync_logs l
                           JOIN subscriptions s ON s.id = l.subscription_id
                           JOIN users u ON u.id = l.user_id
                           ORDER BY l.created_at DESC
                           LIMIT ?");
    $stmt->bindValue(1, (int)$limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function create_hosted_link($subscription_id, $user_id, $title, $description, $amount, $purpose, $image_url, $domain, array $fields = [], $slug_override = null)
{
    $slug = null;
    if ($slug_override) {
        $candidate = strtolower(preg_replace('/[^a-z0-9-]/', '', (string)$slug_override));
        if ($candidate !== '') {
            $slug = $candidate;
            $stmt = db()->prepare("SELECT COUNT(*) FROM hosted_links WHERE slug = ? LIMIT 1");
            $stmt->execute([$slug]);
            if ((int)$stmt->fetchColumn() > 0) {
                return null;
            }
        }
    }
    if (!$slug) {
        $slug = bin2hex(random_bytes(8));
    }
    $payload = json_encode([
        'fields' => $fields,
        'link_type' => $fields['link_type'] ?? null,
        'capture_fields' => $fields['capture_fields'] ?? [],
        'collect_payment' => $fields['collect_payment'] ?? false,
        'regular_price' => $fields['regular_price'] ?? null,
        'sale_price' => $fields['sale_price'] ?? null,
        'digital_file_url' => $fields['digital_file_url'] ?? null,
        'hero_image_url' => $fields['hero_image_url'] ?? null,
        'custom_url' => $fields['custom_url'] ?? null,
        'cta_text' => $fields['cta_text'] ?? null,
        'primary_url' => $fields['primary_url'] ?? null,
        'secondary_text' => $fields['secondary_text'] ?? null,
        'payment_amount' => $fields['payment_amount'] ?? null,
        'custom_slug' => $fields['custom_slug'] ?? null,
    ]);
    $now = current_timestamp();
    $stmt = db()->prepare("INSERT INTO hosted_links (subscription_id, user_id, slug, title, description, amount, purpose, image_url, domain, payload, created_at, updated_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $subscription_id,
        $user_id,
        $slug,
        $title,
        $description,
        $amount,
        $purpose,
        $image_url,
        $domain,
        $payload,
        $now,
        $now,
    ]);
    return db()->lastInsertId() ? $slug : null;
}

function update_hosted_link_payload($subscription_id, $slug, array $data)
{
    $stmt = db()->prepare("SELECT payload FROM hosted_links WHERE subscription_id = ? AND slug = ? LIMIT 1");
    $stmt->execute([$subscription_id, $slug]);
    $row = $stmt->fetch();
    if (!$row) {
        return false;
    }
    $current = [];
    if (!empty($row['payload'])) {
        $decoded = json_decode($row['payload'], true);
        if (is_array($decoded)) {
            $current = $decoded;
        }
    }
    $merged = array_merge($current, $data);
    $stmt = db()->prepare("UPDATE hosted_links SET payload = ?, updated_at = NOW() WHERE subscription_id = ? AND slug = ?");
    return $stmt->execute([json_encode($merged), $subscription_id, $slug]);
}

function mark_hosted_link_paid($subscription_id, $slug, $amount, $txn, $payer = null)
{
    $info = [
        'paid' => true,
        'paid_at' => current_timestamp(),
        'paid_amount' => (float)$amount,
        'txn_id' => $txn,
        'payer_vpa' => $payer,
    ];
    return update_hosted_link_payload($subscription_id, $slug, $info);
}

function record_payment_sync($subscription_id, $user_id, $license_key, $source, $feature, $amount, $txn_id, $payer_vpa, $metadata = null, $customer = [], $domain = null, $product = null)
{
    $now = current_timestamp();
    $meta = $metadata ? json_encode($metadata) : null;
    $stmt = db()->prepare("INSERT INTO payment_sync_logs (subscription_id, user_id, license_key, source, feature, amount, txn_id, payer_vpa, customer_email, customer_phone, domain, product, metadata, recorded_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $subscription_id,
        $user_id,
        $license_key,
        $source,
        $feature,
        $amount,
        $txn_id,
        $payer_vpa,
        $customer['email'] ?? null,
        $customer['phone'] ?? null,
        $domain,
        $product,
        $meta,
        $now,
    ]);
    return db()->lastInsertId();
}

function extend_subscription_validity($subscription_id, $months = 1)
{
    $subscription = get_subscription_by_id($subscription_id);
    if (!$subscription) {
        return false;
    }
    $now = strtotime(current_timestamp());
    $currentValidity = !empty($subscription['valid_until']) ? strtotime($subscription['valid_until']) : $now;
    $base = max($currentValidity, $now);
    $newUntil = date('Y-m-d H:i:s', strtotime("+{$months} month", $base));
    $stmt = db()->prepare("UPDATE subscriptions SET valid_until = ?, status = 'active', updated_at = NOW() WHERE id = ?");
    $stmt->execute([$newUntil, $subscription_id]);
    return true;
}

function purge_payment_sync_logs($months)
{
    $months = max(0, (int)$months);
    if ($months <= 0) {
        return 0;
    }
    $threshold = date('Y-m-d H:i:s', strtotime("-{$months} month"));
    $stmt = db()->prepare("DELETE FROM payment_sync_logs WHERE recorded_at < ?");
    $stmt->execute([$threshold]);
    return $stmt->rowCount();
}
