<?php

function redirect($path)
{
    $base = defined('LICD_PLUGIN_URL') ? rtrim(LICD_PLUGIN_URL, '/') . '/public' : (rtrim(BASE_URL, '/') . '/public');
    $url  = $base . '/' . ltrim($path, '/');
    header('Location: ' . $url);
    exit;
}

function is_post()
{
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

function e($value)
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function normalize_domain($value)
{
    $value = trim($value);
    $value = preg_replace('#^https?://#i', '', $value);
    $value = preg_replace('#/.*$#', '', $value);
    $value = strtolower($value);
    return $value;
}

function request_payload()
{
    static $payload;
    if ($payload === null) {
        $payload = [];
        $body = trim(file_get_contents('php://input') ?: '');
        if ($body !== '') {
            $decoded = json_decode($body, true);
            if (is_array($decoded)) {
                $payload = $decoded;
            }
        }
    }
    return $payload;
}

function request_param($key, $default = null)
{
    $payload = request_payload();
    if (array_key_exists($key, $payload)) {
        return $payload[$key];
    }
    if (isset($_REQUEST[$key])) {
        return $_REQUEST[$key];
    }
    return $default;
}

function request_param_trim($key, $default = '')
{
    $value = request_param($key, $default);
    return is_string($value) ? trim($value) : $value;
}

function request_param_int($key, $default = 0)
{
    return intval(request_param($key, $default));
}

function request_param_float($key, $default = 0.0)
{
    return floatval(request_param($key, $default));
}

function request_param_array($key, $default = [])
{
    $value = request_param($key, $default);
    if (is_array($value)) {
        return $value;
    }
    if (is_string($value)) {
        $decoded = json_decode($value, true);
        if (is_array($decoded)) {
            return $decoded;
        }
    }
    return $default;
}

function set_flash($key, $message)
{
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = [];
    }
    $_SESSION['flash_messages'][$key] = $message;
}

function pull_flash($key)
{
    if (empty($_SESSION['flash_messages'][$key])) {
        return null;
    }
    $value = $_SESSION['flash_messages'][$key];
    unset($_SESSION['flash_messages'][$key]);
    return $value;
}

function pull_all_flash()
{
    if (empty($_SESSION['flash_messages'])) {
        return [];
    }
    $messages = $_SESSION['flash_messages'];
    unset($_SESSION['flash_messages']);
    return $messages;
}

/**
 * Write an error entry to a local log file (logs/error.log) and PHP error_log.
 */
function licd_log_error($message, array $context = [])
{
    $baseDir = __DIR__ . '/..';
    $logDir  = $baseDir . '/logs';
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    $entry = [
        'time'    => gmdate('c'),
        'message' => $message,
    ];
    if (!empty($context)) {
        $entry['context'] = $context;
    }
    $line = json_encode($entry, JSON_UNESCAPED_SLASHES);
    @file_put_contents($logDir . '/error.log', $line . PHP_EOL, FILE_APPEND | LOCK_EX);
    error_log('[licd] ' . $message . (empty($context) ? '' : ' ' . json_encode($context)));
}

/**
 * Send an email via WordPress with basic HTML headers.
 */
function licd_mail_wrap($body)
{
    $brand = function_exists('get_payment_gateway_name') ? get_payment_gateway_name() : '';
    $brand = $brand !== '' ? $brand : (function_exists('get_bloginfo') ? get_bloginfo('name') : 'eGo');
    $logo = function_exists('get_payment_logo_url') ? get_payment_logo_url() : '';
    if ($logo === '' && defined('LICD_PLUGIN_URL')) {
        $logo = rtrim(LICD_PLUGIN_URL, '/') . '/public/assets/images/ego-logo.svg';
    }
    $header = '<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">';
    if ($logo !== '') {
        $header .= '<img src="' . esc_url($logo) . '" alt="' . esc_attr($brand) . '" style="height:32px;width:auto;border-radius:6px;">';
    }
    $header .= '<div><div style="font-size:16px;font-weight:700;color:#111;">' . esc_html($brand) . '</div>'
            . '<div style="font-size:12px;color:#6b7280;">Payments & Subscriptions</div></div></div>';
    return '<html><body style="font-family:Arial,sans-serif;font-size:14px;color:#111;margin:0;padding:16px;background:#f3f4f6;">
    <div style="max-width:640px;margin:0 auto;padding:20px;background:#ffffff;border:1px solid #e5e7eb;border-radius:10px;">
    ' . $header . '
    ' . $body . '
    <p style="margin-top:24px;color:#6b7280;font-size:12px;">Sent from ' . esc_html($brand) . '</p>
    </div></body></html>';
}

function licd_public_url($path)
{
    $path = ltrim($path, '/');
    if (defined('LICD_PLUGIN_URL')) {
        return rtrim(LICD_PLUGIN_URL, '/') . '/public/' . $path;
    }
    return rtrim(BASE_URL, '/') . '/public/' . $path;
}

function licd_log_file_path()
{
    $dir = defined('LICD_PLUGIN_DIR') ? rtrim(LICD_PLUGIN_DIR, '/\\') . '/logs' : __DIR__ . '/../logs';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    return rtrim($dir, '/\\') . '/app_comm.log';
}

function licd_log_event($type, $message, array $context = [])
{
    $entry = [
        'ts' => gmdate('Y-m-d H:i:s'),
        'type' => $type,
        'message' => $message,
        'context' => $context,
    ];
    $line = json_encode($entry, JSON_UNESCAPED_SLASHES);
    if ($line === false) {
        return;
    }
    @file_put_contents(licd_log_file_path(), $line . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function licd_read_logs($limit = 200)
{
    $path = licd_log_file_path();
    if (!is_file($path)) {
        return [];
    }
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$lines) {
        return [];
    }
    $lines = array_slice($lines, -1 * (int)$limit);
    $out = [];
    foreach ($lines as $line) {
        $row = json_decode($line, true);
        $out[] = is_array($row) ? $row : ['ts' => '', 'type' => 'raw', 'message' => $line, 'context' => []];
    }
    return array_reverse($out);
}

/**
 * Send an email via WordPress. Uses HTML content with a temporary content-type filter.
 */
function licd_send_mail($to, $subject, $body, $headers = [])
{
    $prev_filter = null;
    $filter = function() { return 'text/html'; };
    add_filter('wp_mail_content_type', $filter);
    $sent = wp_mail($to, $subject, licd_mail_wrap($body), $headers);
    remove_filter('wp_mail_content_type', $filter);
    return $sent;
}
