<?php

function get_setting($key, $default = null)
{
    $stmt = db()->prepare("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1");
    $stmt->execute([$key]);
    $row = $stmt->fetch();
    if (!$row) {
        return $default;
    }
    return $row['setting_value'];
}

function set_setting($key, $value)
{
    $stmt = db()->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
                           ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()");
    $stmt->execute([$key, $value]);
}

function get_payment_retention_months()
{
    return max(0, (int)get_setting('payment_retention_months', 0));
}

function set_payment_retention_months($months)
{
    $months = max(0, (int)$months);
    set_setting('payment_retention_months', (string)$months);
}

function record_payment_cleanup_run()
{
    set_setting('payment_cleanup_last_run', current_timestamp());
}

function get_last_payment_cleanup_run()
{
    return get_setting('payment_cleanup_last_run', null);
}

function get_payment_gateway_upi()
{
    return get_setting('payment_gateway_upi', 'ego.payments@okhdfc');
}

function set_payment_gateway_upi($upi)
{
    set_setting('payment_gateway_upi', trim($upi));
}

function get_payment_gateway_name()
{
    return get_setting('payment_gateway_name', 'eGo Payments');
}

function get_app_hmac_secret()
{
    $s = get_setting('app_hmac_secret', '');
    if ($s === '') {
        $s = bin2hex(random_bytes(16));
        set_setting('app_hmac_secret', $s);
    }
    return $s;
}

function set_app_hmac_secret($secret)
{
    set_setting('app_hmac_secret', trim($secret));
}

function get_android_allowed_packages()
{
    return get_setting('android_allowed_packages', '');
}

function set_android_allowed_packages($csv)
{
    set_setting('android_allowed_packages', trim($csv));
}

function get_payment_logo_url()
{
    return get_setting('payment_logo_url', '');
}

function set_payment_logo_url($url)
{
    set_setting('payment_logo_url', trim($url));
}

function set_payment_gateway_name($name)
{
    set_setting('payment_gateway_name', trim($name));
}

function get_fee_setting($key, $default = 0.0)
{
    return max(0.0, floatval(get_setting($key, $default)));
}

function set_fee_setting($key, $value)
{
    set_setting($key, (string)max(0.0, floatval($value)));
}

function get_extra_domain_fee()
{
    return get_fee_setting('extra_domain_fee', 99.0);
}

function set_extra_domain_fee($value)
{
    set_fee_setting('extra_domain_fee', $value);
}

function get_extra_link_fee()
{
    return get_fee_setting('extra_link_fee', 49.0);
}

function set_extra_link_fee($value)
{
    set_fee_setting('extra_link_fee', $value);
}

function get_upgrade_fee()
{
    return get_fee_setting('upgrade_fee', 0.0);
}

function set_upgrade_fee($value)
{
    set_fee_setting('upgrade_fee', $value);
}

function ensure_user_app_keys_table()
{
    $sql = "CREATE TABLE IF NOT EXISTS user_app_keys (
        user_id INT UNSIGNED PRIMARY KEY,
        key_id VARCHAR(64) NOT NULL,
        secret VARCHAR(128) NOT NULL,
        device VARCHAR(191) DEFAULT NULL,
        last_ping DATETIME DEFAULT NULL,
        save_logs TINYINT(1) DEFAULT 0,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        INDEX idx_key_id (key_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    db()->exec($sql);
}

function ensure_user_app_keys_columns()
{
    ensure_user_app_keys_table();
    try {
        $col = db()->query("SHOW COLUMNS FROM user_app_keys LIKE 'save_logs'")->fetch();
        if (!$col) {
            db()->exec("ALTER TABLE user_app_keys ADD COLUMN save_logs TINYINT(1) DEFAULT 0 AFTER last_ping");
        }
    } catch (\Throwable $e) {
        // ignore
    }
}

function update_user_app_save_logs($user_id, $enabled)
{
    ensure_user_app_keys_columns();
    $val = $enabled ? 1 : 0;
    $stmt = db()->prepare("UPDATE user_app_keys SET save_logs = ?, updated_at = NOW() WHERE user_id = ?");
    return $stmt->execute([$val, $user_id]);
}

function ensure_app_saved_logs_table()
{
    $sql = "CREATE TABLE IF NOT EXISTS app_saved_logs (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED DEFAULT NULL,
        context VARCHAR(64) DEFAULT NULL,
        payload_json LONGTEXT,
        created_at DATETIME NOT NULL,
        INDEX idx_user_created (user_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    db()->exec($sql);
}

function save_app_log($user_id, $context, $payload)
{
    ensure_app_saved_logs_table();
    $now = current_timestamp();
    $stmt = db()->prepare("INSERT INTO app_saved_logs (user_id, context, payload_json, created_at) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user_id ?: null, $context, is_string($payload) ? $payload : json_encode($payload), $now]);
    // Purge logs older than 12 hours for this user
    try {
        $threshold = date('Y-m-d H:i:s', strtotime('-12 hours'));
        if ($user_id) {
            $p = db()->prepare("DELETE FROM app_saved_logs WHERE user_id = ? AND created_at < ?");
            $p->execute([$user_id, $threshold]);
        } else {
            $p = db()->prepare("DELETE FROM app_saved_logs WHERE created_at < ?");
            $p->execute([$threshold]);
        }
    } catch (\Throwable $e) {
        // ignore
    }
}

function get_user_app_key($user_id)
{
    ensure_user_app_keys_table();
    $stmt = db()->prepare("SELECT * FROM user_app_keys WHERE user_id = ? LIMIT 1");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

function get_user_app_key_by_key_id($key_id)
{
    ensure_user_app_keys_table();
    $stmt = db()->prepare("SELECT * FROM user_app_keys WHERE key_id = ? LIMIT 1");
    $stmt->execute([$key_id]);
    return $stmt->fetch();
}

function ensure_user_app_key($user_id)
{
    $row = get_user_app_key($user_id);
    if ($row) {
        return $row;
    }
    $keyId = 'usr_' . $user_id . '_' . bin2hex(random_bytes(4));
    $secret = bin2hex(random_bytes(16));
    $now = current_timestamp();
    $stmt = db()->prepare("INSERT INTO user_app_keys (user_id, key_id, secret, created_at, updated_at) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $keyId, $secret, $now, $now]);
    return get_user_app_key($user_id);
}

function update_user_app_ping($user_id, $device)
{
    ensure_user_app_keys_table();
    $stmt = db()->prepare("UPDATE user_app_keys SET device = ?, last_ping = NOW(), updated_at = NOW() WHERE user_id = ?");
    $stmt->execute([$device, $user_id]);
}

function regenerate_user_app_key($user_id)
{
    ensure_user_app_keys_table();
    $keyId = 'usr_' . $user_id . '_' . bin2hex(random_bytes(4));
    $secret = bin2hex(random_bytes(16));
    $stmt = db()->prepare("UPDATE user_app_keys SET key_id = ?, secret = ?, device = NULL, last_ping = NULL, updated_at = NOW() WHERE user_id = ?");
    $stmt->execute([$keyId, $secret, $user_id]);
    return get_user_app_key($user_id);
}
