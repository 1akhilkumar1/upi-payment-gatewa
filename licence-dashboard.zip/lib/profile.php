<?php

function ensure_profile_table()
{
    $sql = "CREATE TABLE IF NOT EXISTS user_profiles (
        user_id INT UNSIGNED PRIMARY KEY,
        phone VARCHAR(32),
        country VARCHAR(128),
        username VARCHAR(128),
        trade_name VARCHAR(191),
        upi_name VARCHAR(191),
        upi_id VARCHAR(191),
        has_website TINYINT(1) DEFAULT 0,
        website_url VARCHAR(255),
        turnover_range VARCHAR(64),
        business_category VARCHAR(191),
        regions VARCHAR(191),
        about TEXT,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        CONSTRAINT fk_profile_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    db()->exec($sql);
    ensure_profile_columns();
}

function ensure_profile_columns()
{
    $columns = ['upi_name' => "ALTER TABLE user_profiles ADD COLUMN upi_name VARCHAR(191) NULL",
                'upi_id' => "ALTER TABLE user_profiles ADD COLUMN upi_id VARCHAR(191) NULL"];
    foreach ($columns as $name => $alter) {
        $stmt = db()->prepare("SHOW COLUMNS FROM user_profiles LIKE ?");
        $stmt->execute([$name]);
        if (!$stmt->fetch()) {
            db()->exec($alter);
        }
    }
}

function get_user_profile($user_id)
{
    ensure_profile_table();
    $stmt = db()->prepare("SELECT * FROM user_profiles WHERE user_id = ? LIMIT 1");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

function save_user_profile($user_id, array $data)
{
    ensure_profile_table();
    $now = current_timestamp();
    $fields = [
        'phone' => $data['phone'] ?? null,
        'country' => $data['country'] ?? null,
        'username' => $data['username'] ?? null,
        'trade_name' => $data['trade_name'] ?? null,
        'upi_name' => $data['upi_name'] ?? null,
        'upi_id' => $data['upi_id'] ?? null,
        'has_website' => !empty($data['has_website']) ? 1 : 0,
        'website_url' => $data['website_url'] ?? null,
        'turnover_range' => $data['turnover_range'] ?? null,
        'business_category' => $data['business_category'] ?? null,
        'regions' => $data['regions'] ?? null,
        'about' => $data['about'] ?? null,
    ];
    $sql = "INSERT INTO user_profiles (user_id, phone, country, username, trade_name, upi_name, upi_id, has_website, website_url, turnover_range, business_category, regions, about, created_at, updated_at)
            VALUES (:user_id, :phone, :country, :username, :trade_name, :upi_name, :upi_id, :has_website, :website_url, :turnover_range, :business_category, :regions, :about, :created_at, :updated_at)
            ON DUPLICATE KEY UPDATE
                phone = VALUES(phone),
                country = VALUES(country),
                username = VALUES(username),
                trade_name = VALUES(trade_name),
                upi_name = VALUES(upi_name),
                upi_id = VALUES(upi_id),
                has_website = VALUES(has_website),
                website_url = VALUES(website_url),
                turnover_range = VALUES(turnover_range),
                business_category = VALUES(business_category),
                regions = VALUES(regions),
                about = VALUES(about),
                updated_at = VALUES(updated_at)";
    $stmt = db()->prepare($sql);
    $stmt->execute([
        ':user_id' => $user_id,
        ':phone' => $fields['phone'],
        ':country' => $fields['country'],
        ':username' => $fields['username'],
        ':trade_name' => $fields['trade_name'],
        ':upi_name' => $fields['upi_name'],
        ':upi_id' => $fields['upi_id'],
        ':has_website' => $fields['has_website'],
        ':website_url' => $fields['website_url'],
        ':turnover_range' => $fields['turnover_range'],
        ':business_category' => $fields['business_category'],
        ':regions' => $fields['regions'],
        ':about' => $fields['about'],
        ':created_at' => $now,
        ':updated_at' => $now,
    ]);
}
