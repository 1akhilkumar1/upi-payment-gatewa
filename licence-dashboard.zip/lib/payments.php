<?php

function payment_gateway_upi_id()
{
    return get_payment_gateway_upi();
}

function payment_gateway_merchant_name()
{
    return get_payment_gateway_name();
}

function payment_gateway_currency()
{
    return get_setting('payment_gateway_currency', 'INR');
}

function generate_payment_deeplink($amount, $purpose, $note = '')
{
    $upiId = payment_gateway_upi_id();
    $merchant = payment_gateway_merchant_name();
    $params = [
        'pa' => $upiId,
        'pn' => $merchant,
        'am' => number_format((float)$amount, 2, '.', ''),
        'cu' => payment_gateway_currency(),
        'tn' => $note ?: $purpose,
    ];
    $query = http_build_query(array_filter($params), '', '&', PHP_QUERY_RFC3986);
    return 'upi://pay?' . $query;
}

function generate_payment_deeplink_with($amount, $purpose, $note, $upiId, $merchant)
{
    $params = [
        'pa' => $upiId,
        'pn' => $merchant,
        'am' => number_format((float)$amount, 2, '.', ''),
        'cu' => payment_gateway_currency(),
        'tn' => $note ?: $purpose,
    ];
    $query = http_build_query(array_filter($params), '', '&', PHP_QUERY_RFC3986);
    return 'upi://pay?' . $query;
}

function generate_public_checkout_token($paymentId, $userId)
{
    $secret = get_app_hmac_secret();
    if (empty($secret)) {
        return '';
    }
    return hash_hmac('sha256', $paymentId . '|' . $userId, $secret);
}

function verify_public_checkout_token($paymentId, $userId, $token)
{
    if (empty($token)) {
        return false;
    }
    $expected = generate_public_checkout_token($paymentId, $userId);
    if ($expected === '') {
        return false;
    }
    return hash_equals($expected, $token);
}

function payment_amount_candidates($raw)
{
    if ($raw === null || $raw === '' || is_bool($raw)) {
        return [];
    }
    $s = is_string($raw) ? trim($raw) : (string)$raw;
    $s = str_replace([',', ' '], '', $s);
    if ($s === '' || !is_numeric($s)) {
        return [];
    }
    $candidates = [];
    $rupees = round((float)$s, 2);
    if ($rupees > 0) {
        $candidates[] = $rupees;
    }
    if (strpos($s, '.') === false) {
        $paise = round(((float)$s) / 100, 2);
        if ($paise > 0) {
            $candidates[] = $paise;
        }
    }
    $candidates = array_values(array_unique($candidates));
    sort($candidates);
    return $candidates;
}

function pick_matching_amount($target, array $candidates, $tolerance = null)
{
    // Determine a sensible absolute tolerance when none provided.
    if ($tolerance === null || !is_numeric($tolerance) || $tolerance <= 0) {
        // Use 1% of the amount but clamp to the range [0.1, 0.5]
        $computed = round(max(0.0, (float)$target) * 0.01, 2);
        $tolerance = max(0.1, min(0.5, $computed));
    }

    $best = null;
    $bestDiff = null;
    foreach ($candidates as $cand) {
        $diff = abs((float)$target - (float)$cand);
        if ($diff <= (float)$tolerance && ($bestDiff === null || $diff < $bestDiff)) {
            $best = (float)$cand;
            $bestDiff = $diff;
        }
    }
    return $best;
}

function get_instant_discount_range()
{
    $min = floatval(get_setting('instant_discount_min', 0.25));
    $max = floatval(get_setting('instant_discount_max', 0.50));
    if ($min <= 0) { $min = 0.25; }
    if ($max <= 0) { $max = 0.50; }
    if ($max < $min) { $max = $min; }
    return ['min' => $min, 'max' => $max];
}

function generate_invoice_id($prefix = 'INV')
{
    return $prefix . '-' . strtoupper(dechex(time())) . '-' . strtoupper(substr(md5($prefix . microtime(true) . rand()), 0, 4));
}

function is_unique_payable_amount($amount)
{
    $amount = (float)$amount;
    // Use the same tolerance strategy as matching: 1% clamped to [0.1,0.5]
    $computed = round(max(0.0, $amount) * 0.01, 2);
    $tol = max(0.1, min(0.5, $computed));
    $window = intval(get_setting('payment_match_window_minutes', 60));
    $sql = "SELECT COUNT(*) FROM payment_requests WHERE created_at >= DATE_SUB(NOW(), INTERVAL $window MINUTE) AND ABS(amount - ?) <= ?";
    $stmt = db()->prepare($sql);
    $stmt->execute([$amount, $tol]);
    return (int)$stmt->fetchColumn() === 0;
}

function generate_instant_discount($baseAmount)
{
    $baseAmount = max(0, (float)$baseAmount);
    $range = get_instant_discount_range();
    $attempts = 0;
    $picked = null;
    do {
        $pct = mt_rand((int)round($range['min'] * 1000), (int)round($range['max'] * 1000)) / 1000;
        $discount = round(($baseAmount * $pct) / 100, 2);
        $payable = max(0, round($baseAmount - $discount, 2));
        $picked = ['percent' => $pct, 'amount' => $discount, 'payable' => $payable];
        $attempts++;
        if ($payable <= 0) {
            continue;
        }
    } while ($attempts < 8 && !is_unique_payable_amount($picked['payable']));
    return $picked;
}

function generate_instant_discount_for_feature($feature, $baseAmount)
{
    $baseAmount = max(0, (float)$baseAmount);
    $feature = strtolower(trim((string)$feature));
    if ($feature === 'link') {
        $min = 0.10;
        $max = 0.50;
        $attempts = 0;
        $picked = null;
        do {
            $pct = mt_rand((int)round($min * 1000), (int)round($max * 1000)) / 1000;
            $discount = round(($baseAmount * $pct) / 100, 2);
            $payable = max(0, round($baseAmount - $discount, 2));
            $picked = ['percent' => $pct, 'amount' => $discount, 'payable' => $payable];
            $attempts++;
            if ($payable <= 0) {
                continue;
            }
        } while ($attempts < 8 && !is_unique_payable_amount($picked['payable']));
        return $picked;
    }
    return generate_instant_discount($baseAmount);
}

function plan_price_for_cycle($plan, $cycle = 'monthly')
{
    $cycle = strtolower(trim($cycle));
    if ($cycle === 'yearly') {
        $cycle = 'annual';
    }
    if ($cycle === 'annual') {
        return isset($plan['pricing']['annual']) && $plan['pricing']['annual'] > 0 ? (float)$plan['pricing']['annual'] : (float)($plan['annual_price'] ?? 0);
    }
    return isset($plan['pricing']['monthly']) && $plan['pricing']['monthly'] > 0 ? (float)$plan['pricing']['monthly'] : (float)($plan['monthly_price'] ?? 0);
}

function calculate_upgrade_amount($currentPlan, $targetPlan, $cycle = 'monthly')
{
    $current = plan_price_for_cycle($currentPlan, $cycle);
    $target = plan_price_for_cycle($targetPlan, $cycle);
    return max(0.0, $target - $current);
}

function prorated_upgrade_amount($currentPlan, $targetPlan, $validUntil, $cycle = 'monthly')
{
    $target = plan_price_for_cycle($targetPlan, $cycle);
    $current = plan_price_for_cycle($currentPlan, $cycle);
    $credit = 0.0;
    if (!empty($validUntil)) {
        $expires = strtotime($validUntil);
        if ($expires && $expires > time()) {
            $daysLeft = max(0, ($expires - time()) / 86400);
            $credit = $current * min(1.0, $daysLeft / 30.0);
        }
    }
    return max(0.0, $target - $credit);
}

function ensure_payment_request_nullable()
{
    try {
        $col = db()->query("SHOW COLUMNS FROM payment_requests LIKE 'subscription_id'")->fetch();
        if ($col && strtoupper($col['Null']) === 'NO') {
            db()->exec("ALTER TABLE payment_requests MODIFY subscription_id INT UNSIGNED NULL");
        }
    } catch (\Throwable $e) {
        // silent; do not block flow
    }
}

function create_payment_request($subscription, $feature, $amount, $cycle = 'monthly', $planSlug = null, $metadata = [], $callbackUrl = null, $note = '')
{
    ensure_payment_request_nullable();
    $now = current_timestamp();
    $baseAmount = (float)$amount;
    $discount = null;
    $invoice = generate_invoice_id();
    if (in_array(strtolower($feature), ['subscription', 'renewal', 'upgrade', 'link'], true) && $baseAmount > 0) {
        $discount = generate_instant_discount_for_feature($feature, $baseAmount);
        if ($discount && isset($discount['payable'])) {
            $amount = (float)$discount['payable'];
        }
    }
    $noteToken = $note ?: ($planSlug ?: $feature);
    $noteToken = $invoice ? trim($noteToken . ' ' . $invoice) : $noteToken;
    if (!is_array($metadata)) {
        $metadata = [];
    }
    if ($invoice) {
        $metadata['invoice'] = $invoice;
    }
    if ($discount) {
        $metadata['base_amount'] = $baseAmount;
        $metadata['discount_percent'] = $discount['percent'] ?? 0;
        $metadata['discount_amount'] = $discount['amount'] ?? 0;
        $metadata['payable_amount'] = $discount['payable'] ?? $amount;
    }
    $overrideUpi = '';
    $overrideName = '';
    if (isset($metadata['merchant_upi'])) {
        $overrideUpi = trim((string)$metadata['merchant_upi']);
    }
    if (isset($metadata['merchant_name'])) {
        $overrideName = trim((string)$metadata['merchant_name']);
    }
    if ($overrideUpi !== '' && $overrideName !== '') {
        $deeplink = generate_payment_deeplink_with($amount, ucfirst($feature), $noteToken, $overrideUpi, $overrideName);
    } else {
        $deeplink = generate_payment_deeplink($amount, ucfirst($feature), $noteToken);
    }
    $subId = is_array($subscription) && isset($subscription['id']) ? $subscription['id'] : null;
    $userId = is_array($subscription) && isset($subscription['user_id']) ? $subscription['user_id'] : ($subscription['user'] ?? null);
    $stmt = db()->prepare("INSERT INTO payment_requests (subscription_id, user_id, feature, amount, currency, plan_slug, cycle, callback_url, metadata, deeplink, created_at, updated_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $subId,
        $userId,
        $feature,
        $amount,
        payment_gateway_currency(),
        $planSlug,
        $cycle,
        $callbackUrl,
        $metadata ? json_encode($metadata) : null,
        $deeplink,
        $now,
        $now,
    ]);
    $id = db()->lastInsertId();
    if (function_exists('licd_log_event')) {
        licd_log_event('payment_request_created', 'Created payment request', [
            'payment_id' => (int)$id,
            'feature' => $feature,
            'amount' => (float)$amount,
            'base_amount' => $baseAmount,
            'discount_percent' => $discount['percent'] ?? 0,
            'invoice' => $invoice,
        ]);
    }
    return [
        'id' => $id,
        'deeplink' => $deeplink,
        'amount' => $amount,
        'currency' => payment_gateway_currency(),
        'invoice' => $invoice,
        'discount' => $discount,
        'base_amount' => $baseAmount,
    ];
}

function mark_payment_request($paymentId, $state, $txnId = null, $response = [])
{
    $stmt = db()->prepare("UPDATE payment_requests SET state = ?, txn_id = ?, response_json = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([
        $state,
        $txnId,
        $response ? json_encode($response) : null,
        $paymentId,
    ]);
    // Try to synchronize platform orders (WooCommerce / EDD) when running inside WP
    try {
        sync_payment_request_order_state($paymentId, $state, $response);
    } catch (\Throwable $e) {
        // ignore; do not block payment flow
    }
}

function sync_payment_request_order_state($paymentId, $state, $response = [])
{
    $req = get_payment_request($paymentId);
    if (!$req) return false;
    $meta = payment_request_metadata($req);

    // WooCommerce integration (if running inside WP)
    if (function_exists('wc_get_order')) {
        $wooId = null;
        if (!empty($meta['woo_order_id'])) {
            $wooId = intval($meta['woo_order_id']);
        } elseif (!empty($meta['order_id'])) {
            $wooId = intval($meta['order_id']);
        }
        if ($wooId && $wooId > 0) {
            try {
                $order = wc_get_order($wooId);
                if ($order) {
                    if ($state === 'cancelled' || $state === 'failed') {
                        $order->update_status('failed', 'Payment marked as failed/cancelled by payment request state.');
                    } elseif ($state === 'submitted') {
                        $order->update_status('on-hold', 'Awaiting UPI payment confirmation (manual proof submitted).');
                    } elseif ($state === 'pending') {
                        $order->update_status('pending', 'Payment pending.');
                    } elseif ($state === 'completed') {
                        // If order has only downloadable/virtual products, complete it; else set processing
                        $allDownloadable = true;
                        foreach ($order->get_items() as $item) {
                            $product = $item->get_product();
                            if ($product && !$product->is_downloadable()) { $allDownloadable = false; break; }
                        }
                        if ($allDownloadable) {
                            $order->update_status('completed', 'Payment received; downloadable products delivered.');
                        } else {
                            $order->update_status('processing', 'Payment received via UPI.');
                        }
                    }
                }
            } catch (\Throwable $e) {
                // ignore
            }
        }
    }

    // EDD integration (if present)
    if (function_exists('edd_update_payment_status')) {
        $eddId = null;
        if (!empty($meta['edd_payment_id'])) {
            $eddId = intval($meta['edd_payment_id']);
        } elseif (!empty($meta['payment_post_id'])) {
            $eddId = intval($meta['payment_post_id']);
        }
        if ($eddId && $eddId > 0) {
            try {
                if ($state === 'cancelled' || $state === 'failed') {
                    edd_update_payment_status($eddId, 'failed');
                } elseif ($state === 'submitted') {
                    edd_update_payment_status($eddId, 'pending');
                } elseif ($state === 'pending') {
                    edd_update_payment_status($eddId, 'pending');
                } elseif ($state === 'completed') {
                    edd_update_payment_status($eddId, 'publish');
                }
            } catch (\Throwable $e) {
                // ignore
            }
        }
    }

    return true;
}

function mark_matching_payment_request_completed($subscriptionId, $txnId, $payerVpa, $amount, $userId = null, $allowedFeatures = null)
{
    if (empty($txnId) && empty($payerVpa)) {
        return false;
    }
    $sql = "SELECT * FROM payment_requests WHERE state IN ('pending','submitted')";
    $params = [];
    if ($subscriptionId) {
        $sql .= " AND subscription_id = ?";
        $params[] = $subscriptionId;
    }
    if ($userId) {
        $sql .= " AND user_id = ?";
        $params[] = $userId;
    }
    if (is_array($allowedFeatures) && !empty($allowedFeatures)) {
        $placeholders = implode(',', array_fill(0, count($allowedFeatures), '?'));
        $sql .= " AND feature IN (" . $placeholders . ")";
        foreach ($allowedFeatures as $feature) {
            $params[] = $feature;
        }
    }
    if (!empty($txnId)) {
        $sql .= " AND (txn_id = ? OR response_json LIKE ?)";
        $params[] = $txnId;
        $params[] = '%' . $txnId . '%';
    }
    $sql .= " ORDER BY created_at DESC LIMIT 1";
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $req = $stmt->fetch();
    if (!$req) {
        return false;
    }
    if ($amount > 0 && abs((float)$req['amount'] - (float)$amount) > 0.01) {
        return false;
    }
    mark_payment_request($req['id'], 'completed', $txnId, ['payer_vpa' => $payerVpa, 'amount' => $amount]);

    if ($req['feature'] === 'link') {
        $meta = payment_request_metadata($req);
        $linkSlug = $meta['link_slug'] ?? '';
        $customerEmail = $meta['customer_email'] ?? '';
        $downloadSent = !empty($meta['download_sent']);
        if ($linkSlug !== '' && $customerEmail !== '' && !$downloadSent) {
            $stmt = db()->prepare("SELECT payload FROM hosted_links WHERE subscription_id = ? AND slug = ? LIMIT 1");
            $stmt->execute([$req['subscription_id'], $linkSlug]);
            $row = $stmt->fetch();
            if ($row && !empty($row['payload'])) {
                $payload = json_decode($row['payload'], true);
                if (is_array($payload) && !empty($payload['digital_file_url'])) {
                    $downloadUrl = $payload['digital_file_url'];
                    if (function_exists('licd_send_mail')) {
                        $subject = 'Your download is ready';
                        $body = '<p>Thanks for your payment.</p><p><a href="' . esc_url($downloadUrl) . '">Download your file</a></p>';
                        licd_send_mail($customerEmail, $subject, $body);
                        update_payment_request_metadata($req['id'], ['download_sent' => true]);
                    }
                }
            }
        }
    }
    return $req;
}

function get_payment_request($paymentId)
{
    $stmt = db()->prepare("SELECT * FROM payment_requests WHERE id = ? LIMIT 1");
    $stmt->execute([$paymentId]);
    return $stmt->fetch();
}

function recent_payment_requests($limit = 10)
{
    $stmt = db()->prepare("SELECT pr.*, u.email AS user_email, p.name AS plan_name
                           FROM payment_requests pr
                           LEFT JOIN subscriptions s ON s.id = pr.subscription_id
                           LEFT JOIN users u ON u.id = COALESCE(pr.user_id, s.user_id)
                           LEFT JOIN plans p ON p.slug = COALESCE(pr.plan_slug, s.plan_slug)
                           ORDER BY pr.created_at DESC
                           LIMIT ?");
    $stmt->bindValue(1, (int)$limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function payment_request_metadata(array $row)
{
    if (empty($row['metadata'])) {
        return [];
    }
    $decoded = json_decode($row['metadata'], true);
    return is_array($decoded) ? $decoded : [];
}

function update_payment_request_metadata($paymentId, array $data)
{
    if (empty($data)) {
        return false;
    }
    $stmt = db()->prepare("SELECT metadata FROM payment_requests WHERE id = ? LIMIT 1");
    $stmt->execute([(int)$paymentId]);
    $row = $stmt->fetch();
    if (!$row) {
        return false;
    }
    $current = [];
    if (!empty($row['metadata'])) {
        $decoded = json_decode($row['metadata'], true);
        if (is_array($decoded)) {
            $current = $decoded;
        }
    }
    $merged = array_merge($current, $data);
    $stmt = db()->prepare("UPDATE payment_requests SET metadata = ?, updated_at = NOW() WHERE id = ?");
    return $stmt->execute([json_encode($merged), (int)$paymentId]);
}

function latest_pending_payment_request()
{
    $stmt = db()->prepare("SELECT * FROM payment_requests WHERE state IN ('pending','submitted') ORDER BY created_at DESC LIMIT 1");
    $stmt->execute();
    return $stmt->fetch();
}

function latest_pending_payment_request_for_user($userId, $allowedFeatures = null)
{
    $sql = "SELECT * FROM payment_requests WHERE state IN ('pending','submitted') AND user_id = ?";
    $params = [$userId];
    if (is_array($allowedFeatures) && !empty($allowedFeatures)) {
        $placeholders = implode(',', array_fill(0, count($allowedFeatures), '?'));
        $sql .= " AND feature IN (" . $placeholders . ")";
        foreach ($allowedFeatures as $feature) {
            $params[] = $feature;
        }
    }
    $sql .= " ORDER BY created_at DESC LIMIT 1";
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetch();
}

function payment_summary()
{
    $paidStmt = db()->query("SELECT COUNT(*) AS ct, COALESCE(SUM(amount),0) AS total FROM payments WHERE status = 'completed'");
    $paidRow = $paidStmt->fetch();
    $pendingStmt = db()->query("SELECT COUNT(*) AS ct, COALESCE(SUM(amount),0) AS total FROM payment_requests WHERE state IN ('pending','submitted')");
    $pendingRow = $pendingStmt->fetch();
    $paidCt = (int)($paidRow['ct'] ?? 0);
    $paidTotal = (float)($paidRow['total'] ?? 0);
    $pendingCt = (int)($pendingRow['ct'] ?? 0);
    $pendingTotal = (float)($pendingRow['total'] ?? 0);
    return [
        'total' => $paidCt + $pendingCt,
        'paid' => $paidCt,
        'pending' => $pendingCt,
        'revenue' => $paidTotal,
        'on_the_way_amount' => $pendingTotal,
    ];
}
