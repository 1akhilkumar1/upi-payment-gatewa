<?php

if (!function_exists('current_user')) {
function current_user()
{
    // Prefer WordPress auth when available
    if (function_exists('is_user_logged_in') && is_user_logged_in()) {
        $wp_user = wp_get_current_user();
        if ($wp_user && $wp_user->exists()) {
            $existing = licd_get_user_by_email($wp_user->user_email);
            if ($existing) {
                return $existing;
            }
            // Create a local record mirroring WP user
            $role = user_can($wp_user, 'manage_options') ? 'admin' : 'customer';
            $id   = licd_create_user($wp_user->display_name ?: $wp_user->user_login, $wp_user->user_email, wp_generate_password(20), $role);
            return licd_get_user_by_id($id);
        }
    }
    if (!empty($_SESSION['user_id'])) {
        return licd_get_user_by_id($_SESSION['user_id']);
    }
    return null;
}
} // function exists

function require_auth()
{
    // For this app, always send unauthenticated users to the bundled login page.
    if (empty($_SESSION['user_id']) && (!function_exists('is_user_logged_in') || !is_user_logged_in())) {
        redirect('login.php');
    }
}

function require_admin()
{
    require_auth();
    if (function_exists('current_user_can') && current_user_can('manage_options')) {
        return;
    }
    $user = current_user();
    if (!$user || $user['role'] !== 'admin') {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

function licd_get_user_by_id($id)
{
    $stmt = db()->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function licd_get_user_by_email($email)
{
    $stmt = db()->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    return $stmt->fetch();
}

function licd_create_user($name, $email, $password, $role = 'customer')
{
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = db()->prepare("INSERT INTO users (name, email, password_hash, role, status, created_at, updated_at)
                           VALUES (?, ?, ?, ?, 'active', NOW(), NOW())");
    $stmt->execute([$name, $email, $hash, $role]);
    $id = db()->lastInsertId();

    // Create WP user if possible
    if (function_exists('wp_insert_user')) {
        $maybe_user = get_user_by('email', $email);
        if (!$maybe_user) {
            $username = sanitize_user(str_replace('@', '_', $email));
            $wp_id = wp_insert_user([
                'user_login' => $username,
                'user_pass'  => $password,
                'user_email' => $email,
                'display_name' => $name,
                'role' => $role === 'admin' ? 'administrator' : 'subscriber',
            ]);
            if (is_wp_error($wp_id)) {
                licd_log_error('WP user create failed', ['email' => $email, 'error' => $wp_id->get_error_message()]);
            } else {
                update_user_meta($wp_id, '_licd_user_id', $id);
            }
        } else {
            update_user_meta($maybe_user->ID, '_licd_user_id', $id);
        }
    }
    if (function_exists('licd_send_mail')) {
        $loginUrl = function_exists('licd_public_url') ? licd_public_url('login.php') : (defined('BASE_URL') ? rtrim(BASE_URL, '/') . '/login.php' : '');
        $body = '<p>Hi ' . esc_html($name) . ',</p>'
              . '<p>Your account is ready. You can sign in with your email address.</p>'
              . ($loginUrl ? '<p><a href="' . esc_url($loginUrl) . '">Login to your dashboard</a></p>' : '');
        licd_send_mail($email, 'Welcome to eGo', $body);
    }
    return $id;
}

function attempt_login($email, $password)
{
    if (function_exists('wp_signon')) {
        $creds = [
            'user_login'    => $email,
            'user_password' => $password,
            'remember'      => true,
        ];
        $wp_user = wp_signon($creds, is_ssl());
        if (!is_wp_error($wp_user)) {
            $user = licd_get_user_by_email($wp_user->user_email);
            if (!$user) {
                $role = user_can($wp_user, 'manage_options') ? 'admin' : 'customer';
                $id   = licd_create_user($wp_user->display_name ?: $wp_user->user_login, $wp_user->user_email, $password, $role);
                $user = licd_get_user_by_id($id);
            }
            if ($wp_user && isset($user['id'])) {
                update_user_meta($wp_user->ID, '_licd_user_id', $user['id']);
            }
            $_SESSION['user_id'] = $user['id'];
            return $user;
        }
    }

    $user = licd_get_user_by_email($email);
    if ($user && password_verify($password, $user['password_hash']) && $user['status'] === 'active') {
        $_SESSION['user_id'] = $user['id'];
        return $user;
    }
    return false;
}

function logout()
{
    if (function_exists('wp_logout')) {
        wp_logout();
    }
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

function licd_get_api_token($tokenValue)
{
    $stmt = db()->prepare("SELECT * FROM api_tokens WHERE token = ? AND active = 1 LIMIT 1");
    $stmt->execute([$tokenValue]);
    return $stmt->fetch();
}

function licd_get_user_by_api_token($tokenValue)
{
    $token = licd_get_api_token($tokenValue);
    if (!$token) {
        return null;
    }
    return licd_get_user_by_id($token['user_id']);
}

function create_api_token_for_user($user_id)
{
    $token = bin2hex(random_bytes(24));
    $now = current_timestamp();
    $stmt = db()->prepare("INSERT INTO api_tokens (user_id, token, scopes, active, created_at) VALUES (?, ?, 'wp_plugin,app', 1, ?)");
    $stmt->execute([$user_id, $token, $now]);
    return $token;
}

function update_user_name($user_id, $name)
{
    $stmt = db()->prepare("UPDATE users SET name = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$name, $user_id]);
}

function verify_user_password($user_id, $password)
{
    $user = licd_get_user_by_id($user_id);
    if (!$user) {
        return false;
    }
    return password_verify($password, $user['password_hash']);
}

function update_user_password($user_id, $newPassword)
{
    $hash = password_hash($newPassword, PASSWORD_BCRYPT);
    $stmt = db()->prepare("UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$hash, $user_id]);
}

function ensure_password_resets_table()
{
    db()->exec("CREATE TABLE IF NOT EXISTS password_resets (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        token VARCHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_token (token),
        KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function create_password_reset($email)
{
    $user = licd_get_user_by_email($email);
    if (!$user) {
        return null;
    }
    ensure_password_resets_table();
    $token = bin2hex(random_bytes(24));
    $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
    $stmt = db()->prepare("INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)");
    $stmt->execute([$user['id'], $token, $expires]);
    return ['user' => $user, 'token' => $token, 'expires_at' => $expires];
}

function get_password_reset($token)
{
    if (!$token) {
        return null;
    }
    ensure_password_resets_table();
    $stmt = db()->prepare("SELECT pr.*, u.email, u.name FROM password_resets pr JOIN users u ON u.id = pr.user_id WHERE pr.token = ? AND pr.expires_at > NOW() LIMIT 1");
    $stmt->execute([$token]);
    return $stmt->fetch();
}

function consume_password_reset($token, $newPassword)
{
    $row = get_password_reset($token);
    if (!$row) {
        return false;
    }
    update_user_password($row['user_id'], $newPassword);
    $stmt = db()->prepare("DELETE FROM password_resets WHERE token = ?");
    $stmt->execute([$token]);
    if (function_exists('licd_send_mail')) {
        licd_send_mail($row['email'], 'Your password was updated', '<p>Hi ' . esc_html($row['name']) . ',</p><p>Your password has been updated successfully.</p>');
    }
    return true;
}
