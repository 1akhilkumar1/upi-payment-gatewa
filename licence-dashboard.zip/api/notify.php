<?php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

$raw = file_get_contents('php://input');
if ($raw === false || $raw === '') {
    $raw = '{}';
}
$sig = $_SERVER['HTTP_X_FG_SIGNATURE'] ?? '';
if ($sig === '') {
    http_response_code(401);
    echo json_encode(['ok' => false, 'reason' => 'missing_signature']);
    exit;
}
$secret = get_app_hmac_secret();
$calc = base64_encode(hash_hmac('sha256', $raw, $secret, true));
if (!hash_equals($calc, $sig)) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'reason' => 'invalid_signature']);
    exit;
}

$payload = json_decode($raw, true);
if (!is_array($payload)) {
    $payload = [];
}

// Try to associate notify with a user for optional saved logs
$userForLog = null;
if (!empty($payload['payment_id']) || !empty($payload['order_id'])) {
    $pid = intval($payload['payment_id'] ?? $payload['order_id']);
    if ($pid > 0) {
        $reqRow = get_payment_request($pid);
        if ($reqRow) {
            $userForLog = $reqRow['user_id'] ?? null;
        }
    }
}

// Matching window (minutes) - only consider very recent pending requests for automatic unique-amount matching.
$match_window_minutes = intval(get_setting('payment_match_window_minutes', 60));

$direction = strtolower(trim((string)($payload['direction'] ?? '')));
if ($direction === 'debit') {
    echo json_encode(['ok' => true, 'matched' => 0]);
    exit;
}

$amountRaw = $payload['amount'] ?? null;
$amountCandidates = payment_amount_candidates($amountRaw);
$hasAmount = !empty($amountCandidates);
$orderId = (int)($payload['order_id'] ?? 0);
if ($orderId <= 0 && !empty($payload['payment_id'])) {
    $orderId = (int)$payload['payment_id'];
}
$txn = trim((string)($payload['utr'] ?? $payload['txn_id'] ?? $payload['transaction_id'] ?? ''));
$payer = trim((string)($payload['payer_vpa'] ?? ''));
$note = trim((string)($payload['note'] ?? ''));

function finalize_payment_request(array $req, $matchedAmount, array $payload, $txn, $payer)
{
    $feature = $req['feature'] ?? 'subscription';
    $cycle = $req['cycle'] ?? 'monthly';
    $subId = (int)($req['subscription_id'] ?? 0);
    if ($subId <= 0) {
        $subId = ensure_subscription_from_request($req);
        if ($subId) {
            db()->prepare("UPDATE payment_requests SET subscription_id = ? WHERE id = ?")->execute([$subId, $req['id']]);
        }
    }
    if ($subId) {
        activate_subscription_from_payment($subId, $cycle);
        $type = strtolower($feature) === 'renewal' ? 'renewal' : 'initial';
        create_payment_record(
            $subId,
            $matchedAmount,
            'upi',
            'completed',
            $type,
            $payload,
            $req['currency'] ?? payment_gateway_currency(),
            $txn ?: null,
            current_timestamp()
        );
        $subscription = get_subscription_by_id($subId);
        if ($subscription) {
            record_payment_sync(
                $subId,
                $subscription['user_id'],
                $subscription['license_key'],
                'app',
                $feature,
                $matchedAmount,
                $txn,
                $payer,
                ['payload' => $payload],
                [],
                null,
                $feature
            );
        }
    }
    mark_payment_request($req['id'], 'completed', $txn, $payload);
    return $subId;
}

$matchedId = 0;
$matchedSub = 0;
$matchReason = '';

if ($orderId > 0) {
    $req = get_payment_request($orderId);
    if ($req && in_array($req['state'], ['pending','submitted'], true) && $hasAmount) {
        $picked = pick_matching_amount((float)$req['amount'], $amountCandidates);
        if ($picked !== null) {
            $matchedId = (int)$req['id'];
            $matchedSub = finalize_payment_request($req, $picked, $payload, $txn, $payer);
            $matchReason = 'order_id';
        }
    }
}

if ($matchedId === 0 && $hasAmount) {
    $stmt = db()->prepare("SELECT * FROM payment_requests WHERE state IN ('pending','submitted') AND created_at >= DATE_SUB(NOW(), INTERVAL $match_window_minutes MINUTE) ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $rows = $stmt->fetchAll();
    $candidates = [];
    foreach ($rows as $row) {
        $picked = pick_matching_amount((float)$row['amount'], $amountCandidates);
        if ($picked !== null) {
            $candidates[] = [$row, $picked];
        }
    }
    if (count($candidates) === 1) {
        $row = $candidates[0][0];
        $matchedId = (int)$row['id'];
        $matchedSub = finalize_payment_request($row, $candidates[0][1], $payload, $txn, $payer);
        $matchReason = 'unique_amount';
    } elseif (count($candidates) > 1 && $note !== '') {
        foreach ($candidates as $cand) {
            $meta = payment_request_metadata($cand[0]);
            $invoice = $meta['invoice'] ?? '';
            if ($invoice !== '' && stripos($note, $invoice) !== false) {
                $matchedId = (int)$cand[0]['id'];
                $matchedSub = finalize_payment_request($cand[0], $cand[1], $payload, $txn, $payer);
                $matchReason = 'note_invoice';
                break;
            }
        }
    }
}

if (function_exists('licd_log_event')) {
    licd_log_event('app_notify', 'Notification received', [
        'order_id' => $orderId ?: null,
        'amount_candidates' => $amountCandidates,
        'matched_id' => $matchedId,
        'matched_subscription' => $matchedSub,
        'match_reason' => $matchReason,
        'txn' => $txn ? substr($txn, 0, 6) . '...' : '',
        'payer' => $payer ? substr($payer, 0, 4) . '***' : '',
    ]);
}

// Save notify payload to app_saved_logs if the associated user has enabled it
if ($userForLog) {
    $uk = get_user_app_key($userForLog);
    if ($uk && !empty($uk['save_logs'])) {
        save_app_log($userForLog, 'notify', $payload);
    }
} else {
    // fallback: no associated user found — save as anonymous if global save requested
    // do not save anonymous by default
}

echo json_encode([
    'ok' => true,
    'matched' => $matchedId,
    'subscription_id' => $matchedSub,
]);
