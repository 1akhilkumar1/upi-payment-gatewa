<?php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

$raw = file_get_contents('php://input');
if ($raw === false || $raw === '') {
    $raw = '{}';
}
$sig = $_SERVER['HTTP_X_FG_SIGNATURE'] ?? '';
if ($sig === '') {
    http_response_code(401);
    echo json_encode(['ok' => false, 'reason' => 'missing_signature']);
    exit;
}

$secret = get_app_hmac_secret();
$calc = base64_encode(hash_hmac('sha256', $raw, $secret, true));
if (!hash_equals($calc, $sig)) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'reason' => 'invalid_signature']);
    exit;
}

echo json_encode([
    'ok' => true,
    'summary' => payment_summary(),
]);
