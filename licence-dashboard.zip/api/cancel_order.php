<?php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

$raw = file_get_contents('php://input');
if ($raw === false || $raw === '') {
    $raw = '{}';
}
$sig = $_SERVER['HTTP_X_FG_SIGNATURE'] ?? '';
if ($sig === '') {
    http_response_code(401);
    echo json_encode(['ok' => false, 'reason' => 'missing_signature']);
    exit;
}
$secret = get_app_hmac_secret();
$calc = base64_encode(hash_hmac('sha256', $raw, $secret, true));
if (!hash_equals($calc, $sig)) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'reason' => 'invalid_signature']);
    exit;
}

$payload = json_decode($raw, true);
if (!is_array($payload)) { $payload = []; }

$paymentId = intval($payload['payment_id'] ?? 0);
$reason = trim((string)($payload['reason'] ?? 'cancelled_by_user'));

if ($paymentId <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'reason' => 'missing_payment_id']);
    exit;
}

$req = get_payment_request($paymentId);
if (!$req) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'reason' => 'not_found']);
    exit;
}

if (!in_array($req['state'], ['pending','submitted'], true)) {
    echo json_encode(['ok' => false, 'reason' => 'not_pending', 'state' => $req['state']]);
    exit;
}

// Mark cancelled so future notifications won't match this request
mark_payment_request($paymentId, 'cancelled', null, ['note' => $reason]);
if (function_exists('licd_log_event')) {
    licd_log_event('payment_request_cancelled', 'Payment request canceled via API', [
        'payment_id' => $paymentId,
        'reason' => $reason,
    ]);
}

echo json_encode(['ok' => true, 'payment_id' => $paymentId, 'state' => 'cancelled']);
