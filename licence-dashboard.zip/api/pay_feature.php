<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = $_REQUEST['token'] ?? null;
$licenseKey = $_REQUEST['license_key'] ?? null;
$feature = $_REQUEST['feature'] ?? '';
$quantity = max(1, (int)($_REQUEST['quantity'] ?? 1));
$subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);

if (!$subscription) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => $reason ?? 'no_subscription']);
    exit;
}

switch ($feature) {
    case 'domain':
        $fee = get_extra_domain_fee();
        $title = 'Add domain request';
        $purpose = 'Domain whitelist fee';
        break;
    case 'landing_link':
    case 'link':
        $feature = 'landing_link';
        $fee = get_extra_link_fee();
        $title = 'Add landing link';
        $purpose = 'Landing page fee';
        break;
    default:
        http_response_code(400);
        echo json_encode(['ok' => false, 'reason' => 'unknown_feature']);
        exit;
}

$amount = $fee * $quantity;
if ($amount <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'reason' => 'invalid_amount']);
    exit;
}

$metadata = [];
if (!empty($_REQUEST['domain'])) {
    $metadata['domain'] = trim($_REQUEST['domain']);
}

$payload = create_payment_request(
    $subscription,
    $feature,
    $amount,
    'monthly',
    null,
    $metadata + ['quantity' => $quantity],
    null,
    $title
);
$response = [
    'ok' => true,
    'payment_id' => $payload['id'],
    'deeplink' => $payload['deeplink'],
    'amount' => number_format($payload['amount'], 2, '.', ''),
    'currency' => $payload['currency'],
    'feature' => $feature,
    'title' => $title,
    'purpose' => $purpose,
    'license' => build_subscription_payload($subscription),
];
if (!empty($payload['invoice'])) {
    $response['invoice'] = $payload['invoice'];
}
if (!empty($payload['discount'])) {
    $response['discount'] = $payload['discount'];
    $response['base_amount'] = $payload['base_amount'] ?? null;
}
echo json_encode($response);
