<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input') ?: '', true);
$email = trim($data['email'] ?? $_POST['email'] ?? '');
$password = trim($data['password'] ?? $_POST['password'] ?? '');
error_log("Login payload received: " . json_encode(['email'=>$email,'password'=> $password ? '***' : '']));

if ($email === '' || $password === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'reason' => 'missing_credentials']);
    exit;
}

$user = licd_get_user_by_email($email);
if (!$user || $user['status'] !== 'active' || !password_verify($password, $user['password_hash'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'reason' => 'invalid_credentials']);
    exit;
}

$token = create_api_token_for_user($user['id']);

echo json_encode([
    'ok' => true,
    'token' => $token,
    'user' => [
        'id' => $user['id'],
        'email' => $user['email'],
        'name' => $user['name'],
    ],
]);
