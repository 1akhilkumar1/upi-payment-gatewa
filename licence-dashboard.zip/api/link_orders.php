<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = request_param_trim('token');
$licenseKey = request_param_trim('license_key');
$limit = max(1, min(50, request_param_int('limit', 20)));

$reason = null;
$subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);
if (!$subscription) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => $reason ?? 'no_subscription']);
    exit;
}

$stmt = db()->prepare("SELECT * FROM payment_requests WHERE subscription_id = ? AND feature = 'link' ORDER BY created_at DESC LIMIT ?");
$stmt->bindValue(1, $subscription['id'], PDO::PARAM_INT);
$stmt->bindValue(2, $limit, PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll();

$orders = [];
foreach ($rows as $row) {
    $meta = payment_request_metadata($row);
    $response = $row['response_json'] ? json_decode($row['response_json'], true) : [];
    if (!is_array($response)) {
        $response = [];
    }
    $proofSubmitted = ($row['state'] === 'submitted') ||
        !empty($response['payer_name']) || !empty($response['payer_upi']) || !empty($response['txn_id']);
    $displayStatus = $proofSubmitted ? 'processing' : $row['state'];
    $orders[] = [
        'id' => (int)$row['id'],
        'amount' => (float)$row['amount'],
        'currency' => $row['currency'] ?: 'INR',
        'state' => $row['state'],
        'display_status' => $displayStatus,
        'created_at' => $row['created_at'],
        'link_title' => $meta['link_title'] ?? '',
        'link_slug' => $meta['link_slug'] ?? '',
        'customer_name' => $meta['customer_name'] ?? '',
        'customer_email' => $meta['customer_email'] ?? '',
        'customer_phone' => $meta['customer_phone'] ?? '',
        'customer_address' => $meta['customer_address'] ?? '',
        'invoice' => $meta['invoice'] ?? '',
        'payer_name' => $response['payer_name'] ?? ($meta['payer_name'] ?? ''),
        'payer_upi' => $response['payer_upi'] ?? ($meta['payer_upi'] ?? ''),
        'txn_id' => $row['txn_id'] ?? ($response['txn_id'] ?? ($meta['txn_id'] ?? '')),
        'screenshot' => $response['screenshot'] ?? ($meta['screenshot'] ?? ''),
        'proof_submitted' => $proofSubmitted,
    ];
}

echo json_encode([
    'ok' => true,
    'orders' => $orders,
    'license' => build_subscription_payload($subscription),
]);
