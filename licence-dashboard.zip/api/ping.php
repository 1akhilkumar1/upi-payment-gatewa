<?php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

$raw = file_get_contents('php://input');
if ($raw === false || $raw === '') {
    $raw = '{}';
}
$userId = $_SERVER['HTTP_X_FG_USER_ID'] ?? '';
$keyId = $_SERVER['HTTP_X_FG_KEY_ID'] ?? '';
if ($userId === '' || $keyId === '') {
    http_response_code(401);
    echo json_encode(['ok' => false, 'reason' => 'missing_user_or_key']);
    exit;
}
$userKey = get_user_app_key_by_key_id($keyId);
if (!$userKey || $userKey['user_id'] != $userId) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'reason' => 'invalid_key']);
    exit;
}
$secret = $userKey['secret'];
$sig = $_SERVER['HTTP_X_FG_SIGNATURE'] ?? '';
if ($sig === '') {
    http_response_code(401);
    echo json_encode(['ok' => false, 'reason' => 'missing_signature']);
    exit;
}
$calc = base64_encode(hash_hmac('sha256', $raw, $secret, true));
if (!hash_equals($calc, $sig)) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'reason' => 'invalid_signature']);
    exit;
}

$summary = payment_summary();
$latest = latest_pending_payment_request();
$latestOut = null;
if ($latest) {
    $meta = payment_request_metadata($latest);
    $invoice = $meta['invoice'] ?? '';
    $label = $invoice ?: ('PAY-' . $latest['id']);
    $latestOut = [
        'id' => (string)$latest['id'],
        'number' => (string)$label,
        'status' => $latest['state'],
        'total' => (float)$latest['amount'],
        'currency' => $latest['currency'] ?? payment_gateway_currency(),
        'created_at' => $latest['created_at'] ?? null,
        'merchant_vpa' => get_payment_gateway_upi(),
    ];
}

if (function_exists('licd_log_event')) {
    licd_log_event('app_ping', 'Ping received', [
        'device' => $_SERVER['HTTP_X_FG_DEVICE'] ?? '',
        'armed_payment_id' => $latest['id'] ?? null,
    ]);
}

update_user_app_ping($userId, $_SERVER['HTTP_X_FG_DEVICE'] ?? '');
// Save ping log if user enabled
$uk = get_user_app_key($userId);
if ($uk && !empty($uk['save_logs'])) {
    save_app_log($userId, 'ping', $raw);
}

echo json_encode([
    'ok' => true,
    'latest_order' => $latestOut,
    'summary' => $summary,
]);
