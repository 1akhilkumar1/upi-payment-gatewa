<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = request_param_trim('token');
$licenseKey = request_param_trim('license_key');
$feature = request_param_trim('feature', 'subscription');
$planSlug = request_param_trim('plan_slug');
$cycle = request_param_trim('cycle', 'monthly');
$quantity = max(1, request_param_int('quantity', 1));
$callbackUrl = request_param_trim('callback_url');
$amountOverride = request_param_float('amount', 0.0);
$metadata = request_param_array('metadata', []);

$subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);
if (!$subscription) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => $reason ?? 'no_subscription']);
    exit;
}

$plan = $planSlug ? get_plan_by_slug($planSlug) : null;
if (!$plan) {
    $plan = $subscription['plan'];
}

$amount = 0.0;
switch ($feature) {
    case 'subscription':
        $amount = plan_price_for_cycle($plan, $cycle);
        break;
    case 'renewal':
        $amount = plan_price_for_cycle($plan, $cycle);
        break;
    case 'upgrade':
        $amount = calculate_upgrade_amount($subscription['plan'], $plan, $cycle);
        $amount += get_upgrade_fee();
        break;
    case 'domain':
        $amount = get_extra_domain_fee() * $quantity;
        break;
    case 'landing_link':
    case 'link':
        $amount = get_extra_link_fee() * $quantity;
        break;
    default:
        http_response_code(400);
        echo json_encode(['ok' => false, 'reason' => 'unknown_feature']);
        exit;
}

if ($amountOverride > 0) {
    $amount = $amountOverride;
}

if ($amount <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'reason' => 'invalid_amount']);
    exit;
}

$payload = create_payment_request(
    $subscription,
    $feature,
    $amount,
    $cycle,
    $plan['slug'],
    $metadata ? $metadata : null,
    $callbackUrl ?: null,
    $plan['name'] ?? $feature
);

$response = [
    'ok' => true,
    'payment_id' => $payload['id'],
    'deeplink' => $payload['deeplink'],
    'amount' => number_format($payload['amount'], 2, '.', ''),
    'currency' => $payload['currency'],
    'feature' => $feature,
    'plan' => $plan,
    'cycle' => $cycle,
    'license' => build_subscription_payload($subscription),
];
if (!empty($payload['invoice'])) {
    $response['invoice'] = $payload['invoice'];
}
if (!empty($payload['discount'])) {
    $response['discount'] = $payload['discount'];
    $response['base_amount'] = $payload['base_amount'] ?? null;
}

if ($callbackUrl) {
    $response['callback_url'] = $callbackUrl;
}

echo json_encode($response);
