<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = request_param_trim('token');
$licenseKey = request_param_trim('license_key');

$reason = null;
$subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);
if (!$subscription) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => $reason ?? 'no_subscription']);
    exit;
}

// Fetch all hosted links for this subscription
$stmt = db()->prepare("SELECT * FROM hosted_links WHERE subscription_id = ? ORDER BY created_at DESC");
$stmt->execute([$subscription['id']]);
$links = $stmt->fetchAll();

// Preload stats from payment_sync_logs grouped by product (link slug)
$stats = [];
$sql = "SELECT product,
               SUM(CASE WHEN feature = 'link_view' THEN 1 ELSE 0 END) AS views,
               SUM(CASE WHEN feature <> 'link_view' THEN 1 ELSE 0 END) AS payments,
               SUM(CASE WHEN feature <> 'link_view' THEN amount ELSE 0 END) AS revenue,
               MAX(CASE WHEN feature <> 'link_view' THEN recorded_at ELSE NULL END) AS last_paid
        FROM payment_sync_logs
        WHERE subscription_id = ? AND product IS NOT NULL AND product <> ''
        GROUP BY product";
$st = db()->prepare($sql);
$st->execute([$subscription['id']]);
foreach ($st->fetchAll() as $row) {
    $stats[$row['product']] = $row;
}

$out = [];
foreach ($links as $link) {
    $slug = $link['slug'];
    $base = $link['domain'] ?: DEFAULT_HOSTED_DOMAIN;
    $base = rtrim($base, '/');
    $url = $base . '/link/' . $slug;
    $st = $stats[$slug] ?? ['views' => 0, 'payments' => 0, 'revenue' => 0, 'last_paid' => null];
    $payload = json_decode($link['payload'], true) ?: [];
    $linkType = $payload['link_type'] ?? 'payment_link';
    $out[] = [
        'link_id'    => $slug,
        'title'      => $link['title'],
        'amount'     => (float) $link['amount'],
        'type'       => $linkType,
        'status'     => $link['status'],
        'url'        => $url,
        'views'      => (int) $st['views'],
        'payments'   => (int) $st['payments'],
        'revenue'    => (float) $st['revenue'],
        'last_paid'  => $st['last_paid'],
        'created_at' => $link['created_at'],
    ];
}

echo json_encode([
    'ok' => true,
    'links' => $out,
]);
