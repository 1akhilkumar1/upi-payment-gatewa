<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = request_param_trim('token');
$licenseKey = request_param_trim('license_key');
$linkId     = request_param_trim('link_id'); // hosted link slug

if ($linkId === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'reason' => 'missing_link_id']);
    exit;
}

$reason = null;
$subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);
if (!$subscription) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => $reason ?? 'no_subscription']);
    exit;
}

// Look up the hosted link for this subscription
$stmt = db()->prepare("SELECT * FROM hosted_links WHERE subscription_id = ? AND slug = ? LIMIT 1");
$stmt->execute([$subscription['id'], $linkId]);
$link = $stmt->fetch();

if (!$link) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'reason' => 'link_not_found']);
    exit;
}

// Record a lightweight view event in payment_sync_logs to avoid new tables
$stmt = db()->prepare("INSERT INTO payment_sync_logs (subscription_id, user_id, license_key, source, feature, amount, txn_id, payer_vpa, customer_email, customer_phone, domain, product, metadata, recorded_at)
                       VALUES (?, ?, ?, 'app', 'link_view', 0, NULL, NULL, NULL, NULL, ?, ?, ?, NOW())");
$meta = json_encode(['event' => 'render']);
$stmt->execute([
    $subscription['id'],
    $subscription['user_id'],
    $subscription['license_key'],
    $link['domain'] ?: DEFAULT_HOSTED_DOMAIN,
    $linkId,
    $meta,
]);

echo json_encode(['ok' => true]);
