<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = request_param_trim('token');
$licenseKey = request_param_trim('license_key');

$subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);

if (!$subscription) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => $reason ?? 'no_subscription']);
    exit;
}

$linkType = '';
if (is_array($fields) && isset($fields['link_type'])) {
    $linkType = trim((string)$fields['link_type']);
}

$plan = $subscription['plan'];
$linksLimit = 0;
if ($linkType === 'landing_page') {
    $linksLimit = intval($plan['landing_pages_limit'] ?? 0);
} elseif ($linkType === 'payment_link') {
    $linksLimit = intval($plan['payment_links_limit'] ?? 0);
} elseif ($linkType === 'payment_page') {
    $linksLimit = intval($plan['whitelist_domains_limit'] ?? 0); // Assuming payment pages use whitelist limit
} else {
    $linksLimit = intval($plan['payment_links_limit'] ?? 0); // Default
}
if ($linksLimit > 0 && count_hosted_links($subscription['id']) >= $linksLimit) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => 'links_limit_reached']);
    exit;
}

$title = request_param_trim('title');
$amount = request_param_float('amount', 0.0);
$description = request_param_trim('description');
$purpose = request_param_trim('purpose');
$domain = normalize_domain(request_param_trim('domain'));
$image = request_param_trim('image_url');
$fields = request_param_array('fields', []);
$linkType = '';
if (is_array($fields) && isset($fields['link_type'])) {
    $linkType = trim((string)$fields['link_type']);
}

if ($domain !== '') {
    $reason = null;
    if (!request_domain_for_subscription($subscription['id'], $domain, $reason)) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'reason' => $reason]);
        exit;
    }
}

if ($title === '' || ($amount <= 0 && $linkType !== 'landing_page')) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'reason' => 'invalid_payload']);
    exit;
}

$slug = create_hosted_link($subscription['id'], $subscription['user_id'], $title, $description, $amount, $purpose, $image, $domain ?: DEFAULT_HOSTED_DOMAIN, $fields);
if (!$slug) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'reason' => 'unable_to_create']);
    exit;
}

$baseDomain = $domain ?: DEFAULT_HOSTED_DOMAIN;
// Use plugin path to avoid root-level 404s
$url = rtrim($baseDomain, '/') . '/link/' . urlencode($slug);

echo json_encode([
    'ok' => true,
    'url' => $url,
    'link_id' => $slug,
    'plan' => $plan,
    'license' => build_subscription_payload($subscription),
]);
