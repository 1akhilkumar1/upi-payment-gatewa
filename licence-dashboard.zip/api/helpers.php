<?php

function touch_api_token($tokenId)
{
    $stmt = db()->prepare("UPDATE api_tokens SET last_used_at = NOW() WHERE id = ?");
    $stmt->execute([$tokenId]);
}

function resolve_subscription_from_token($tokenValue, &$reason = null)
{
    if (!$tokenValue) {
        $reason = 'missing_token';
        return null;
    }

    $token = licd_get_api_token($tokenValue);
    if (!$token) {
        $reason = 'invalid_token';
        return null;
    }

    touch_api_token($token['id']);
    $subscription = get_active_subscription_for_user($token['user_id']);

    if (!$subscription) {
        $reason = 'no_active_subscription';
    }

    return $subscription;
}

function resolve_subscription_from_license($licenseKey, &$reason = null)
{
    if (!$licenseKey) {
        $reason = 'missing_license_key';
        return null;
    }
    $key = strtoupper(trim($licenseKey));
    if ($key === '') {
        $reason = 'invalid_license_key';
        return null;
    }
    $subscription = get_subscription_by_license($key);
    if (!$subscription) {
        $reason = 'invalid_license_key';
    }
    return $subscription;
}

function resolve_subscription_for_api($tokenValue, $licenseKey, &$reason = null)
{
    if ($tokenValue) {
        return resolve_subscription_from_token($tokenValue, $reason);
    }
    if ($licenseKey) {
        return resolve_subscription_from_license($licenseKey, $reason);
    }
    $reason = 'missing_token_or_license';
    return null;
}

function build_payment_response($subscription, $amount, $feature, $title, $purpose, array $metadata = [])
{
    $deeplink = generate_payment_deeplink($amount, $purpose, $title);
    return [
        'ok' => true,
        'amount' => number_format($amount, 2, '.', ''),
        'feature' => $feature,
        'title' => $title,
        'purpose' => $purpose,
        'upi_link' => $deeplink,
        'license' => build_subscription_payload($subscription),
        'metadata' => $metadata,
    ];
}
