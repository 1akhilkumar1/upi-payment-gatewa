<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = $_REQUEST['token'] ?? null;
$licenseKey = $_REQUEST['license_key'] ?? null;

if (!$tokenValue && !$licenseKey) {
    echo json_encode([
        'ok' => false,
        'reason' => 'missing_token_or_license',
    ]);
    exit;
}

$subscription = null;
$reason = null;

if ($tokenValue) {
    $token = licd_get_api_token($tokenValue);
    if (!$token) {
        echo json_encode([
            'ok' => false,
            'reason' => 'invalid_token',
        ]);
        exit;
    }
    touch_api_token($token['id']);
    $subscription = get_last_subscription_for_user($token['user_id']);
    if (!$subscription) {
        echo json_encode([
            'ok' => true,
            'reason' => 'no_subscription_found',
            'active' => false,
        ]);
        exit;
    }
} else {
    $key = strtoupper(trim($licenseKey));
    if ($key === '') {
        echo json_encode([
            'ok' => false,
            'reason' => 'invalid_license_key',
        ]);
        exit;
    }
    $subscription = get_subscription_by_license($key);
    if (!$subscription) {
        echo json_encode([
            'ok' => false,
            'reason' => 'invalid_license_key',
        ]);
        exit;
    }
}

$payload = build_subscription_payload($subscription);
$features = $payload['features'] ?? [];

echo json_encode([
    'ok' => true,
    'active' => $payload['is_active'],
    'feature_flags' => $features,
    'license' => $payload,
]);
