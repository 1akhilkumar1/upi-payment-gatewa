<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = request_param_trim('token');
$licenseKey = request_param_trim('license_key');
$orderId = request_param_int('order_id', 0);
$action = request_param_trim('action');

$reason = null;
$subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);
if (!$subscription) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => $reason ?? 'no_subscription']);
    exit;
}

if ($orderId <= 0 || !in_array($action, ['approve','reject'], true)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'reason' => 'invalid_request']);
    exit;
}

$stmt = db()->prepare("SELECT * FROM payment_requests WHERE id = ? AND subscription_id = ? AND feature = 'link' LIMIT 1");
$stmt->execute([$orderId, $subscription['id']]);
$order = $stmt->fetch();
if (!$order) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'reason' => 'order_not_found']);
    exit;
}

$meta = payment_request_metadata($order);
$response = $order['response_json'] ? json_decode($order['response_json'], true) : [];
if (!is_array($response)) {
    $response = [];
}
$customerEmail = $meta['customer_email'] ?? '';
$linkSlug = $meta['link_slug'] ?? '';
$payerUpi = $response['payer_upi'] ?? ($meta['payer_upi'] ?? '');
$txnId = $order['txn_id'] ?? ($response['txn_id'] ?? ($meta['txn_id'] ?? ''));
$downloadUrl = '';

if ($linkSlug !== '' && !empty($order['subscription_id'])) {
    $stmt = db()->prepare("SELECT payload FROM hosted_links WHERE subscription_id = ? AND slug = ? LIMIT 1");
    $stmt->execute([$order['subscription_id'], $linkSlug]);
    $row = $stmt->fetch();
    if ($row && !empty($row['payload'])) {
        $payload = json_decode($row['payload'], true);
        if (is_array($payload)) {
            $downloadUrl = $payload['digital_file_url'] ?? '';
        }
    }
}

if ($action === 'approve') {
    mark_payment_request($orderId, 'completed', $txnId !== '' ? $txnId : null, ['user_approved' => true]);
    if (!empty($order['subscription_id'])) {
        $domain = $meta['domain'] ?? null;
        record_payment_sync(
            $subscription['id'],
            $subscription['user_id'],
            $subscription['license_key'],
            'manual',
            'link',
            (float)$order['amount'],
            $txnId,
            $payerUpi,
            ['order_id' => $order['id'], 'approved_by' => 'api'],
            ['email' => $customerEmail, 'phone' => $meta['customer_phone'] ?? null],
            $domain,
            $linkSlug
        );
        if ($linkSlug !== '') {
            mark_hosted_link_paid($subscription['id'], $linkSlug, (float)$order['amount'], $txnId, $payerUpi);
        }
    }
    if ($customerEmail !== '' && $downloadUrl !== '' && function_exists('licd_send_mail')) {
        $subject = 'Your download is ready';
        $body = '<p>Thanks for your payment.</p><p><a href="' . esc_url($downloadUrl) . '">Download your file</a></p>';
        licd_send_mail($customerEmail, $subject, $body);
        update_payment_request_metadata($orderId, ['download_sent' => true]);
    }
    echo json_encode(['ok' => true, 'status' => 'completed']);
    exit;
}

mark_payment_request($orderId, 'failed', $txnId !== '' ? $txnId : null, ['user_rejected' => true]);
if ($customerEmail !== '' && function_exists('licd_send_mail')) {
    $subject = 'Payment rejected';
    $body = '<p>Your payment could not be confirmed. Please contact the seller or retry the payment.</p>';
    licd_send_mail($customerEmail, $subject, $body);
}
echo json_encode(['ok' => true, 'status' => 'failed']);
