<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = request_param_trim('token');
$licenseKey = request_param_trim('license_key');
$feature = request_param_trim('feature');
$domain = request_param_trim('domain');

if (!$feature) {
    echo json_encode([
        'ok' => false,
        'allowed' => false,
        'reason' => 'missing_feature',
    ]);
    exit;
}

$reason = null;
$subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);

if (!$subscription) {
    echo json_encode([
        'ok' => false,
        'allowed' => false,
        'reason' => $reason ?? 'unavailable',
    ]);
    exit;
}

$payload = build_subscription_payload($subscription);
$allowed = true;
$domainAllowed = null;
$reason = 'granted';

if (!$payload['is_active']) {
    $allowed = false;
    $reason = 'subscription_not_active';
}

if ($allowed && !in_array($feature, $payload['plan']['features'], true)) {
    $allowed = false;
    $reason = 'feature_not_in_plan';
}

if ($allowed && $domain) {
    $domainAllowed = is_subscription_domain_allowed($subscription['id'], $domain);
    if (!$domainAllowed) {
        $allowed = false;
        $reason = 'domain_not_whitelisted';
    }
} elseif ($domain) {
    $domainAllowed = is_subscription_domain_allowed($subscription['id'], $domain);
}

echo json_encode([
    'ok' => true,
    'allowed' => $allowed,
    'reason' => $reason,
    'feature' => $feature,
    'domain' => $domain,
    'domain_allowed' => $domainAllowed,
    'license' => $payload,
]);
