<?php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

$dev = $_SERVER['HTTP_X_FG_DEV_TOKEN'] ?? '';
if ($dev === '' || !defined('LICD_DEV_KEY_TOKEN') || $dev !== LICD_DEV_KEY_TOKEN) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => 'forbidden']);
    exit;
}

$secret = get_app_hmac_secret();
echo json_encode([
    'ok' => true,
    'keys' => [
        'primary' => $secret,
    ],
]);
