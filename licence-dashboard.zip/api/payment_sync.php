<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = request_param_trim('token');
$licenseKey = request_param_trim('license_key');
$subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);

$payload = request_payload();
if (empty($payload)) {
    $payload = $_POST;
}

if (!$subscription) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => $reason ?? 'no_subscription']);
    exit;
}

$amount = request_param_float('amount', 0.0);
$feature = request_param_trim('feature', 'automations');
$txn = request_param_trim('txn_id', request_param_trim('transaction_id', ''));
$payer = request_param_trim('payer_vpa');
$domain = normalize_domain(request_param_trim('domain'));
$product = request_param_trim('product', request_param_trim('link_id', ''));
$source = request_param_trim('source');
$source = in_array($source, ['plugin', 'dashboard'], true) ? $source : 'app';
$customerPayload = request_param_array('customer', []);
$customer = [
    'email' => trim($customerPayload['email'] ?? request_param_trim('email')),
    'phone' => trim($customerPayload['phone'] ?? request_param_trim('phone')),
];

$paymentId = intval($payload['payment_id'] ?? 0);
$metadata = [];
foreach (['payload','metadata','note'] as $key) {
    if (!empty($payload[$key])) {
        $metadata[$key] = $payload[$key];
    }
}

$request = $paymentId ? get_payment_request($paymentId) : null;
if ($request && in_array($request['state'], ['pending','submitted'], true) && (int)$request['subscription_id'] === (int)$subscription['id']) {
    $candidates = payment_amount_candidates($amount);
    $picked = $amount > 0 ? pick_matching_amount((float)$request['amount'], $candidates) : null;
    if ($picked !== null) {
        mark_payment_request($paymentId, 'completed', $txn, $payload);
        $cycle = $request['cycle'] ?? 'monthly';
        $base = time();
        $validUntil = $cycle === 'yearly' ? date('Y-m-d H:i:s', strtotime('+1 year', $base)) : date('Y-m-d H:i:s', strtotime('+1 month', $base));
        set_subscription_validity($subscription['id'], $validUntil, 'active');
        create_payment_record(
            $subscription['id'],
            $picked,
            'upi',
            'completed',
            $feature === 'renewal' ? 'renewal' : 'initial',
            $payload,
            $request['currency'] ?? payment_gateway_currency(),
            $txn ?: null,
            current_timestamp()
        );
        if (function_exists('licd_log_event')) {
            licd_log_event('payment_sync_match', 'Payment sync matched request', [
                'payment_id' => $paymentId,
                'subscription_id' => $subscription['id'],
                'amount' => $picked,
                'txn' => $txn ? substr($txn, 0, 6) . '...' : '',
            ]);
        }
    }
}

record_payment_sync($subscription['id'], $subscription['user_id'], $subscription['license_key'], $source, $feature, $amount, $txn, $payer, $metadata, $customer, $domain, $product);

if (in_array($feature, ['automations','auto_confirm','renew'], true) && $amount > 0) {
    extend_subscription_validity($subscription['id']);
    update_subscription_status($subscription['id'], 'active');
    if (function_exists('licd_log_event')) {
        licd_log_event('payment_sync_extend', 'Subscription extended from payment sync', [
            'subscription_id' => $subscription['id'],
            'feature' => $feature,
            'amount' => $amount,
        ]);
    }
}

echo json_encode([
    'ok' => true,
    'subscriber' => $subscription['user_email'],
    'plan' => $subscription['plan_slug'],
    'valid_until' => get_active_subscription_for_user($subscription['user_id'])['valid_until'] ?? null,
]);
