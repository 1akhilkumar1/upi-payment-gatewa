<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = request_param_trim('token');
$licenseKey = request_param_trim('license_key');
$feature = request_param_trim('feature', 'renew');
$subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);

if (!$subscription) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => $reason ?? 'no_subscription']);
    exit;
}
$plan = $subscription['plan'];
$cycle = request_param_trim('cycle', 'monthly');
$amount = plan_price_for_cycle($plan, $cycle);
if (!$amount || $amount <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'reason' => 'invalid_amount']);
    exit;
}

$payload = create_payment_request(
    $subscription,
    'renewal',
    $amount,
    $cycle,
    $plan['slug'],
    ['cycle' => $cycle, 'expiry' => $subscription['valid_until']],
    null,
    $plan['name']
);
$response = [
    'ok' => true,
    'payment_id' => $payload['id'],
    'deeplink' => $payload['deeplink'],
    'amount' => number_format($payload['amount'], 2, '.', ''),
    'currency' => $payload['currency'],
    'feature' => 'renewal',
    'plan' => $plan,
    'cycle' => $cycle,
    'license' => build_subscription_payload($subscription),
];
if (!empty($payload['invoice'])) {
    $response['invoice'] = $payload['invoice'];
}
if (!empty($payload['discount'])) {
    $response['discount'] = $payload['discount'];
    $response['base_amount'] = $payload['base_amount'] ?? null;
}
echo json_encode($response);
