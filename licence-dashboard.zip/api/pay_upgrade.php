<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

$tokenValue = request_param_trim('token');
$licenseKey = request_param_trim('license_key');
$planSlug = request_param_trim('plan_slug');
$subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);

if (!$subscription) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'reason' => $reason ?? 'no_subscription']);
    exit;
}

$plan = null;
if ($planSlug) {
    $plan = get_plan_by_slug($planSlug);
}
$plan = $plan ?: $subscription['plan'];
$cycle = request_param_trim('cycle', 'monthly');
$amount = calculate_upgrade_amount($subscription['plan'], $plan, $cycle);
$amount += get_upgrade_fee();
if (!$amount || $amount <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'reason' => 'invalid_amount']);
    exit;
}

$payload = create_payment_request(
    $subscription,
    'upgrade',
    $amount,
    $cycle,
    $plan['slug'],
    ['cycle' => $cycle, 'target_plan' => $plan['slug']],
    null,
    $plan['name']
);
$response = [
    'ok' => true,
    'payment_id' => $payload['id'],
    'deeplink' => $payload['deeplink'],
    'amount' => number_format($payload['amount'], 2, '.', ''),
    'currency' => $payload['currency'],
    'feature' => 'upgrade',
    'plan' => $plan,
    'cycle' => $cycle,
    'license' => build_subscription_payload($subscription),
];
if (!empty($payload['invoice'])) {
    $response['invoice'] = $payload['invoice'];
}
if (!empty($payload['discount'])) {
    $response['discount'] = $payload['discount'];
    $response['base_amount'] = $payload['base_amount'] ?? null;
}
echo json_encode($response);
