<?php
/**
 * Plugin Name: eGo Licence Dashboard
 * Description: Embeds the eGo licence manager app inside WordPress (admin + frontend) using the WordPress database and email.
 * Version: 1.1.0
 * Author: Fourego
 */

if (!defined('ABSPATH')) {
    exit;
}

define('LICD_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LICD_PLUGIN_URL', plugin_dir_url(__FILE__));

// Basic logger to capture fatals during activation/load.
function licd_bootstrap_logging() {
    $logDir = LICD_PLUGIN_DIR . 'logs';
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    $logFile = $logDir . '/error.log';
    @ini_set('log_errors', 'On');
    @ini_set('error_log', $logFile);

    register_shutdown_function(function () use ($logFile) {
        $err = error_get_last();
        if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
            $entry = json_encode([
                'time' => gmdate('c'),
                'type' => $err['type'],
                'message' => $err['message'],
                'file' => $err['file'],
                'line' => $err['line'],
            ]);
            @file_put_contents($logFile, $entry . PHP_EOL, FILE_APPEND | LOCK_EX);
        }
    });
    // Log warnings/notices as JSON lines too.
    set_error_handler(function($severity, $message, $file, $line) use ($logFile) {
        // Respect @ operator.
        if (!(error_reporting() & $severity)) {
            return false;
        }
        $entry = json_encode([
            'time' => gmdate('c'),
            'type' => $severity,
            'message' => $message,
            'file' => $file,
            'line' => $line,
        ]);
        @file_put_contents($logFile, $entry . PHP_EOL, FILE_APPEND | LOCK_EX);
        return false; // let normal handling continue
    });
    @ini_set('display_errors', '0');
}
licd_bootstrap_logging();

// Bootstrap the app (DB + helpers + auth are WordPress-aware via config.php)
require_once LICD_PLUGIN_DIR . 'config.php';
require_once LICD_PLUGIN_DIR . 'api/helpers.php';

/**
 * App URL (public entry).
 */
function licd_app_url() {
    return trailingslashit(LICD_PLUGIN_URL . 'public');
}

function licd_register_link_rewrite() {
    add_rewrite_tag('%licd_link%', '([^&]+)');
    add_rewrite_rule('^link/([a-z0-9-]+)/?$', 'index.php?licd_link=$matches[1]', 'top');
}
add_action('init', 'licd_register_link_rewrite');

add_filter('query_vars', function($vars) {
    $vars[] = 'licd_link';
    return $vars;
});

add_action('template_redirect', function() {
    $slug = get_query_var('licd_link');
    if (!$slug) {
        return;
    }
    $_GET['slug'] = $slug;
    require LICD_PLUGIN_DIR . 'public/link.php';
    exit;
});

add_action('init', function() {
    $version = '1';
    if (get_option('licd_rewrite_version') !== $version) {
        licd_register_link_rewrite();
        flush_rewrite_rules();
        update_option('licd_rewrite_version', $version);
    }
});

function licd_push_gateway_license_status($status, $domains = []) {
    $token = get_setting('gateway_rest_token', '');
    $endpoint = trailingslashit(BASE_URL) . '/wp-json/fourego-upi/v1/license/sync';
    if (empty($token)) {
        return;
    }
    $payload = wp_json_encode([
        'status' => $status,
        'domains' => array_values(array_unique($domains)),
    ]);
    $args = [
        'headers' => [
            'Content-Type'     => 'application/json',
            'X-Fourego-Token'  => $token,
        ],
        'body'    => $payload,
        'timeout' => 8,
    ];
    wp_remote_post($endpoint, $args);
}
/**
 * Activation: ensure DB connectivity.
 */
function licd_activate() {
    try {
        $pdo = db();
        $pdo->query('SELECT 1');
    } catch (Throwable $e) {
        if (function_exists('licd_log_error')) {
            licd_log_error('Activation DB check failed', ['error' => $e->getMessage()]);
        }
        // Do not block activation; admin can review logs and configure DB/import schema.
    }
    if (!wp_next_scheduled('licd_daily_events')) {
        wp_schedule_event(time() + 3600, 'daily', 'licd_daily_events');
    }
    if (!wp_next_scheduled('licd_five_min_events')) {
        wp_schedule_event(time() + 300, 'five_minutes', 'licd_five_min_events');
    }
    licd_register_link_rewrite();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'licd_activate');
register_deactivation_hook(__FILE__, function() {
    wp_clear_scheduled_hook('licd_daily_events');
    wp_clear_scheduled_hook('licd_five_min_events');
});

add_filter('cron_schedules', function($schedules) {
    if (!isset($schedules['five_minutes'])) {
        $schedules['five_minutes'] = [
            'interval' => 300,
            'display' => 'Every 5 minutes',
        ];
    }
    return $schedules;
});

add_action('licd_five_min_events', function() {
    $minutes = (int)get_setting('domain_auto_approve_minutes', 5);
    if ($minutes <= 0) { $minutes = 5; }
    auto_approve_pending_domains($minutes);
});

/**
 * Register admin menu page.
 */
function licd_register_admin_menu() {
    add_menu_page(
        __('Licence Dashboard', 'licd'),
        __('Licence Dashboard', 'licd'),
        'manage_options',
        'licd-dashboard',
        'licd_render_admin_page',
        'dashicons-lock',
        56
    );
}
add_action('admin_menu', 'licd_register_admin_menu');

add_action('init', function() {
    if (!wp_next_scheduled('licd_daily_events')) {
        wp_schedule_event(time() + 3600, 'daily', 'licd_daily_events');
    }
    if (!wp_next_scheduled('licd_five_min_events')) {
        wp_schedule_event(time() + 300, 'five_minutes', 'licd_five_min_events');
    }
});

function licd_render_admin_page() {
    $src = licd_app_url() . 'index.php';
    ?>
    <div class="wrap" style="margin:0;padding:0;">
        <h1><?php esc_html_e('Licence Dashboard', 'licd'); ?></h1>
        <iframe src="<?php echo esc_url($src); ?>"
                style="width:100%;min-height:calc(100vh - 160px);border:0;background:#ffffff;"></iframe>
    </div>
    <?php
}

/**
 * Shortcode handler to embed the app on the frontend.
 */
function licd_shortcode_handler($atts) {
    $atts = shortcode_atts(
        [
            'height' => '900px',
        ],
        $atts,
        'licd_dashboard'
    );
    $src = licd_app_url() . 'index.php';
    ob_start();
    ?>
    <style>
        /* Make the embedded dashboard stretch edge-to-edge on the page */
        .licd-embed-wrapper {
            width: 100vw;
            margin-left: calc(50% - 50vw);
            max-width: 100vw;
            overflow: hidden;
        }
        .licd-embed-wrapper iframe {
            width: 100vw;
            min-height: 100vh;
            border: 0;
            background: #ffffff;
        }
    </style>
    <div class="licd-embed-wrapper">
        <iframe src="<?php echo esc_url($src); ?>"
                style="height:<?php echo esc_attr($atts['height']); ?>;"></iframe>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('licd_dashboard', 'licd_shortcode_handler');

/**
 * Basic enqueue for front-end pages using the shortcode (for consistency).
 */
function licd_enqueue_assets() {
    if (is_admin()) {
        return;
    }
    $post = get_post();
    if ($post && is_singular() && (
        has_shortcode($post->post_content ?? '', 'licd_dashboard') ||
        has_shortcode($post->post_content ?? '', 'licd_pricing')
    )) {
        wp_enqueue_style('licd-theme', LICD_PLUGIN_URL . 'public/assets/theme.css', [], '1.0.0');
    }
}
add_action('wp_enqueue_scripts', 'licd_enqueue_assets');

/**
 * Pricing shortcode to embed the hosted pricing page on the frontend.
 * Usage: [licd_pricing height="1200px"]
 */
function licd_pricing_shortcode($atts) {
    $atts = shortcode_atts(
        [
            'height' => '1200px',
        ],
        $atts,
        'licd_pricing'
    );
    $src = licd_app_url() . 'pricing.php';
    ob_start();
    ?>
    <div class="licd-embed-wrapper">
        <iframe src="<?php echo esc_url($src); ?>"
                style="width:100vw;min-height:100vh;border:0;background:#ffffff;height:<?php echo esc_attr($atts['height']); ?>;"></iframe>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('licd_pricing', 'licd_pricing_shortcode');

/**
 * Daily cron: send subscription reminders and expiry notices.
 */
add_action('licd_daily_events', function() {
    try {
        $pdo = db();
    } catch (Throwable $e) {
        if (function_exists('licd_log_error')) {
            licd_log_error('Cron DB fail', ['error' => $e->getMessage()]);
        }
        return;
    }
    $now = gmdate('Y-m-d H:i:s');
    $days = (int)get_setting('renewal_reminder_days', 2);
    if (!in_array($days, [2,3,7], true)) { $days = 2; }
    $soon = gmdate('Y-m-d H:i:s', strtotime('+' . $days . ' days'));

    // Track notifications to avoid spamming
    $pre_notified = get_option('licd_notified_pre', []);
    if (!is_array($pre_notified)) { $pre_notified = []; }
    $exp_notified = get_option('licd_notified_expired', []);
    if (!is_array($exp_notified)) { $exp_notified = []; }

    // Expiring soon (next 7 days)
    $stmt = $pdo->prepare("SELECT s.*, u.email AS user_email, u.name AS user_name FROM subscriptions s JOIN users u ON u.id = s.user_id WHERE s.valid_until IS NOT NULL AND s.status = 'active' AND s.valid_until <= ? AND s.valid_until >= ?");
    $stmt->execute([$soon, $now]);
    foreach ($stmt->fetchAll() as $sub) {
        $sid = $sub['id'];
        if (isset($pre_notified[$sid])) {
            continue;
        }
        licd_send_mail(
            $sub['user_email'],
            'Your subscription is expiring soon',
            '<p>Hi ' . esc_html($sub['user_name']) . ',</p><p>Your plan expires on ' . esc_html($sub['valid_until']) . '. Renew now to avoid interruption.</p>'
        );
        if (function_exists('licd_log_event')) {
            licd_log_event('renewal_reminder', 'Sent renewal reminder', [
                'subscription_id' => $sid,
                'email' => $sub['user_email'],
                'valid_until' => $sub['valid_until'],
                'renew_url' => function_exists('licd_public_url') ? licd_public_url('pricing.php') : '',
            ]);
        }
        $pre_notified[$sid] = $now;
    }
    update_option('licd_notified_pre', $pre_notified, false);

    // Expired
    $stmt2 = $pdo->prepare("SELECT s.*, u.email AS user_email, u.name AS user_name FROM subscriptions s JOIN users u ON u.id = s.user_id WHERE s.valid_until IS NOT NULL AND s.status = 'active' AND s.valid_until < ?");
    $stmt2->execute([$now]);
    foreach ($stmt2->fetchAll() as $sub) {
        $sid = $sub['id'];
        if (isset($exp_notified[$sid])) {
            continue;
        }
        licd_send_mail(
            $sub['user_email'],
            'Your subscription has expired',
            '<p>Hi ' . esc_html($sub['user_name']) . ',</p><p>Your plan expired on ' . esc_html($sub['valid_until']) . '. Renew to restore access.</p>'
        );
        $exp_notified[$sid] = $now;
    }
    update_option('licd_notified_expired', $exp_notified, false);
});

/**
 * REST endpoints (WP-native wrappers around core API flows).
 */
function licd_register_rest() {
    register_rest_route(
        'licd/v1',
        '/login',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_login',
            'permission_callback' => '__return_true',
        ]
    );

    register_rest_route(
        'licd/v1',
        '/license-info',
        [
            'methods'             => 'GET',
            'callback'            => 'licd_rest_license_info',
            'permission_callback' => '__return_true',
        ]
    );

    register_rest_route(
        'licd/v1',
        '/payment-sync',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_payment_sync',
            'permission_callback' => '__return_true',
        ]
    );

    register_rest_route(
        'licd/v1',
        '/pay-request',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_pay_request',
            'permission_callback' => '__return_true',
        ]
    );

    register_rest_route(
        'licd/v1',
        '/check-access',
        [
            'methods'             => 'GET',
            'callback'            => 'licd_rest_check_access',
            'permission_callback' => '__return_true',
        ]
    );

    register_rest_route(
        'licd/v1',
        '/link/create',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_link_create',
            'permission_callback' => '__return_true',
        ]
    );

    register_rest_route(
        'licd/v1',
        '/link/event',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_link_event',
            'permission_callback' => '__return_true',
        ]
    );

    register_rest_route(
        'licd/v1',
        '/link/stats',
        [
            'methods'             => 'GET',
            'callback'            => 'licd_rest_link_stats',
            'permission_callback' => '__return_true',
        ]
    );

    register_rest_route(
        'licd/v1',
        '/pay/feature',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_pay_feature',
            'permission_callback' => '__return_true',
        ]
    );

    register_rest_route(
        'licd/v1',
        '/pay/renew',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_pay_renew',
            'permission_callback' => '__return_true',
        ]
    );

    register_rest_route(
        'licd/v1',
        '/pay/subscription',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_pay_subscription',
            'permission_callback' => '__return_true',
        ]
    );

    register_rest_route(
        'licd/v1',
        '/pay/upgrade',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_pay_upgrade',
            'permission_callback' => '__return_true',
        ]
    );

    // HMAC-signed payment sync for Android app (fourego://connect)
    register_rest_route(
        'fourego/v1',
        '/payment-sync',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_payment_sync_hmac',
            'permission_callback' => '__return_true',
        ]
    );
    register_rest_route(
        'fourego/v1',
        '/ping',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_fourego_ping',
            'permission_callback' => '__return_true',
        ]
    );
    register_rest_route(
        'fourego/v1',
        '/notify',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_fourego_notify',
            'permission_callback' => '__return_true',
        ]
    );
    register_rest_route(
        'fourego/v1',
        '/summary',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_fourego_summary',
            'permission_callback' => '__return_true',
        ]
    );
    register_rest_route(
        'fourego/v1',
        '/license',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_fourego_license',
            'permission_callback' => '__return_true',
        ]
    );
    register_rest_route(
        'fourego/v1',
        '/keyset',
        [
            'methods'             => 'GET',
            'callback'            => 'licd_rest_keyset',
            'permission_callback' => '__return_true',
        ]
    );
    register_rest_route(
        'fourego/v1',
        '/push-relay',
        [
            'methods'             => 'POST',
            'callback'            => 'licd_rest_push_relay',
            'permission_callback' => '__return_true',
        ]
    );
}
add_action('rest_api_init', 'licd_register_rest');

function licd_rest_login(WP_REST_Request $request) {
    $email = sanitize_email($request->get_param('email'));
    $password = (string) $request->get_param('password');
    if (empty($email) || empty($password)) {
        return new WP_Error('licd_missing_creds', __('Email and password are required.', 'licd'), ['status' => 400]);
    }
    $user = attempt_login($email, $password);
    if (!$user) {
        return new WP_Error('licd_invalid_creds', __('Invalid credentials.', 'licd'), ['status' => 401]);
    }
    $token = create_api_token_for_user($user['id']);
    return rest_ensure_response([
        'ok'    => true,
        'token' => $token,
        'user'  => [
            'id'    => $user['id'],
            'email' => $user['email'],
            'name'  => $user['name'],
            'role'  => $user['role'],
        ],
    ]);
}

function licd_rest_license_info(WP_REST_Request $request) {
    $tokenValue = $request->get_param('token');
    $licenseKey = $request->get_param('license_key');

    if (!$tokenValue && !$licenseKey) {
        return new WP_Error('licd_missing_token', __('Token or license_key is required.', 'licd'), ['status' => 400]);
    }

    $subscription = null;
    if ($tokenValue) {
    $token = licd_get_api_token($tokenValue);
        if (!$token) {
            return new WP_Error('licd_invalid_token', __('Invalid token.', 'licd'), ['status' => 401]);
        }
        $subscription = get_last_subscription_for_user($token['user_id']);
        if (!$subscription) {
            return rest_ensure_response([
                'ok'      => true,
                'active'  => false,
                'reason'  => 'no_subscription_found',
            ]);
        }
    } else {
        $key = strtoupper(trim((string)$licenseKey));
        if ($key === '') {
            return new WP_Error('licd_invalid_license', __('Invalid license key.', 'licd'), ['status' => 400]);
        }
        $subscription = get_subscription_by_license($key);
        if (!$subscription) {
            return new WP_Error('licd_invalid_license', __('Invalid license key.', 'licd'), ['status' => 404]);
        }
    }

    $payload = build_subscription_payload($subscription);
    return rest_ensure_response([
        'ok'            => true,
        'active'        => $payload['is_active'],
        'feature_flags' => $payload['features'] ?? [],
        'license'       => $payload,
    ]);
}

function licd_rest_payment_sync(WP_REST_Request $request) {
    $license = strtoupper(trim((string)$request->get_param('license_key')));
    $txn     = sanitize_text_field($request->get_param('txn_id'));
    $amount  = floatval($request->get_param('amount'));
    $payer   = sanitize_text_field($request->get_param('payer_vpa'));
    $feature = sanitize_text_field($request->get_param('feature') ?: 'license');
    $source  = sanitize_text_field($request->get_param('source') ?: 'wp');
    if (empty($license) || empty($txn) || $amount <= 0) {
        return new WP_Error('licd_bad_payload', __('Missing or invalid payment data.', 'licd'), ['status' => 400]);
    }
    $subscription = get_subscription_by_license($license);
    if (!$subscription) {
        // Try to match by request/token later; for now fail if unknown license.
        return new WP_Error('licd_invalid_license', __('License not found.', 'licd'), ['status' => 404]);
    }
    record_payment_sync(
        $subscription['id'],
        $subscription['user_id'],
        $license,
        $source,
        $feature,
        $amount,
        $txn,
        $payer,
        $request->get_param('metadata') ?? null,
        [
            'email' => $request->get_param('customer_email'),
            'phone' => $request->get_param('customer_phone'),
        ],
        $request->get_param('domain'),
        $request->get_param('product')
    );
    $product = $request->get_param('product');
    if (!empty($product)) {
        try {
            mark_hosted_link_paid($subscription['id'], $product, $amount, $txn, $payer);
        } catch (Throwable $e) {
            // Best-effort; do not block sync
        }
    }
    // If this matches a pending payment request, mark it completed and activate the plan.
    $matched = mark_matching_payment_request_completed($subscription['id'], $txn, $payer, $amount);
    if ($matched) {
        $meta = !empty($matched['metadata']) ? json_decode($matched['metadata'], true) : [];
        if (is_array($meta) && !empty($meta['product'])) {
            try {
                mark_hosted_link_paid($subscription['id'], $meta['product'], $amount, $txn, $payer);
            } catch (Throwable $e) {
                // best-effort
            }
        }
        if (!empty($matched['subscription_id'])) {
            activate_subscription_from_payment($subscription['id'], $matched['cycle'] ?? 'monthly');
        } else {
            $newId = ensure_subscription_from_request($matched);
            if ($newId) {
                db()->prepare("UPDATE payment_requests SET subscription_id = ? WHERE id = ?")->execute([$newId, $matched['id']]);
            }
        }
    }
    return rest_ensure_response(['ok' => true]);
}

/**
 * HMAC entrypoint expected by the Android app (fourego://connect).
 */
function licd_rest_payment_sync_hmac(WP_REST_Request $request) {
    $secret = get_app_hmac_secret();
    $raw = $request->get_body();
    $sig = $request->get_header('x-fg-signature');
    if (empty($secret) || empty($sig)) {
        return new WP_Error('licd_hmac_missing', __('Signature missing.', 'licd'), ['status' => 401]);
    }
    $computed = base64_encode(hash_hmac('sha256', $raw, $secret, true));
    if (!hash_equals($computed, $sig)) {
        return new WP_Error('licd_hmac_bad', __('Invalid signature.', 'licd'), ['status' => 401]);
    }
    // Proxy to main payment sync handler
    return licd_rest_payment_sync($request);
}

function licd_verify_fourego_signature(WP_REST_Request $request) {
    $raw = $request->get_body();
    $sig = $request->get_header('x-fg-signature');
    $keyId = $request->get_header('x-fg-key-id');
    $userId = $request->get_header('x-fg-user-id');
    if ($userId) {
        $userKey = get_user_app_key((int)$userId);
        if ($userKey && !empty($userKey['secret'])) {
            $computed = base64_encode(hash_hmac('sha256', $raw, $userKey['secret'], true));
            if (hash_equals($computed, $sig)) {
                return ['ok' => true, 'user_id' => (int)$userId, 'scope' => 'user'];
            }
        }
    }
    if (!empty($keyId)) {
        $userKey = get_user_app_key_by_key_id($keyId);
        if ($userKey && !empty($userKey['secret'])) {
            $computed = base64_encode(hash_hmac('sha256', $raw, $userKey['secret'], true));
            if (hash_equals($computed, $sig)) {
                return ['ok' => true, 'user_id' => (int)$userKey['user_id'], 'scope' => 'user'];
            }
        }
    }
    $keys = licd_get_app_keyring();
    foreach ($keys as $id => $secret) {
        if (!empty($keyId) && $keyId !== $id) {
            continue;
        }
        if (empty($secret)) {
            continue;
        }
        $computed = base64_encode(hash_hmac('sha256', $raw, $secret, true));
        if (hash_equals($computed, $sig)) {
            return ['ok' => true, 'user_id' => null, 'scope' => 'admin'];
        }
    }
    return false;
}

function licd_rest_fourego_ping(WP_REST_Request $request) {
    $verified = licd_verify_fourego_signature($request);
    if (!$verified) {
        return new WP_Error('licd_hmac_bad', __('Invalid signature.', 'licd'), ['status' => 401]);
    }
    $device = $request->get_header('x-fg-device');
    if (!empty($verified['user_id'])) {
        update_user_app_ping((int)$verified['user_id'], $device ?: '');
    } else {
        update_option('licd_last_app_ping', [
            'ts' => time(),
            'device' => $device ?: '',
        ], false);
    }
    $latestOut = null;
    if (!empty($verified['user_id'])) {
        $latest = latest_pending_payment_request_for_user((int)$verified['user_id'], ['link']);
    } else {
        $latest = latest_pending_payment_request();
    }
    if ($latest) {
        $meta = payment_request_metadata($latest);
        $invoice = $meta['invoice'] ?? '';
        $label = $invoice ?: ('PAY-' . $latest['id']);
        $latestOut = [
            'id' => (string)$latest['id'],
            'number' => (string)$label,
            'status' => $latest['state'],
            'total' => (float)$latest['amount'],
            'currency' => $latest['currency'] ?? payment_gateway_currency(),
            'created_at' => $latest['created_at'] ?? null,
            'merchant_vpa' => !empty($meta['merchant_upi']) ? $meta['merchant_upi'] : get_payment_gateway_upi(),
        ];
    }
    return rest_ensure_response([
        'ok' => true,
        'merchant_vpa' => get_payment_gateway_upi(),
        'merchant_name' => get_payment_gateway_name(),
        'latest_order' => $latestOut,
        'armed_link' => null,
    ]);
}

function licd_rest_fourego_notify(WP_REST_Request $request) {
    $verified = licd_verify_fourego_signature($request);
    if (!$verified) {
        return new WP_Error('licd_hmac_bad', __('Invalid signature.', 'licd'), ['status' => 401]);
    }
    $data = json_decode($request->get_body(), true) ?: [];
    $amount = floatval($data['amount'] ?? 0);
    $txn    = sanitize_text_field($data['utr'] ?? $data['txn_id'] ?? '');
    $payer  = sanitize_text_field($data['payer_vpa'] ?? '');
    $allowed = null;
    if (!empty($verified['user_id'])) {
        $allowed = ['link'];
    } else {
        $allowed = ['subscription', 'renewal', 'upgrade', 'domain', 'landing_link'];
    }
    $matched = mark_matching_payment_request_completed(null, $txn, $payer, $amount, $verified['user_id'] ?? null, $allowed);
    if ($matched) {
        $meta = !empty($matched['metadata']) ? json_decode($matched['metadata'], true) : [];
        if (is_array($meta) && !empty($meta['product']) && !empty($matched['subscription_id'])) {
            try {
                mark_hosted_link_paid($matched['subscription_id'], $meta['product'], $amount, $txn, $payer);
            } catch (Throwable $e) {
                // best-effort
            }
        }
        if (!empty($matched['subscription_id'])) {
            activate_subscription_from_payment($matched['subscription_id'], $matched['cycle'] ?? 'monthly');
        } else {
            $newId = ensure_subscription_from_request($matched);
            if ($newId) {
                db()->prepare("UPDATE payment_requests SET subscription_id = ? WHERE id = ?")->execute([$newId, $matched['id']]);
            }
        }
    }
    return rest_ensure_response(['ok' => true]);
}

function licd_rest_fourego_summary(WP_REST_Request $request) {
    $verified = licd_verify_fourego_signature($request);
    if (!$verified) {
        return new WP_Error('licd_hmac_bad', __('Invalid signature.', 'licd'), ['status' => 401]);
    }
    $pdo = db();
    if (!empty($verified['user_id'])) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM payment_sync_logs WHERE user_id = ?");
        $stmt->execute([(int)$verified['user_id']]);
        $totalPayments = $stmt->fetchColumn();
        $stmt2 = $pdo->prepare("SELECT COUNT(*) FROM payment_requests WHERE state IN ('pending','submitted') AND user_id = ?");
        $stmt2->execute([(int)$verified['user_id']]);
        $pendingReqs = $stmt2->fetchColumn();
    } else {
        $totalPayments = $pdo->query("SELECT COUNT(*) FROM payment_sync_logs")->fetchColumn();
        $pendingReqs = $pdo->query("SELECT COUNT(*) FROM payment_requests WHERE state IN ('pending','submitted')")->fetchColumn();
    }
    return rest_ensure_response([
        'ok' => true,
        'payments' => intval($totalPayments),
        'pending_requests' => intval($pendingReqs),
    ]);
}

function licd_rest_fourego_license(WP_REST_Request $request) {
    $verified = licd_verify_fourego_signature($request);
    if (!$verified || empty($verified['user_id'])) {
        return new WP_Error('licd_hmac_bad', __('Invalid signature.', 'licd'), ['status' => 401]);
    }
    $subscription = get_last_subscription_for_user((int)$verified['user_id']);
    if (!$subscription) {
        return new WP_Error('licd_no_subscription', __('Subscription not found.', 'licd'), ['status' => 404]);
    }
    $payload = build_subscription_payload($subscription);
    return rest_ensure_response([
        'ok'            => true,
        'active'        => !empty($payload['is_active']),
        'feature_flags' => $payload['features'] ?? [],
        'license'       => $payload,
    ]);
}

function licd_get_app_keyring() {
    // Keyring stored as option: key_id => secret
    $ring = get_option('licd_app_keyring', []);
    if (!is_array($ring)) {
        $ring = [];
    }
    // Always include current secret as fallback
    $current = get_app_hmac_secret();
    if (!empty($current) && !in_array($current, $ring, true)) {
        $ring['primary'] = $current;
    }
    return $ring;
}

function licd_rest_keyset(WP_REST_Request $request) {
    // For dev convenience we allow a static dev token OR HMAC auth
    $devToken = $request->get_header('x-fg-dev-token');
    $devAllowed = defined('LICD_DEV_KEY_TOKEN') ? LICD_DEV_KEY_TOKEN : null;
    if (!$devToken || $devToken !== $devAllowed) {
        if (!licd_verify_fourego_signature($request)) {
            return new WP_Error('licd_hmac_bad', __('Invalid signature.', 'licd'), ['status' => 401]);
        }
    }
    $ring = licd_get_app_keyring();
    return rest_ensure_response([
        'ok' => true,
        'keys' => $ring,
    ]);
}

/**
 * Relay a push payload to FCM using the service account stored on the licence server.
 * Expects body: { tokens: [string], data: { ... } } signed with HMAC (x-fg-signature).
 */
function licd_rest_push_relay(WP_REST_Request $request) {
    if (!licd_verify_fourego_signature($request)) {
        return new WP_Error('licd_hmac_bad', __('Invalid signature.', 'licd'), ['status' => 401]);
    }
    $payload = json_decode($request->get_body(), true);
    if (!is_array($payload)) {
        return new WP_Error('licd_bad_json', __('Invalid JSON.', 'licd'), ['status' => 400]);
    }
    $tokens = isset($payload['tokens']) && is_array($payload['tokens']) ? array_filter(array_map('strval', $payload['tokens'])) : [];
    $data   = isset($payload['data']) && is_array($payload['data']) ? $payload['data'] : [];
    if (empty($tokens) || empty($data)) {
        return new WP_Error('licd_missing_fields', __('Tokens or data missing.', 'licd'), ['status' => 400]);
    }
    $sa = licd_fcm_load_service_account();
    if (!$sa) {
        return new WP_Error('licd_fcm_missing', __('Service account not configured.', 'licd'), ['status' => 500]);
    }
    $access = licd_fcm_access_token($sa);
    if (empty($access)) {
        return new WP_Error('licd_fcm_token_fail', __('Could not obtain FCM access token.', 'licd'), ['status' => 500]);
    }
    $project = isset($sa['project_id']) ? $sa['project_id'] : '';
    if (empty($project)) {
        return new WP_Error('licd_fcm_project_missing', __('Project ID missing in service account.', 'licd'), ['status' => 500]);
    }
    $sent = 0; $errors = [];
    foreach ($tokens as $t) {
        $msg = [
            'message' => [
                'token' => $t,
                'data'  => array_map('strval', $data),
            ],
        ];
        $resp = wp_remote_post(
            'https://fcm.googleapis.com/v1/projects/' . rawurlencode($project) . '/messages:send',
            [
                'timeout' => 8,
                'headers' => [
                    'Authorization' => 'Bearer ' . $access,
                    'Content-Type'  => 'application/json',
                ],
                'body'    => wp_json_encode($msg),
            ]
        );
        if (!is_wp_error($resp) && wp_remote_retrieve_response_code($resp) >= 200 && wp_remote_retrieve_response_code($resp) < 300) {
            $sent++;
        } else {
            $errors[] = is_wp_error($resp) ? $resp->get_error_message() : ('HTTP ' . wp_remote_retrieve_response_code($resp));
        }
    }
    return rest_ensure_response(['ok' => $sent > 0, 'sent' => $sent, 'errors' => $errors]);
}

/**
 * Load FCM service account JSON from a secure path or URL (define LICD_FCM_SERVICE_ACCOUNT).
 */
function licd_fcm_load_service_account() {
    $path = defined('LICD_FCM_SERVICE_ACCOUNT') ? LICD_FCM_SERVICE_ACCOUNT : '';
    if (empty($path)) {
        return null;
    }
    $json = '';
    if (0 === strpos($path, 'http')) {
        $resp = wp_remote_get($path, ['timeout' => 8]);
        if (is_wp_error($resp)) { return null; }
        $json = wp_remote_retrieve_body($resp);
    } elseif (file_exists($path)) {
        $json = file_get_contents($path);
    }
    if (empty($json)) {
        return null;
    }
    $data = json_decode($json, true);
    return is_array($data) ? $data : null;
}

/**
 * Generate an OAuth2 access token for FCM using a service account.
 */
function licd_fcm_access_token($sa) {
    if (empty($sa['client_email']) || empty($sa['private_key'])) {
        return '';
    }
    $iat = time();
    $exp = $iat + 3600;
    $jwt_header = rtrim(strtr(base64_encode(wp_json_encode(['alg' => 'RS256', 'typ' => 'JWT'])), '+/', '-_'), '=');
    $jwt_claims = rtrim(strtr(base64_encode(wp_json_encode([
        'iss'   => $sa['client_email'],
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
        'aud'   => 'https://oauth2.googleapis.com/token',
        'iat'   => $iat,
        'exp'   => $exp,
    ])), '+/', '-_'), '=');
    $base = $jwt_header . '.' . $jwt_claims;
    $signature = '';
    openssl_sign($base, $signature, $sa['private_key'], 'sha256WithRSAEncryption');
    if (empty($signature)) {
        return '';
    }
    $jwt = $base . '.' . rtrim(strtr(base64_encode($signature), '+/', '-_'), '=');
    $resp = wp_remote_post(
        'https://oauth2.googleapis.com/token',
        [
            'timeout' => 8,
            'body'    => [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion'  => $jwt,
            ],
        ]
    );
    if (is_wp_error($resp)) {
        return '';
    }
    $body = json_decode(wp_remote_retrieve_body($resp), true);
    return isset($body['access_token']) ? $body['access_token'] : '';
}

function licd_rest_pay_request(WP_REST_Request $request) {
    $tokenValue    = sanitize_text_field($request->get_param('token'));
    $licenseKey    = sanitize_text_field($request->get_param('license_key'));
    $feature       = sanitize_text_field($request->get_param('feature') ?: 'subscription');
    $planSlug      = sanitize_text_field($request->get_param('plan_slug'));
    $cycle         = sanitize_text_field($request->get_param('cycle') ?: 'monthly');
    $quantity      = max(1, intval($request->get_param('quantity') ?: 1));
    $callbackUrl   = sanitize_text_field($request->get_param('callback_url'));
    $amountOverride= floatval($request->get_param('amount') ?: 0.0);
    $metadata      = $request->get_param('metadata');
    if (!is_array($metadata)) { $metadata = []; }

    $reason = null;
    $subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);
    if (!$subscription) {
        return new WP_Error('licd_no_subscription', $reason ?: __('Subscription not found.', 'licd'), ['status' => 403]);
    }

    $plan = $planSlug ? get_plan_by_slug($planSlug) : null;
    if (!$plan) {
        $plan = $subscription['plan'];
    }

    $amount = 0.0;
    switch ($feature) {
        case 'subscription':
        case 'renewal':
            $amount = plan_price_for_cycle($plan, $cycle);
            break;
        case 'upgrade':
            $amount = calculate_upgrade_amount($subscription['plan'], $plan, $cycle);
            $amount += function_exists('get_upgrade_fee') ? get_upgrade_fee() : 0;
            break;
        case 'domain':
            $amount = (function_exists('get_extra_domain_fee') ? get_extra_domain_fee() : 0) * $quantity;
            break;
        case 'landing_link':
        case 'link':
            $amount = (function_exists('get_extra_link_fee') ? get_extra_link_fee() : 0) * $quantity;
            break;
        default:
            return new WP_Error('licd_unknown_feature', __('Unknown feature.', 'licd'), ['status' => 400]);
    }

    if ($amountOverride > 0) {
        $amount = $amountOverride;
    }
    if ($amount <= 0) {
        return new WP_Error('licd_invalid_amount', __('Invalid amount.', 'licd'), ['status' => 400]);
    }

    $payload = create_payment_request(
        $subscription,
        $feature,
        $amount,
        $cycle,
        $plan['slug'],
        $metadata ?: null,
        $callbackUrl ?: null,
        $plan['name'] ?? $feature
    );

    $response = [
        'ok'         => true,
        'payment_id' => $payload['id'],
        'deeplink'   => $payload['deeplink'],
        'amount'     => number_format($payload['amount'], 2, '.', ''),
        'currency'   => $payload['currency'],
        'feature'    => $feature,
        'plan'       => $plan,
        'cycle'      => $cycle,
        'license'    => build_subscription_payload($subscription),
    ];
    if ($callbackUrl) {
        $response['callback_url'] = $callbackUrl;
    }
    return rest_ensure_response($response);
}

function licd_rest_check_access(WP_REST_Request $request) {
    $tokenValue = sanitize_text_field($request->get_param('token'));
    $licenseKey = sanitize_text_field($request->get_param('license_key'));
    $feature    = sanitize_text_field($request->get_param('feature'));
    $domain     = sanitize_text_field($request->get_param('domain'));

    if (empty($feature)) {
        return rest_ensure_response([
            'ok' => false,
            'allowed' => false,
            'reason' => 'missing_feature',
        ]);
    }

    $reason = null;
    $subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);
    if (!$subscription) {
        return rest_ensure_response([
            'ok' => false,
            'allowed' => false,
            'reason' => $reason ?? 'unavailable',
        ]);
    }

    $payload = build_subscription_payload($subscription);
    $allowed = true;
    $domainAllowed = null;
    $why = 'granted';

    if (!$payload['is_active']) {
        $allowed = false;
        $why = 'subscription_not_active';
    }

    if ($allowed && !in_array($feature, $payload['plan']['features'], true)) {
        $allowed = false;
        $why = 'feature_not_in_plan';
    }

    if ($allowed && $domain) {
        $domainAllowed = is_subscription_domain_allowed($subscription['id'], $domain);
        if (!$domainAllowed) {
            $allowed = false;
            $why = 'domain_not_whitelisted';
        }
    } elseif ($domain) {
        $domainAllowed = is_subscription_domain_allowed($subscription['id'], $domain);
    }

    return rest_ensure_response([
        'ok' => true,
        'allowed' => $allowed,
        'reason' => $why,
        'feature' => $feature,
        'domain' => $domain,
        'domain_allowed' => $domainAllowed,
        'license' => $payload,
    ]);
}

function licd_rest_link_create(WP_REST_Request $request) {
    $tokenValue = sanitize_text_field($request->get_param('token'));
    $licenseKey = sanitize_text_field($request->get_param('license_key'));

    $subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);
    if (!$subscription) {
        return new WP_Error('licd_no_subscription', $reason ?? 'no_subscription', ['status' => 403]);
    }

    if (empty($subscription['plan']['features']) || !in_array('landing_builder', $subscription['plan']['features'], true)) {
        return new WP_Error('licd_feature_missing', 'feature_missing', ['status' => 403]);
    }

    $plan = $subscription['plan'];
    $linksLimit = intval($plan['payment_links_limit'] ?? 0);
    if ($linksLimit > 0 && count_hosted_links($subscription['id']) >= $linksLimit) {
        return new WP_Error('licd_links_limit', 'links_limit_reached', ['status' => 403]);
    }

    $title = sanitize_text_field($request->get_param('title'));
    $amount = floatval($request->get_param('amount') ?: 0.0);
    $description = sanitize_textarea_field($request->get_param('description'));
    $purpose = sanitize_text_field($request->get_param('purpose'));
    $domain = normalize_domain($request->get_param('domain'));
    $image = esc_url_raw($request->get_param('image_url'));
    $fields = $request->get_param('fields');
    if (!is_array($fields)) { $fields = []; }

    if ($domain !== '') {
        $reason = null;
        if (!request_domain_for_subscription($subscription['id'], $domain, $reason)) {
            return new WP_Error('licd_domain', $reason ?: 'domain_error', ['status' => 403]);
        }
    }

    if ($title === '' || $amount <= 0) {
        return new WP_Error('licd_invalid_payload', 'invalid_payload', ['status' => 400]);
    }

    $slug = create_hosted_link($subscription['id'], $subscription['user_id'], $title, $description, $amount, $purpose, $image, $domain ?: DEFAULT_HOSTED_DOMAIN, $fields);
    if (!$slug) {
        return new WP_Error('licd_create_failed', 'unable_to_create', ['status' => 500]);
    }

    $baseDomain = $domain ?: DEFAULT_HOSTED_DOMAIN;
    $url = rtrim($baseDomain, '/') . '/link/' . urlencode($slug);

    return rest_ensure_response([
        'ok' => true,
        'url' => $url,
        'link_id' => $slug,
        'plan' => $plan,
        'license' => build_subscription_payload($subscription),
    ]);
}

function licd_rest_link_event(WP_REST_Request $request) {
    $tokenValue = sanitize_text_field($request->get_param('token'));
    $licenseKey = sanitize_text_field($request->get_param('license_key'));
    $linkId     = sanitize_text_field($request->get_param('link_id'));
    if ($linkId === '') {
        return new WP_Error('licd_missing_link', 'missing_link_id', ['status' => 400]);
    }

    $reason = null;
    $subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);
    if (!$subscription) {
        return new WP_Error('licd_no_subscription', $reason ?? 'no_subscription', ['status' => 403]);
    }

    $stmt = db()->prepare("SELECT * FROM hosted_links WHERE subscription_id = ? AND slug = ? LIMIT 1");
    $stmt->execute([$subscription['id'], $linkId]);
    $link = $stmt->fetch();
    if (!$link) {
        return new WP_Error('licd_link_not_found', 'link_not_found', ['status' => 404]);
    }

    $stmt = db()->prepare("INSERT INTO payment_sync_logs (subscription_id, user_id, license_key, source, feature, amount, txn_id, payer_vpa, customer_email, customer_phone, domain, product, metadata, recorded_at)
                           VALUES (?, ?, ?, 'app', 'link_view', 0, NULL, NULL, NULL, NULL, ?, ?, ?, NOW())");
    $meta = json_encode(['event' => 'render']);
    $stmt->execute([
        $subscription['id'],
        $subscription['user_id'],
        $subscription['license_key'],
        $link['domain'] ?: DEFAULT_HOSTED_DOMAIN,
        $linkId,
        $meta,
    ]);

    return rest_ensure_response(['ok' => true]);
}

function licd_rest_link_stats(WP_REST_Request $request) {
    $tokenValue = sanitize_text_field($request->get_param('token'));
    $licenseKey = sanitize_text_field($request->get_param('license_key'));

    $reason = null;
    $subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);
    if (!$subscription) {
        return new WP_Error('licd_no_subscription', $reason ?? 'no_subscription', ['status' => 403]);
    }

    $stmt = db()->prepare("SELECT * FROM hosted_links WHERE subscription_id = ? ORDER BY created_at DESC");
    $stmt->execute([$subscription['id']]);
    $links = $stmt->fetchAll();

    $stats = [];
    $sql = "SELECT product,
                   SUM(CASE WHEN feature = 'link_view' THEN 1 ELSE 0 END) AS views,
                   SUM(CASE WHEN feature <> 'link_view' THEN 1 ELSE 0 END) AS payments,
                   SUM(CASE WHEN feature <> 'link_view' THEN amount ELSE 0 END) AS revenue,
                   MAX(CASE WHEN feature <> 'link_view' THEN recorded_at ELSE NULL END) AS last_paid
            FROM payment_sync_logs
            WHERE subscription_id = ? AND product IS NOT NULL AND product <> ''
            GROUP BY product";
    $st = db()->prepare($sql);
    $st->execute([$subscription['id']]);
    foreach ($st->fetchAll() as $row) {
        $stats[$row['product']] = $row;
    }

    $out = [];
    foreach ($links as $link) {
        $slug = $link['slug'];
        $base = $link['domain'] ?: DEFAULT_HOSTED_DOMAIN;
        $base = rtrim($base, '/');
        $url = $base . '/link/' . $slug;
        $st = $stats[$slug] ?? ['views' => 0, 'payments' => 0, 'revenue' => 0, 'last_paid' => null];
        $out[] = [
            'link_id'    => $slug,
            'title'      => $link['title'],
            'amount'     => (float) $link['amount'],
            'status'     => $link['status'],
            'url'        => $url,
            'views'      => (int) $st['views'],
            'payments'   => (int) $st['payments'],
            'revenue'    => (float) $st['revenue'],
            'last_paid'  => $st['last_paid'],
            'created_at' => $link['created_at'],
        ];
    }

    return rest_ensure_response([
        'ok' => true,
        'links' => $out,
    ]);
}

function licd_rest_pay_feature(WP_REST_Request $request) {
    $tokenValue = sanitize_text_field($request->get_param('token'));
    $licenseKey = sanitize_text_field($request->get_param('license_key'));
    $feature    = sanitize_text_field($request->get_param('feature') ?? '');
    $quantity   = max(1, intval($request->get_param('quantity') ?? 1));
    $subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);

    if (!$subscription) {
        return new WP_Error('licd_no_subscription', $reason ?? 'no_subscription', ['status' => 403]);
    }

    switch ($feature) {
        case 'domain':
            $fee = get_extra_domain_fee();
            $title = 'Add domain request';
            $purpose = 'Domain whitelist fee';
            break;
        case 'landing_link':
        case 'link':
            $feature = 'landing_link';
            $fee = get_extra_link_fee();
            $title = 'Add landing link';
            $purpose = 'Landing page fee';
            break;
        default:
            return new WP_Error('licd_unknown_feature', 'unknown_feature', ['status' => 400]);
    }

    $amount = $fee * $quantity;
    if ($amount <= 0) {
        return new WP_Error('licd_invalid_amount', 'invalid_amount', ['status' => 400]);
    }

    $metadata = [];
    $domainParam = $request->get_param('domain');
    if (!empty($domainParam)) {
        $metadata['domain'] = trim($domainParam);
    }

    return rest_ensure_response(build_payment_response(
        $subscription,
        $amount,
        $feature,
        $title,
        $purpose,
        $metadata + ['quantity' => $quantity]
    ));
}

function licd_rest_pay_renew(WP_REST_Request $request) {
    $tokenValue = sanitize_text_field($request->get_param('token'));
    $licenseKey = sanitize_text_field($request->get_param('license_key'));
    $subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);

    if (!$subscription) {
        return new WP_Error('licd_no_subscription', $reason ?? 'no_subscription', ['status' => 403]);
    }
    $plan = $subscription['plan'];
    $cycle = sanitize_text_field($request->get_param('cycle') ?: 'monthly');
    $amount = plan_price_for_cycle($plan, $cycle);
    if (!$amount || $amount <= 0) {
        return new WP_Error('licd_invalid_amount', 'invalid_amount', ['status' => 400]);
    }

    return rest_ensure_response(build_payment_response(
        $subscription,
        $amount,
        'renewal',
        'Renew ' . $plan['name'],
        'Renewal (' . ucfirst($cycle) . ') for ' . $plan['name'],
        ['cycle' => $cycle, 'expiry' => $subscription['valid_until']]
    ));
}

function licd_rest_pay_subscription(WP_REST_Request $request) {
    $tokenValue = sanitize_text_field($request->get_param('token'));
    $licenseKey = sanitize_text_field($request->get_param('license_key'));
    $planSlug = sanitize_text_field($request->get_param('plan_slug'));
    $cycle = sanitize_text_field($request->get_param('cycle') ?: 'monthly');
    $subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);

    if (!$subscription) {
        return new WP_Error('licd_no_subscription', $reason ?? 'no_subscription', ['status' => 403]);
    }

    $plan = $planSlug ? get_plan_by_slug($planSlug) : null;
    $plan = $plan ?: $subscription['plan'];
    $amount = plan_price_for_cycle($plan, $cycle);
    if (!$amount || $amount <= 0) {
        return new WP_Error('licd_invalid_amount', 'invalid_amount', ['status' => 400]);
    }

    return rest_ensure_response(build_payment_response(
        $subscription,
        $amount,
        'subscription',
        'Pay for ' . $plan['name'],
        'Payment for ' . $plan['name'] . ' (' . ucfirst($cycle) . ')',
        ['cycle' => $cycle, 'plan' => $plan['slug']]
    ));
}

function licd_rest_pay_upgrade(WP_REST_Request $request) {
    $tokenValue = sanitize_text_field($request->get_param('token'));
    $licenseKey = sanitize_text_field($request->get_param('license_key'));
    $planSlug = sanitize_text_field($request->get_param('plan_slug'));
    $subscription = resolve_subscription_for_api($tokenValue, $licenseKey, $reason);

    if (!$subscription) {
        return new WP_Error('licd_no_subscription', $reason ?? 'no_subscription', ['status' => 403]);
    }

    $plan = null;
    if ($planSlug) {
        $plan = get_plan_by_slug($planSlug);
    }
    $plan = $plan ?: $subscription['plan'];
    $cycle = sanitize_text_field($request->get_param('cycle') ?: 'monthly');
    $amount = calculate_upgrade_amount($subscription['plan'], $plan, $cycle);
    $amount += function_exists('get_upgrade_fee') ? get_upgrade_fee() : 0;
    if (!$amount || $amount <= 0) {
        return new WP_Error('licd_invalid_amount', 'invalid_amount', ['status' => 400]);
    }

    return rest_ensure_response(build_payment_response(
        $subscription,
        $amount,
        'upgrade',
        'Upgrade to ' . $plan['name'],
        'Upgrade to ' . $plan['name'] . ' (' . ucfirst($cycle) . ')',
        ['cycle' => $cycle, 'target_plan' => $plan['slug']]
    ));
}
