<?php
require_once __DIR__ . '/../config.php';

require_auth();
$user = current_user();
$profile = get_user_profile($user['id']);

$error = '';
$success = '';

if (is_post()) {
    $name = trim($_POST['name'] ?? '');
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $phone = trim($_POST['phone'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $trade = trim($_POST['trade_name'] ?? '');
    $upiName = trim($_POST['upi_name'] ?? '');
    $upiId = trim($_POST['upi_id'] ?? '');
    $hasWebsite = ($_POST['has_website'] ?? '') === 'yes';
    $website = trim($_POST['website_url'] ?? '');
    $turnover = $_POST['turnover'] ?? '';
    $category = trim($_POST['business_category'] ?? '');
    $regions = trim($_POST['regions'] ?? '');
    $about = trim($_POST['about'] ?? '');

    if ($name === '') {
        $error = 'Name cannot be empty.';
    } else {
        update_user_name($user['id'], $name);
        $success = 'Profile updated.';
    }

    save_user_profile($user['id'], [
        'phone' => $phone,
        'country' => $country,
        'username' => $username,
        'trade_name' => $trade,
        'upi_name' => $upiName,
        'upi_id' => $upiId,
        'has_website' => $hasWebsite,
        'website_url' => $website,
        'turnover_range' => $turnover,
        'business_category' => $category,
        'regions' => $regions,
        'about' => $about,
    ]);
    $profile = get_user_profile($user['id']);

    if ($newPassword !== '') {
        if ($newPassword !== $confirmPassword) {
            $error = 'New passwords do not match.';
        } elseif (!verify_user_password($user['id'], $currentPassword)) {
            $error = 'Current password is incorrect.';
        } else {
            update_user_password($user['id'], $newPassword);
            $success = 'Password updated successfully.';
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Profile - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="dashboard.php">eGo Control Panel</a>
                <div class="d-flex gap-2">
                    <span class="navbar-text text-white"><?php echo e($user['email']); ?></span>
                    <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </nav>
        <div class="container-fluid py-2">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo e($error); ?></div>
            <?php elseif ($success): ?>
                <div class="alert alert-success"><?php echo e($success); ?></div>
            <?php endif; ?>
            <div class="card shadow-sm">
                <div class="card-header">
                    <strong>Profile</strong>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Email (read-only)</label>
                            <input type="email" class="form-control" value="<?php echo e($user['email']); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($user['name']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" name="username" class="form-control" value="<?php echo e($profile['username'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone</label>
                            <input type="text" name="phone" class="form-control" value="<?php echo e($profile['phone'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Country</label>
                            <input type="text" name="country" class="form-control" value="<?php echo e($profile['country'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Trade name / Company</label>
                            <input type="text" name="trade_name" class="form-control" value="<?php echo e($profile['trade_name'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">UPI name (for receiving payments)</label>
                            <input type="text" name="upi_name" class="form-control" value="<?php echo e($profile['upi_name'] ?? ''); ?>" placeholder="Your UPI name">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">UPI ID (for receiving payments)</label>
                            <input type="text" name="upi_id" class="form-control" value="<?php echo e($profile['upi_id'] ?? ''); ?>" placeholder="name@bank">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Do you have a website?</label>
                            <select name="has_website" class="form-select">
                                <option value="no" <?php echo empty($profile['has_website']) ? 'selected' : ''; ?>>No</option>
                                <option value="yes" <?php echo !empty($profile['has_website']) ? 'selected' : ''; ?>>Yes</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Website URL</label>
                            <input type="url" name="website_url" class="form-control" value="<?php echo e($profile['website_url'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Monthly turnover</label>
                            <select name="turnover" class="form-select">
                                <option value="0-50k" <?php echo (($profile['turnover_range'] ?? '')==='0-50k')?'selected':''; ?>>0-50k</option>
                                <option value="50k-100k" <?php echo (($profile['turnover_range'] ?? '')==='50k-100k')?'selected':''; ?>>50k-100k</option>
                                <option value="100k-plus" <?php echo (($profile['turnover_range'] ?? '')==='100k-plus')?'selected':''; ?>>More than 100k</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Business category</label>
                            <input type="text" name="business_category" class="form-control" value="<?php echo e($profile['business_category'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Regions / Countries</label>
                            <input type="text" name="regions" class="form-control" value="<?php echo e($profile['regions'] ?? ''); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">About your business</label>
                            <textarea name="about" class="form-control" rows="3"><?php echo e($profile['about'] ?? ''); ?></textarea>
                        </div>
                        <hr>
                        <p class="text-muted small">Change your password (leave blank to keep current).</p>
                        <div class="mb-3">
                            <label class="form-label">Current Password</label>
                            <input type="password" name="current_password" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" name="new_password" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Save changes</button>
                    </form>
                </div>
            </div>
            <div class="mt-3 text-center">
                <a href="dashboard.php" class="btn btn-link btn-sm">Back to dashboard</a>
            </div>
        </div>
    </div>
</div>
    </div>
</div>
</div>
</body>
</html>
