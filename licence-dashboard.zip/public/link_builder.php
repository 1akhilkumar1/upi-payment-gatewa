<?php
require_once __DIR__ . '/../config.php';

// Ensure errors are logged when this page is hit directly.
@ini_set('log_errors', '1');
@ini_set('error_log', __DIR__ . '/../logs/error.log');
set_error_handler(function($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) { return false; }
    $entry = json_encode([
        'time' => gmdate('c'),
        'type' => $severity,
        'message' => $message,
        'file' => $file,
        'line' => $line,
    ]);
    @file_put_contents(__DIR__ . '/../logs/error.log', $entry . PHP_EOL, FILE_APPEND | LOCK_EX);
    return false;
});

require_auth();
$user = current_user();
$subscription = get_active_subscription_for_user($user['id']);

if (!$subscription) {
    set_flash('error', 'You need an active subscription to create payment links or landing pages.');
    redirect('dashboard.php');
    exit;
}

$license = build_subscription_payload($subscription);
$features = $license['plan']['features'] ?? [];
// Landing builder is now default in all plans
// if (empty($features) || !in_array('landing_builder', $features, true)) {
//     set_flash('error', 'Your plan does not include the landing page builder.');
//     redirect('dashboard.php');
//     exit;
// }

$linksLimit = (int)($license['plan']['payment_links_limit'] ?? 0);
$linksUsed  = (int)($license['used_links'] ?? 0);
$landingLimit = (int)($license['plan']['landing_pages_limit'] ?? 0);
$landingUsed = (int)($license['used_landing_pages'] ?? 0);
$whitelistLimit = (int)($license['plan']['whitelist_domains_limit'] ?? 0);
$whitelistUsed = (int)($license['quotas']['whitelist_domains_used'] ?? 0);
$canCreate  = $linksLimit === 0 || $linksUsed < $linksLimit;
$approvedDomains = get_domains_for_subscription($subscription['id'], 'approved');

$flashes = pull_all_flash();
$generatedUrl = null;

if (is_post() && isset($_POST['action']) && $_POST['action'] === 'create_link') {
    $linkType    = trim($_POST['link_type'] ?? 'payment_page');
    if (!in_array($linkType, ['landing_page', 'payment_page', 'payment_link'], true)) {
        $linkType = 'payment_page';
    }

    // Check limits based on link type
    if ($linkType === 'landing_page') {
        $limit = $landingLimit;
        $used = $landingUsed;
    } elseif ($linkType === 'payment_link') {
        $limit = $linksLimit;
        $used = $linksUsed;
    } elseif ($linkType === 'payment_page') {
        $limit = $whitelistLimit;
        $used = $whitelistUsed;
    }
    $canCreateType = $limit === 0 || $used < $limit;
    if (!$canCreateType) {
        set_flash('error', 'Limit reached for ' . str_replace('_', ' ', $linkType) . '. Please upgrade or remove an existing one.');
        redirect('link_builder.php');
        exit;
    }
    $title       = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $purpose     = trim($_POST['purpose'] ?? '');
    $domainInput = trim($_POST['domain'] ?? '');
    $subdomain   = trim($_POST['subdomain'] ?? '');
    $heroImage   = trim($_POST['hero_image_url'] ?? '');
    $customUrl   = trim($_POST['custom_url'] ?? '');
    $ctaText     = trim($_POST['cta_text'] ?? '');
    $primaryUrl  = trim($_POST['primary_url'] ?? '');
    $secondaryText = trim($_POST['secondary_text'] ?? '');
    $customSlug  = trim($_POST['custom_slug'] ?? '');
    $captureLead = $linkType === 'landing_page' && isset($_POST['capture_leads']);
    $collectPay  = $linkType !== 'landing_page';
    $regular     = (float)($_POST['regular_price'] ?? 0);
    $sale        = (float)($_POST['sale_price'] ?? 0);
    $linkAmount  = (float)($_POST['payment_amount'] ?? 0);
    $digitalFile = trim($_POST['digital_file_url'] ?? '');
    $domainMode  = $_POST['domain_mode'] ?? 'platform';
    $customDomain = trim($_POST['custom_domain'] ?? '');
    $subdomainChoice = trim($_POST['subdomain_choice'] ?? '');
    $captureFields = isset($_POST['capture_fields']) && is_array($_POST['capture_fields'])
        ? array_values(array_intersect(['name','email','phone','address'], $_POST['capture_fields']))
        : [];
    if ($captureLead && empty($captureFields)) {
        $captureFields = ['name', 'email'];
    }
    if ($linkType === 'payment_link') {
        $regular = 0;
        $sale = 0;
    }

    $baseHost = parse_url(BASE_URL, PHP_URL_HOST) ?: 'localhost';
    $scheme = (parse_url(BASE_URL, PHP_URL_SCHEME) ?: 'https') . '://';
    $domainSelected = $scheme . $baseHost; // default: platform domain
    $domain = '';

    if ($domainMode === 'subdomain') {
        $cleanSub = strtolower(preg_replace('/[^a-z0-9-]/', '', $subdomainChoice));
        if ($cleanSub !== '') {
            $domainSelected = $scheme . $cleanSub . '.' . $baseHost;
        } else {
            set_flash('error', 'Please enter a subdomain.');
            redirect('link_builder.php');
            exit;
        }
    } elseif ($domainMode === 'custom') {
        $domain = normalize_domain($customDomain !== '' ? $customDomain : $domainInput);
        if ($domain === '') {
            set_flash('error', 'Please choose a custom domain.');
            redirect('link_builder.php');
            exit;
        }
        if (!is_subscription_domain_allowed($subscription['id'], $domain)) {
            set_flash('error', 'Custom domain must be approved/whitelisted.');
            redirect('link_builder.php');
            exit;
        }
        $domainSelected = $scheme . $domain;
    }

    if (!empty($_FILES['hero_image_file']) && is_array($_FILES['hero_image_file']) && !empty($_FILES['hero_image_file']['tmp_name'])) {
        $allowedExt = ['jpg', 'jpeg', 'png', 'webp'];
        $name = $_FILES['hero_image_file']['name'] ?? '';
        $tmp = $_FILES['hero_image_file']['tmp_name'] ?? '';
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if ($ext && in_array($ext, $allowedExt, true)) {
            $uploadDir = __DIR__ . '/uploads';
            if (!is_dir($uploadDir)) {
                @mkdir($uploadDir, 0755, true);
            }
            $fileName = 'hero_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
            $target = rtrim($uploadDir, '/\\') . '/' . $fileName;
            if (@move_uploaded_file($tmp, $target)) {
                $heroImage = licd_public_url('uploads/' . $fileName);
            } else {
                set_flash('error', 'Failed to upload hero image.');
                redirect('link_builder.php');
                exit;
            }
        } else {
            set_flash('error', 'Hero image must be JPG, PNG, or WEBP.');
            redirect('link_builder.php');
            exit;
        }
    }

    if ($title === '') {
        set_flash('error', 'Title is required.');
    } else {
        $amount = 0;
        if ($linkType === 'payment_page') {
            $amount = $sale > 0 ? $sale : $regular;
        } elseif ($linkType === 'payment_link') {
            $amount = $linkAmount;
        }
        if ($collectPay && $amount <= 0) {
            set_flash('error', 'Please enter a price to collect payment.');
            redirect('link_builder.php');
            exit;
        }
        if ($linkType === 'landing_page' && $primaryUrl === '') {
            set_flash('error', 'Primary button URL is required for landing pages.');
            redirect('link_builder.php');
            exit;
        }
        if ($customSlug !== '' && !preg_match('/^[a-z0-9-]{3,60}$/', $customSlug)) {
            set_flash('error', 'Custom slug must be 3-60 characters (a-z, 0-9, hyphen).');
            redirect('link_builder.php');
            exit;
        }

        $fields = [
            'link_type' => $linkType,
            'capture_fields' => $captureLead ? $captureFields : [],
            'collect_payment' => $collectPay,
            'regular_price' => $regular,
            'sale_price' => $sale,
            'digital_file_url' => $digitalFile,
            'hero_image_url' => $heroImage,
            'custom_url' => $customUrl,
            'cta_text' => $ctaText,
            'primary_url' => $primaryUrl,
            'secondary_text' => $secondaryText,
            'payment_amount' => $linkAmount,
            'custom_slug' => $customSlug,
        ];

        $slug = create_hosted_link(
            $subscription['id'],
            $user['id'],
            $title,
            $description,
            $amount,
            $purpose,
            $heroImage,
            $domainSelected,
            $fields,
            $customSlug !== '' ? $customSlug : null
        );

        if ($slug) {
            $generatedUrl = rtrim($domainSelected, '/') . '/link/' . urlencode($slug);
            set_flash('success', 'Link created successfully.');
        } else {
            set_flash('error', 'Could not create link. Please try again.');
        }
    }
    redirect('link_builder.php' . ($generatedUrl ? '?created=' . rawurlencode($generatedUrl) : ''));
    exit;
}

if (isset($_GET['created'])) {
    $generatedUrl = trim($_GET['created']);
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Create payment link / landing page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
    <style>
        .preview-shell { background:#0b1220; border:1px solid #111827; border-radius:16px; padding:16px; color:#e5e7eb; min-height: 520px; }
        .preview-card { background:#0f172a; border:1px solid #1f2937; border-radius:12px; padding:16px; box-shadow:0 10px 35px rgba(0,0,0,0.35); }
        .preview-price { font-weight:800; font-size:22px; color:#22c55e; }
        .preview-strike { text-decoration:line-through; color:#9ca3af; margin-right:8px; }
        .badge-discount { background:#0f5132; color:#c7f9cc; padding:4px 8px; border-radius:999px; font-size:12px; }
        .preview-img { width:100%; border-radius:12px; margin-bottom:12px; object-fit:cover; max-height:220px; }
        .preview-fields label { color:#cbd5e1; font-size:13px; margin-bottom:4px; }
        .toggle-pill input { display:none; }
        .toggle-pill span { display:inline-block; padding:6px 12px; border:1px solid #1f2937; border-radius:999px; cursor:pointer; }
        .toggle-pill input:checked + span { background:#2563eb; color:#fff; border-color:#2563eb; }
    </style>
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="dashboard.php">eGo Customer Portal</a>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(licd_public_url('dashboard.php')); ?>" class="btn btn-outline-light btn-sm">Dashboard</a>
                    <a href="<?php echo e(licd_public_url('app_connect.php')); ?>" class="btn btn-outline-light btn-sm">App Connect</a>
                    <a href="<?php echo e(licd_public_url('user_links.php')); ?>" class="btn btn-outline-light btn-sm">My links</a>
                    <a href="<?php echo e(licd_public_url('logout.php')); ?>" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </nav>
        <div class="container-fluid">
            <?php foreach ($flashes as $type => $message): ?>
                <div class="alert alert-<?php echo e($type === 'error' ? 'danger' : ($type === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
                    <?php echo e($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>

            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h4 class="mb-1">Payment links / Landing pages</h4>
                    <p class="text-muted small mb-0">Track against your plan: <span id="limit-display"><?php echo $landingLimit > 0 ? ($landingUsed . '/' . $landingLimit) : ($landingUsed . '/unlimited'); ?></span></p>
                </div>
                <a href="dashboard.php" class="btn btn-outline-secondary btn-sm">Back</a>
            </div>

            <?php if ($generatedUrl): ?>
                <div class="alert alert-success">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <strong>Link created:</strong>
                            <a href="<?php echo e($generatedUrl); ?>" target="_blank" rel="noopener"><?php echo e($generatedUrl); ?></a>
                        </div>
                        <button class="btn btn-sm btn-outline-light" type="button" onclick="navigator.clipboard.writeText('<?php echo e($generatedUrl); ?>')">Copy</button>
                    </div>
                </div>
            <?php endif; ?>

            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <form method="post" enctype="multipart/form-data">
                                <input type="hidden" name="action" value="create_link">
                                <div class="mb-3">
                                    <label class="form-label">Create type</label>
                                    <div class="d-flex flex-wrap gap-2">
                                        <label class="toggle-pill">
                                            <input type="radio" name="link_type" value="landing_page" checked>
                                            <span>Landing Page</span>
                                        </label>
                                        <label class="toggle-pill">
                                            <input type="radio" name="link_type" value="payment_page">
                                            <span>Payment Page</span>
                                        </label>
                                        <label class="toggle-pill">
                                            <input type="radio" name="link_type" value="payment_link">
                                            <span>Payment Link</span>
                                        </label>
                                    </div>
                                    <div class="form-text">Landing page = no payment. Payment page = landing + checkout. Payment link = direct checkout.</div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Title</label>
                                    <input type="text" name="title" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Description</label>
                                    <textarea name="description" class="form-control" rows="2"></textarea>
                                    <div class="form-text">Line breaks are preserved on the landing page.</div>
                                </div>
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label">Purpose / short note</label>
                                        <input type="text" name="purpose" class="form-control">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Custom slug (optional)</label>
                                        <input type="text" name="custom_slug" class="form-control" placeholder="e.g. my-offer">
                                    </div>
                                </div>
                                <div class="row g-2 mt-2 link-type-section" data-types="landing_page,payment_page">
                                    <div class="col-md-6">
                                        <label class="form-label">Primary button text</label>
                                        <input type="text" name="cta_text" class="form-control" placeholder="Proceed to payment">
                                    </div>
                                    <div class="col-md-6 link-type-section" data-types="landing_page">
                                        <label class="form-label">Primary button URL</label>
                                        <input type="url" name="primary_url" class="form-control" placeholder="https://...">
                                    </div>
                                </div>
                                <div class="row g-2 mt-2 link-type-section" data-types="landing_page,payment_page">
                                    <div class="col-md-6">
                                        <label class="form-label">Hero image URL</label>
                                        <input type="url" name="hero_image_url" class="form-control" placeholder="https://...">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Hero image upload</label>
                                        <input type="file" name="hero_image_file" class="form-control" accept="image/*">
                                    </div>
                                </div>
                                <div class="row g-2 mt-2 link-type-section" data-types="payment_page,payment_link">
                                    <div class="col-md-6">
                                        <label class="form-label">Digital file URL (for downloads)</label>
                                        <input type="url" name="digital_file_url" class="form-control" placeholder="https://...">
                                    </div>
                                </div>
                                                                <div class="mt-3 border rounded p-3">
                                    <label class="form-label fw-semibold d-block mb-2">Link domain</label>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="domain_mode" id="dm_platform" value="platform" checked>
                                        <label class="form-check-label" for="dm_platform">Use platform domain</label>
                                        <div class="form-text">Default: <?php echo e(parse_url(BASE_URL, PHP_URL_SCHEME) ?: "https"); ?>://<?php echo e(parse_url(BASE_URL, PHP_URL_HOST)); ?></div>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="domain_mode" id="dm_sub" value="subdomain">
        <label class="form-check-label" for="dm_sub">Use a subdomain of the platform</label>
        <div class="input-group input-group-sm mt-1">
            <input type="text" name="subdomain_choice" class="form-control" placeholder="promo">
            <span class="input-group-text d-none d-md-inline"><?php echo e(parse_url(BASE_URL, PHP_URL_HOST)); ?></span>
        </div>
        <div class="form-text">Instant: we host it at <code>your-prefix.<?php echo e(parse_url(BASE_URL, PHP_URL_HOST)); ?></code>.</div>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="domain_mode" id="dm_custom" value="custom">
        <label class="form-check-label" for="dm_custom">Use whitelisted custom domain</label>
        <select name="custom_domain" class="form-select form-select-sm mt-1" <?php echo empty($approvedDomains) ? "disabled" : ""; ?>>
            <option value="">Select approved domain</option>
            <?php foreach ($approvedDomains as $dom): ?>
                <option value="<?php echo e($dom['domain']); ?>"><?php echo e($dom['domain']); ?></option>
            <?php endforeach; ?>
        </select>
        <div class="form-text">Add/whitelist domains in Dashboard -> Domain whitelisting. Point CNAME to this host, then select it here.</div>
    </div>
                                </div>
                                <div class="row g-2 mt-2 link-type-section" data-types="landing_page">
                                    <div class="col-md-6">
                                        <label class="form-label">Capture leads</label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="capture_leads" name="capture_leads">
                                            <label class="form-check-label" for="capture_leads">Collect form details</label>
                                        </div>
                                        <div class="row mt-1 ps-3">
                                            <?php foreach (['name'=>'Name','email'=>'Email','phone'=>'Phone','address'=>'Address'] as $fld => $label): ?>
                                                <div class="col-6">
                                                    <div class="form-check">
                                                        <input class="form-check-input capture-field" type="checkbox" name="capture_fields[]" value="<?php echo e($fld); ?>" id="fld_<?php echo e($fld); ?>">
                                                        <label class="form-check-label small" for="fld_<?php echo e($fld); ?>"><?php echo e($label); ?></label>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Submit button text</label>
                                        <input type="text" name="secondary_text" class="form-control" placeholder="Submit details">
                                        <div class="form-text">Used on the lead form submit button.</div>
                                    </div>
                                </div>

                                <div class="mt-3 border rounded p-3 link-type-section" data-types="payment_page">
                                    <div class="row g-2 mt-2">
                                        <div class="col-md-6">
                                            <label class="form-label">Regular price</label>
                                            <input type="number" step="0.01" min="0" name="regular_price" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Sale price (optional)</label>
                                            <input type="number" step="0.01" min="0" name="sale_price" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-3 border rounded p-3 link-type-section" data-types="payment_link">
                                    <div class="row g-2">
                                        <div class="col-md-6">
                                            <label class="form-label">Payment amount</label>
                                            <input type="number" step="0.01" min="0" name="payment_amount" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-text">Payment links open checkout directly.</div>
                                </div>

                                <div class="mt-3 d-flex justify-content-between align-items-center">
                                    <div class="small text-muted">Links used: <?php echo $linksLimit > 0 ? ($linksUsed . '/' . $linksLimit) : ($linksUsed . '/unlimited'); ?></div>
                                    <button class="btn btn-primary" type="submit" <?php echo $canCreate ? '' : 'disabled'; ?>>Create link</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="d-flex gap-2 mb-2">
                        <label class="toggle-pill">
                            <input type="radio" name="view_mode" value="desktop" checked>
                            <span>Desktop preview</span>
                        </label>
                        <label class="toggle-pill">
                            <input type="radio" name="view_mode" value="mobile">
                            <span>Mobile preview</span>
                        </label>
                    </div>
                    <div class="preview-shell">
                        <div class="preview-card" id="preview-card">
                            <img src="" alt="" class="preview-img d-none" id="preview-img">
                            <h5 id="preview-title">Product title</h5>
                            <p class="text-muted" id="preview-desc">Short description of your landing page or payment link.</p>
                            <div class="d-flex align-items-center gap-2 mb-2" id="price-row">
                                <span class="preview-strike d-none" id="preview-regular"></span>
                                <span class="preview-price" id="preview-sale">INR 0.00</span>
                                <span class="badge-discount d-none" id="preview-discount"></span>
                            </div>
                            <div class="preview-fields" id="preview-fields">
                                <p class="text-muted small mb-1">Lead capture fields:</p>
                                <div class="d-flex flex-wrap gap-1 small text-white-50" id="preview-fields-list">
                                    <span class="badge bg-secondary-subtle text-secondary">Name</span>
                                    <span class="badge bg-secondary-subtle text-secondary">Email</span>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button class="btn btn-primary w-100" id="preview-primary-btn">Proceed to payment</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const titleInput = document.querySelector('input[name="title"]');
    const descInput = document.querySelector('textarea[name="description"]');
    const heroInput = document.querySelector('input[name="hero_image_url"]');
    const regInput = document.querySelector('input[name="regular_price"]');
    const saleInput = document.querySelector('input[name="sale_price"]');
    const paymentAmountInput = document.querySelector('input[name="payment_amount"]');
    const ctaInput = document.querySelector('input[name="cta_text"]');
    const captureToggle = document.getElementById('capture_leads');
    const linkTypeRadios = document.querySelectorAll('input[name="link_type"]');

    function formatPrice(val) {
        const num = parseFloat(val);
        if (isNaN(num) || num <= 0) { return ''; }
        return 'INR ' + num.toFixed(2);
    }

    function getLinkType() {
        const active = document.querySelector('input[name="link_type"]:checked');
        return active ? active.value : 'payment_page';
    }

    function updateTypeVisibility() {
        const linkType = getLinkType();
        document.querySelectorAll('.link-type-section').forEach(section => {
            const types = (section.getAttribute('data-types') || '').split(',').map(v => v.trim()).filter(Boolean);
            if (!types.length) { return; }
            section.style.display = types.includes(linkType) ? '' : 'none';
        });

        const priceRow = document.getElementById('price-row');
        if (linkType === 'landing_page') {
            priceRow.classList.add('d-none');
        } else {
            priceRow.classList.remove('d-none');
        }

        const primaryBtn = document.getElementById('preview-primary-btn');
        if (primaryBtn) {
            const ctaText = (ctaInput && ctaInput.value ? ctaInput.value.trim() : '');
            if (linkType === 'payment_link') {
                primaryBtn.innerText = 'Proceed to payment';
            } else if (ctaText) {
                primaryBtn.innerText = ctaText;
            } else {
                primaryBtn.innerText = linkType === 'landing_page' ? 'Learn more' : 'Proceed to payment';
            }
        }
    }

    function updatePreview() {
        const linkType = getLinkType();

        // Update limit display
        let limitText = '';
        if (linkType === 'landing_page') {
            limitText = <?php echo json_encode($landingLimit > 0 ? $landingUsed . '/' . $landingLimit : $landingUsed . '/unlimited'); ?>;
        } else if (linkType === 'payment_link') {
            limitText = <?php echo json_encode($linksLimit > 0 ? $linksUsed . '/' . $linksLimit : $linksUsed . '/unlimited'); ?>;
        } else if (linkType === 'payment_page') {
            limitText = <?php echo json_encode($whitelistLimit > 0 ? $whitelistUsed . '/' . $whitelistLimit : $whitelistUsed . '/unlimited'); ?>;
        }
        document.getElementById('limit-display').innerText = limitText;

        document.getElementById('preview-title').innerText = titleInput.value || 'Product title';
        document.getElementById('preview-desc').innerText = descInput.value || 'Short description of your landing page or payment link.';

        const img = document.getElementById('preview-img');
        if (heroInput.value) {
            img.src = heroInput.value;
            img.classList.remove('d-none');
        } else {
            img.classList.add('d-none');
        }

        const regularEl = document.getElementById('preview-regular');
        const discountEl = document.getElementById('preview-discount');
        if (linkType === 'payment_page') {
            const regular = parseFloat(regInput.value || '0');
            const sale = parseFloat(saleInput.value || '0');
            const hasSale = sale > 0 && sale < regular;
            const displayPrice = sale > 0 ? sale : regular;
            document.getElementById('preview-sale').innerText = displayPrice > 0 ? formatPrice(displayPrice) : 'INR 0.00';

            if (hasSale) {
                regularEl.innerText = formatPrice(regular);
                regularEl.classList.remove('d-none');
                const pct = Math.round(((regular - sale) / regular) * 100);
                discountEl.innerText = '-' + pct + '%';
                discountEl.classList.remove('d-none');
            } else {
                regularEl.classList.add('d-none');
                discountEl.classList.add('d-none');
            }
        } else if (linkType === 'payment_link') {
            const amount = parseFloat(paymentAmountInput.value || '0');
            document.getElementById('preview-sale').innerText = amount > 0 ? formatPrice(amount) : 'INR 0.00';
            regularEl.classList.add('d-none');
            discountEl.classList.add('d-none');
        }

        const fieldBadges = document.getElementById('preview-fields-list');
        fieldBadges.innerHTML = '';
        if (linkType === 'landing_page' && captureToggle.checked) {
            document.querySelectorAll('.capture-field:checked').forEach(cb => {
                const span = document.createElement('span');
                span.className = 'badge bg-secondary-subtle text-secondary';
                span.innerText = cb.nextElementSibling.innerText;
                fieldBadges.appendChild(span);
            });
            if (!fieldBadges.children.length) {
                fieldBadges.innerHTML = '<span class="badge bg-secondary-subtle text-secondary">Name</span>';
            }
            document.getElementById('preview-fields').classList.remove('d-none');
        } else {
            document.getElementById('preview-fields').classList.add('d-none');
        }

        updateTypeVisibility();
    }

    [titleInput, descInput, heroInput, regInput, saleInput, paymentAmountInput, ctaInput, captureToggle].forEach(el => {
        if (!el) { return; }
        el.addEventListener('input', updatePreview);
        el.addEventListener('change', updatePreview);
    });
    document.querySelectorAll('.capture-field').forEach(cb => cb.addEventListener('change', updatePreview));
    linkTypeRadios.forEach(radio => radio.addEventListener('change', updatePreview));

    document.querySelectorAll('input[name="view_mode"]').forEach(radio => {
        radio.addEventListener('change', () => {
            const card = document.getElementById('preview-card');
            if (radio.value === 'mobile') {
                card.style.maxWidth = '360px';
                card.style.margin = '0 auto';
            } else {
                card.style.maxWidth = '100%';
                card.style.margin = '0';
            }
        });
    });

    updateTypeVisibility();
    updatePreview();
});
</script>
</body>
</html>



