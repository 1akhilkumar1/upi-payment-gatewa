<?php
require_once __DIR__ . '/../config.php';
logout();
redirect('login.php');
