<?php
require_once __DIR__ . '/../config.php';
require_admin();
$export = isset($_GET['export']) && $_GET['export'] === 'csv';
$rows = upcoming_renewals(180); // pull more for export

if ($export) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=upcoming_renewals.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Subscription','User','Plan','Valid until']);
    foreach ($rows as $r) {
        fputcsv($out, [$r['subscription_id'], $r['email'], $r['plan_name'], $r['valid_until']]);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Upcoming Renewals - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Upcoming renewals</h3>
        <div class="d-flex gap-2">
            <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back</a>
            <a href="?export=csv" class="btn btn-outline-primary btn-sm">Export CSV</a>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-striped">
            <thead>
                <tr>
                    <th>Subscription</th>
                    <th>User</th>
                    <th>Plan</th>
                    <th>Valid until</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><?php echo e($r['subscription_id']); ?></td>
                        <td><?php echo e($r['email']); ?></td>
                        <td><?php echo e($r['plan_name']); ?></td>
                        <td><?php echo e($r['valid_until']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
