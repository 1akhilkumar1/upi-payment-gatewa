<?php
require_once __DIR__ . '/../config.php';

require_auth();
$user = current_user();
$subscription = get_active_subscription_for_user($user['id']);

if (!$subscription) {
    set_flash('error', 'No active subscription found.');
    redirect('dashboard.php');
    exit;
}

$flashes = pull_all_flash();

if (is_post() && isset($_POST['action']) && $_POST['action'] === 'delete_link') {
    $slug = trim($_POST['slug'] ?? '');
    if ($slug !== '') {
        $stmt = db()->prepare("SELECT id FROM hosted_links WHERE subscription_id = ? AND slug = ? LIMIT 1");
        $stmt->execute([$subscription['id'], $slug]);
        if ($stmt->fetch()) {
            db()->prepare("DELETE FROM hosted_links WHERE subscription_id = ? AND slug = ?")->execute([$subscription['id'], $slug]);
            set_flash('success', 'Link deleted.');
        } else {
            set_flash('error', 'Link not found.');
        }
    }
    redirect('user_links.php');
    exit;
}

$linksStmt = db()->prepare("SELECT * FROM hosted_links WHERE subscription_id = ? ORDER BY created_at DESC");
$linksStmt->execute([$subscription['id']]);
$links = $linksStmt->fetchAll();

$defaultDomain = DEFAULT_HOSTED_DOMAIN;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Links - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">eGo Customer Portal</a>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(licd_public_url('dashboard.php')); ?>" class="btn btn-outline-light btn-sm">Dashboard</a>
                    <a href="<?php echo e(licd_public_url('app_connect.php')); ?>" class="btn btn-outline-light btn-sm">App Connect</a>
                    <a href="<?php echo e(licd_public_url('user_link_orders.php')); ?>" class="btn btn-outline-light btn-sm">Orders</a>
                    <a href="<?php echo e(licd_public_url('user_leads.php')); ?>" class="btn btn-outline-light btn-sm">Leads</a>
                    <a href="<?php echo e(licd_public_url('link_builder.php')); ?>" class="btn btn-primary btn-sm">Create new</a>
                    <a href="<?php echo e(licd_public_url('logout.php')); ?>" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </nav>
        <div class="container-fluid py-2">
            <?php foreach ($flashes as $type => $message): ?>
                <div class="alert alert-<?php echo e($type === 'error' ? 'danger' : ($type === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
                    <?php echo e($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>

            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h4 class="mb-1">Payment links / Landing pages</h4>
                    <p class="text-muted small mb-0">Manage your existing links. Delete or copy the URL. Edit is not available yet.</p>
                </div>
                <a href="link_builder.php" class="btn btn-primary btn-sm">Create new</a>
            </div>

            <div class="card shadow-sm">
                <div class="card-body">
                    <?php if (empty($links)): ?>
                        <p class="text-muted mb-0">No links created yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th>Title</th>
                                        <th>URL</th>
                                        <th>Amount</th>
                                        <th>Created</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($links as $link): ?>
                                        <?php
                                            $payload = $link['payload'] ? json_decode($link['payload'], true) : [];
                                            $linkType = $payload['link_type'] ?? 'payment_link';
                                            $typeLabel = ucfirst(str_replace('_', ' ', $linkType));
                                            $host = $link['domain'] ?: (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : $defaultDomain);
                                            $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
                                            $domain = stripos($host, 'http') === 0 ? $host : ($scheme . $host);
                                            $url = rtrim($domain, '/') . '/link/' . urlencode($link['slug']);
                                            $amount = number_format((float)$link['amount'], 2);
                                        ?>
                                        <tr>
                                            <td><span class="badge bg-info"><?php echo e($typeLabel); ?></span></td>
                                            <td><?php echo e($link['title']); ?></td>
                                            <td style="max-width:280px;">
                                                <div class="text-truncate small" id="link-<?php echo e($link['slug']); ?>"><?php echo e($url); ?></div>
                                                <button class="btn btn-link btn-sm ps-0" type="button" onclick="copyLink('<?php echo e($link['slug']); ?>')">Copy</button>
                                            </td>
                                            <td><?php echo e($amount); ?></td>
                                            <td><?php echo e($link['created_at']); ?></td>
                                            <td><span class="badge bg-<?php echo $link['status']==='active'?'success':'secondary'; ?>"><?php echo e($link['status']); ?></span></td>
                                            <td class="d-flex gap-2">
                                                <a href="<?php echo e($url); ?>" target="_blank" class="btn btn-outline-primary btn-sm">Open</a>
                                                <form method="post" onsubmit="return confirm('Delete this link?');">
                                                    <input type="hidden" name="action" value="delete_link">
                                                    <input type="hidden" name="slug" value="<?php echo e($link['slug']); ?>">
                                                    <button class="btn btn-outline-danger btn-sm" type="submit">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function copyLink(slug) {
    var el = document.getElementById('link-' + slug);
    if (!el) return;
    navigator.clipboard.writeText(el.textContent.trim()).then(function() {
        alert('Link copied');
    }).catch(function(){ alert('Copy failed'); });
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
