<?php
require_once __DIR__ . '/../config.php';
require_admin();

$id = (int)($_POST['request_id'] ?? 0);
$action = $_POST['action'] ?? '';
$txn = trim($_POST['txn_id'] ?? '');

if ($id <= 0 || !in_array($action, ['approve','reject'], true)) {
    set_flash('error', 'Invalid request action.');
    redirect('admin_dashboard.php');
}

$stmt = db()->prepare("SELECT pr.*, s.plan_id, s.plan_slug, s.id AS subscription_id FROM payment_requests pr LEFT JOIN subscriptions s ON s.id = pr.subscription_id WHERE pr.id = ? LIMIT 1");
$stmt->execute([$id]);
$req = $stmt->fetch();
if (!$req) {
    set_flash('error', 'Payment request not found.');
    redirect('admin_dashboard.php');
}

if ($action === 'approve') {
    $subId = $req['subscription_id'];
    if (!$subId) {
        $subId = ensure_subscription_from_request($req);
        if ($subId) {
            db()->prepare("UPDATE payment_requests SET subscription_id = ? WHERE id = ?")->execute([$subId, $id]);
        }
    } else {
        activate_subscription_from_payment($subId, $req['cycle'] ?? 'monthly');
    }
    mark_payment_request($id, 'completed', $txn ?: $req['txn_id'], ['admin_approved' => true]);
    set_flash('success', 'Payment approved and subscription activated.');
} else {
    db()->prepare("DELETE FROM payment_requests WHERE id = ?")->execute([$id]);
    set_flash('success', 'Payment request rejected and removed.');
}

redirect('admin_dashboard.php');
