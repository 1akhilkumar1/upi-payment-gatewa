<?php
require_once __DIR__ . '/../config.php';

require_auth();
$user = current_user();
$subscription = get_active_subscription_for_user($user['id']);

if (!$subscription) {
    set_flash('error', 'No active subscription found.');
    redirect('dashboard.php');
    exit;
}

$stmt = db()->prepare("SELECT * FROM payment_requests WHERE user_id = ? AND feature = 'link' ORDER BY created_at DESC");
$stmt->execute([$user['id']]);
$orders = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Link Orders - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">eGo Customer Portal</a>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(licd_public_url('dashboard.php')); ?>" class="btn btn-outline-light btn-sm">Dashboard</a>
                    <a href="<?php echo e(licd_public_url('user_links.php')); ?>" class="btn btn-outline-light btn-sm">Links</a>
                    <a href="<?php echo e(licd_public_url('user_leads.php')); ?>" class="btn btn-outline-light btn-sm">Leads</a>
                    <a href="<?php echo e(licd_public_url('app_connect.php')); ?>" class="btn btn-outline-light btn-sm">App Connect</a>
                    <a href="<?php echo e(licd_public_url('user_domains.php')); ?>" class="btn btn-outline-light btn-sm">Domains</a>
                    <a href="<?php echo e(licd_public_url('profile.php')); ?>" class="btn btn-outline-light btn-sm">Profile</a>
                    <a href="<?php echo e(licd_public_url('logout.php')); ?>" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </nav>

        <div class="container-fluid py-2">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h4 class="mb-1">Payment Link Orders</h4>
                    <p class="text-muted small mb-0">Newest orders appear first.</p>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-body">
                    <?php if (empty($orders)): ?>
                        <p class="text-muted mb-0">No orders yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th>Created</th>
                                        <th>Customer</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Details</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orders as $order): ?>
                                        <?php
                                            $meta = $order['metadata'] ? json_decode($order['metadata'], true) : [];
                                            $response = $order['response_json'] ? json_decode($order['response_json'], true) : [];
                                            $customerName = $meta['customer_name'] ?? '';
                                            $customerEmail = $meta['customer_email'] ?? '';
                                            $customerPhone = $meta['customer_phone'] ?? '';
                                            $proofSubmitted = ($order['state'] === 'submitted') ||
                                                !empty($response['payer_name']) || !empty($response['payer_upi']) || !empty($response['txn_id']);
                                            $statusLabel = $proofSubmitted ? 'processing' : $order['state'];
                                        ?>
                                        <tr>
                                            <td><?php echo e($order['created_at']); ?></td>
                                            <td><?php echo e($customerName); ?></td>
                                            <td><?php echo e($customerEmail); ?></td>
                                            <td><?php echo e($customerPhone); ?></td>
                                            <td><?php echo e(number_format((float)$order['amount'], 2)); ?></td>
                                            <td><span class="badge bg-<?php echo $order['state'] === 'completed' ? 'success' : ($proofSubmitted ? 'warning' : 'secondary'); ?>"><?php echo e($statusLabel); ?></span></td>
                                            <td><a class="btn btn-outline-primary btn-sm" href="user_link_order_view.php?id=<?php echo e($order['id']); ?>">View</a></td>
                                            <td>
                                                <?php if (in_array($order['state'], ['submitted', 'pending'], true) || $proofSubmitted): ?>
                                                    <div class="d-flex gap-2 flex-wrap">
                                                        <form method="post" action="user_link_order_action.php">
                                                            <input type="hidden" name="order_id" value="<?php echo e($order['id']); ?>">
                                                            <input type="hidden" name="action" value="approve">
                                                            <button class="btn btn-success btn-sm" type="submit">Approve</button>
                                                        </form>
                                                        <form method="post" action="user_link_order_action.php">
                                                            <input type="hidden" name="order_id" value="<?php echo e($order['id']); ?>">
                                                            <input type="hidden" name="action" value="reject">
                                                            <button class="btn btn-outline-danger btn-sm" type="submit">Reject</button>
                                                        </form>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
