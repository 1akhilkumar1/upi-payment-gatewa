<?php
require_once __DIR__ . '/../config.php';

require_admin();
if (!is_post()) {
    redirect('admin_dashboard.php');
}

$action = $_POST['action'] ?? 'update';
if ($action === 'update') {
    $months = max(0, (int)($_POST['months'] ?? 0));
    set_payment_retention_months($months);
    $label = $months > 0 ? "{$months} month" . ($months === 1 ? '' : 's') : 'off';
    set_flash('success', "Automatic payment retention set to {$label}.");
} elseif ($action === 'run') {
    $months = get_payment_retention_months();
    if ($months <= 0) {
        set_flash('error', 'Retention is disabled; enable it before running a cleanup.');
    } else {
        $deleted = purge_payment_sync_logs($months);
        record_payment_cleanup_run();
        set_flash('success', "Purged {$deleted} payment records older than {$months} month" . ($months === 1 ? '' : 's') . '.');
    }
}

redirect('admin_dashboard.php');
