<?php
require_once __DIR__ . '/../config.php';
require_admin();

$id = (int)($_POST['sub_id'] ?? 0);
$status = $_POST['status'] ?? '';
$validUntil = $_POST['valid_until'] ?? null;

// Normalize datetime-local to SQL datetime
if (!empty($validUntil)) {
    $validUntil = str_replace('T', ' ', substr($validUntil, 0, 16)) . ':00';
}

if ($id <= 0 || !in_array($status, ['active','cancelled','hold','delete'], true)) {
    set_flash('error', 'Invalid subscription action.');
    redirect('admin_dashboard.php');
}

if ($status === 'delete') {
    delete_subscription($id);
    set_flash('success', 'Subscription deleted.');
} else {
    // If status is hold, we do not change validity, just mark hold.
    // When re-activated, validity remains what it was.
    if (!empty($validUntil)) {
        set_subscription_validity($id, $validUntil, $status);
    } else {
        set_subscription_status($id, $status);
    }
    set_flash('success', 'Subscription status updated.');
}
redirect('admin_dashboard.php');
