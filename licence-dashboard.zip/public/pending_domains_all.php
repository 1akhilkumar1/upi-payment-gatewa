<?php
require_once __DIR__ . '/../config.php';
require_admin();
$export = isset($_GET['export']) && $_GET['export'] === 'csv';

$stmt = db()->query("SELECT sd.*, u.email AS user_email, s.license_key FROM subscription_domains sd JOIN subscriptions s ON s.id = sd.subscription_id JOIN users u ON u.id = s.user_id ORDER BY sd.requested_at DESC");
$rows = $stmt->fetchAll();

if ($export) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=pending_domains.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID','User','Domain','Status','Requested','Admin note']);
    foreach ($rows as $r) {
        fputcsv($out, [$r['id'], $r['user_email'], $r['domain'], $r['status'], $r['requested_at'], $r['admin_note']]);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Pending Domains - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Pending domain requests</h3>
        <div class="d-flex gap-2">
            <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back</a>
            <a href="?export=csv" class="btn btn-outline-primary btn-sm">Export CSV</a>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>Domain</th>
                    <th>Status</th>
                    <th>Requested</th>
                    <th>Admin note</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><?php echo e($r['id']); ?></td>
                        <td><?php echo e($r['user_email']); ?></td>
                        <td><?php echo e($r['domain']); ?></td>
                        <td><span class="badge bg-<?php echo $r['status'] === 'approved' ? 'success' : ($r['status'] === 'pending' ? 'warning' : 'secondary'); ?>"><?php echo e($r['status']); ?></span></td>
                        <td><?php echo e($r['requested_at']); ?></td>
                        <td><?php echo e($r['admin_note']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
