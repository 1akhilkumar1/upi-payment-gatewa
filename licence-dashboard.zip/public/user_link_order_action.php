<?php
require_once __DIR__ . '/../config.php';

require_auth();
$user = current_user();

$id = (int)($_POST['order_id'] ?? 0);
$action = $_POST['action'] ?? '';
if ($id <= 0 || !in_array($action, ['approve','reject'], true)) {
    set_flash('error', 'Invalid action.');
    redirect('user_link_orders.php');
    exit;
}

$stmt = db()->prepare("SELECT * FROM payment_requests WHERE id = ? AND user_id = ? AND feature = 'link' LIMIT 1");
$stmt->execute([$id, $user['id']]);
$order = $stmt->fetch();
if (!$order) {
    set_flash('error', 'Order not found.');
    redirect('user_link_orders.php');
    exit;
}

$meta = payment_request_metadata($order);
$response = $order['response_json'] ? json_decode($order['response_json'], true) : [];
$customerEmail = $meta['customer_email'] ?? '';
$linkSlug = $meta['link_slug'] ?? '';
$payerUpi = $response['payer_upi'] ?? ($meta['payer_upi'] ?? '');
$txnId = $order['txn_id'] ?? ($response['txn_id'] ?? ($meta['txn_id'] ?? ''));
$downloadUrl = '';
if ($linkSlug !== '' && !empty($order['subscription_id'])) {
    $stmt = db()->prepare("SELECT payload FROM hosted_links WHERE subscription_id = ? AND slug = ? LIMIT 1");
    $stmt->execute([$order['subscription_id'], $linkSlug]);
    $row = $stmt->fetch();
    if ($row && !empty($row['payload'])) {
        $payload = json_decode($row['payload'], true);
        if (is_array($payload)) {
            $downloadUrl = $payload['digital_file_url'] ?? '';
        }
    }
}

if ($action === 'approve') {
    mark_payment_request($id, 'completed', $txnId !== '' ? $txnId : null, ['user_approved' => true]);
    if (!empty($order['subscription_id'])) {
        $subscription = get_subscription_by_id($order['subscription_id']);
        if ($subscription) {
            $domain = $meta['domain'] ?? null;
            record_payment_sync(
                $subscription['id'],
                $subscription['user_id'],
                $subscription['license_key'],
                'manual',
                'link',
                (float)$order['amount'],
                $txnId,
                $payerUpi,
                ['order_id' => $order['id'], 'approved_by' => $user['id']],
                ['email' => $customerEmail, 'phone' => $meta['customer_phone'] ?? null],
                $domain,
                $linkSlug
            );
            if ($linkSlug !== '') {
                mark_hosted_link_paid($subscription['id'], $linkSlug, (float)$order['amount'], $txnId, $payerUpi);
            }
        }
    }
    if ($customerEmail !== '' && $downloadUrl !== '' && function_exists('licd_send_mail')) {
        $subject = 'Your download is ready';
        $body = '<p>Thanks for your payment.</p><p><a href="' . esc_url($downloadUrl) . '">Download your file</a></p>';
        licd_send_mail($customerEmail, $subject, $body);
        update_payment_request_metadata($id, ['download_sent' => true]);
    }
    set_flash('success', 'Order approved and marked paid.');
} else {
    mark_payment_request($id, 'failed', $txnId !== '' ? $txnId : null, ['user_rejected' => true]);
    if ($customerEmail !== '' && function_exists('licd_send_mail')) {
        $subject = 'Payment rejected';
        $body = '<p>Your payment could not be confirmed. Please contact the seller or retry the payment.</p>';
        licd_send_mail($customerEmail, $subject, $body);
    }
    set_flash('success', 'Order rejected.');
}

redirect('user_link_order_view.php?id=' . urlencode((string)$id));
