<?php
require_once __DIR__ . '/../config.php';
require_admin();

$status = $_GET['status'] ?? 'submitted';
$statusFilter = in_array($status, ['submitted','pending','completed'], true) ? $status : 'submitted';

$sql = "SELECT pr.*, u.email AS user_email, p.name AS plan_name
        FROM payment_requests pr
        LEFT JOIN subscriptions s ON s.id = pr.subscription_id
        LEFT JOIN users u ON u.id = COALESCE(pr.user_id, s.user_id)
        LEFT JOIN plans p ON p.slug = COALESCE(pr.plan_slug, s.plan_slug)
        WHERE pr.state = ?
        ORDER BY pr.created_at DESC";
$stmt = db()->prepare($sql);
$stmt->execute([$statusFilter]);
$rows = $stmt->fetchAll();

if (is_post()) {
    $paymentId = (int)($_POST['payment_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    $note = trim($_POST['admin_note'] ?? '');
    if ($paymentId > 0 && in_array($action, ['approve','reject'], true)) {
        $state = $action === 'approve' ? 'completed' : 'rejected';
        $reqRow = get_payment_request($paymentId);
        mark_payment_request($paymentId, $state, null, ['admin_note' => $note]);
        if ($state === 'completed' && $reqRow) {
            $subId = $reqRow['subscription_id'] ?? null;
            if (!$subId) {
                $subId = ensure_subscription_from_request($reqRow);
                if ($subId) {
                    db()->prepare("UPDATE payment_requests SET subscription_id = ? WHERE id = ?")->execute([$subId, $paymentId]);
                }
            }
            if ($subId) {
                $cycle = $reqRow['cycle'] ?? 'monthly';
                activate_subscription_from_payment($subId, $cycle);
                create_payment_record(
                    $subId,
                    (float)$reqRow['amount'],
                    'admin',
                    'completed',
                    ($reqRow['feature'] ?? '') === 'renewal' ? 'renewal' : 'initial',
                    ['admin_note' => $note, 'payment_request_id' => $paymentId],
                    $reqRow['currency'] ?? payment_gateway_currency(),
                    $reqRow['txn_id'] ?? null,
                    current_timestamp()
                );
                if (function_exists('licd_log_event')) {
                    licd_log_event('admin_payment_complete', 'Admin approved payment request', [
                        'payment_id' => $paymentId,
                        'subscription_id' => $subId,
                        'amount' => (float)$reqRow['amount'],
                        'cycle' => $cycle,
                    ]);
                }
            }
        }
        set_flash('success', 'Payment request updated.');
    }
    redirect('admin_payment_requests.php?status=' . urlencode($statusFilter));
    exit;
}
$flashes = pull_all_flash();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment Proofs - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Payment proofs</h3>
        <div class="d-flex gap-2">
            <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back</a>
        </div>
    </div>
    <?php foreach ($flashes as $key => $message): ?>
        <div class="alert alert-<?php echo e($key === 'error' ? 'danger' : ($key === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
            <?php echo e($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
    <div class="mb-3">
        <a class="btn btn-sm <?php echo $statusFilter==='submitted'?'btn-primary':'btn-outline-primary'; ?>" href="?status=submitted">Submitted</a>
        <a class="btn btn-sm <?php echo $statusFilter==='pending'?'btn-primary':'btn-outline-primary'; ?>" href="?status=pending">Pending</a>
        <a class="btn btn-sm <?php echo $statusFilter==='completed'?'btn-primary':'btn-outline-primary'; ?>" href="?status=completed">Completed</a>
    </div>
    <div class="card shadow-sm">
        <div class="card-body">
            <?php if (empty($rows)): ?>
                <p class="text-muted mb-0">No payment requests found.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Plan</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Details</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rows as $req): ?>
                                <?php $response = $req['response_json'] ? json_decode($req['response_json'], true) : []; ?>
                                <?php $shot = !empty($response['screenshot']) ? LICD_PLUGIN_URL . ltrim($response['screenshot'], '/') : ''; ?>
                                <tr>
                                    <td><?php echo e($req['id']); ?></td>
                                    <td><?php echo e($req['user_email']); ?></td>
                                    <td><?php echo e($req['plan_name'] ?: $req['plan_slug']); ?></td>
                                    <td><?php echo e(number_format($req['amount'], 2)); ?></td>
                                    <td><span class="badge bg-<?php echo $req['state']==='completed'?'success':($req['state']==='pending'?'warning':'secondary'); ?>"><?php echo e($req['state']); ?></span></td>
                                    <td class="small">
                                        <div>Payer: <?php echo e($response['payer_name'] ?? ''); ?></div>
                                        <div>UPI: <?php echo e($response['payer_upi'] ?? ''); ?></div>
                                        <div>Txn: <?php echo e($response['txn_id'] ?? $req['txn_id']); ?></div>
                                        <?php if ($shot): ?><div><a href="<?php echo esc_url($shot); ?>" target="_blank">View proof</a></div><?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($req['state'] === 'submitted' || $req['state'] === 'pending'): ?>
                                            <form method="post" class="d-flex gap-1 flex-wrap">
                                                <input type="hidden" name="payment_id" value="<?php echo e($req['id']); ?>">
                                                <input type="text" name="admin_note" class="form-control form-control-sm" placeholder="Note (optional)">
                                                <button name="action" value="approve" class="btn btn-sm btn-success">Approve</button>
                                                <button name="action" value="reject" class="btn btn-sm btn-danger">Reject</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-muted small">No action</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
