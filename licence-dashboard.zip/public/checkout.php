<?php
require_once __DIR__ . '/../config.php';

$paymentId = intval($_GET['id'] ?? 0);
$paymentLogo = get_payment_logo_url();
$publicToken = trim($_GET['token'] ?? '');
$isPublic = isset($_GET['public']) && $publicToken !== '';
if (!$isPublic) {
    require_auth();
    $user = current_user();
    $profile = get_user_profile($user['id']) ?: [];
}
if ($paymentId <= 0) {
    http_response_code(400);
    echo 'Payment request not found.';
    exit;
}
$req = get_payment_request($paymentId);
if (!$req) {
    http_response_code(404);
    echo 'Payment request not found.';
    exit;
}
$meta = payment_request_metadata($req);
$detailsSaved = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_details') {
    if ($isPublic && verify_public_checkout_token($paymentId, $req['user_id'], $publicToken)) {
        $save = [
            'customer_name' => trim($_POST['customer_name'] ?? ''),
            'customer_email' => trim($_POST['customer_email'] ?? ''),
            'customer_phone' => trim($_POST['customer_phone'] ?? ''),
            'customer_address' => trim($_POST['customer_address'] ?? ''),
        ];
        $save = array_filter($save, fn($v) => $v !== '');
        if (!empty($save)) {
            update_payment_request_metadata($paymentId, $save);
            $meta = array_merge($meta, $save);
            $detailsSaved = true;
        }
    }
}
if ($isPublic) {
    if (!verify_public_checkout_token($paymentId, $req['user_id'], $publicToken)) {
        http_response_code(403);
        echo 'Invalid checkout token.';
        exit;
    }
    $user = [
        'name' => $meta['customer_name'] ?? '',
        'email' => $meta['customer_email'] ?? '',
    ];
    $profile = [
        'phone' => $meta['customer_phone'] ?? '',
        'country' => '',
        'trade_name' => '',
        'website_url' => '',
    ];
} else {
    if ($req['user_id'] != $user['id']) {
        http_response_code(404);
        echo 'Payment request not found.';
        exit;
    }
}
$plan = $req['plan_slug'] ? get_plan_by_slug($req['plan_slug']) : null;
$linkTitle = $meta['link_title'] ?? '';
$planName = $linkTitle !== '' ? $linkTitle : ($plan['name'] ?? ($req['plan_slug'] ?: 'Subscription'));
$amount = $req['amount'];
$currency = $req['currency'];
$deeplink = $req['deeplink'];
$feature = $req['feature'];
$cycle = $req['cycle'] ?? 'monthly';
$title = $linkTitle !== '' ? $linkTitle : (ucfirst($feature) . ' - ' . $planName);
$title = trim(preg_replace('/\\s*\\(\\s*\\)\\s*$/', '', $title));
$baseAmount = isset($meta['base_amount']) ? (float)$meta['base_amount'] : null;
$discountAmount = isset($meta['discount_amount']) ? (float)$meta['discount_amount'] : 0.0;
$discountPercent = isset($meta['discount_percent']) ? (float)$meta['discount_percent'] : 0.0;
$showDiscount = $baseAmount !== null && $discountAmount > 0.0;
$merchantName = !empty($meta['merchant_name']) ? $meta['merchant_name'] : get_payment_gateway_name();
$merchantUpi = !empty($meta['merchant_upi']) ? $meta['merchant_upi'] : get_payment_gateway_upi();
$downloadUrl = '';
if (($req['feature'] ?? '') === 'link') {
    $linkSlug = $meta['link_slug'] ?? '';
    if ($linkSlug !== '' && !empty($req['subscription_id'])) {
        $stmt = db()->prepare("SELECT payload FROM hosted_links WHERE subscription_id = ? AND slug = ? LIMIT 1");
        $stmt->execute([$req['subscription_id'], $linkSlug]);
        $row = $stmt->fetch();
        if ($row && !empty($row['payload'])) {
            $payload = json_decode($row['payload'], true);
            if (is_array($payload)) {
                $downloadUrl = $payload['digital_file_url'] ?? '';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Checkout - <?php echo e($planName); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      :root {
        --bg: #0b1020;
        --panel: #0f172a;
        --border: #1f2937;
        --muted: #9ca3af;
        --text: #e5e7eb;
        --accent: #6366f1;
        --accent-2: #0ea5e9;
      }
      * { box-sizing: border-box; }
      body { background: var(--bg); color: var(--text); font-family: 'Inter', system-ui, -apple-system, sans-serif; margin:0; padding:20px; }
      .wrap { max-width: 1100px; margin: 0 auto; }
      .checkout-grid { display:grid; grid-template-columns: 1.4fr 1fr; gap:18px; }
      @media (max-width: 900px){ .checkout-grid { grid-template-columns:1fr; } }
      .panel { background: var(--panel); border:1px solid var(--border); border-radius:16px; box-shadow:0 18px 45px rgba(0,0,0,0.35); padding:20px; }
      .panel h2 { margin:0 0 8px; font-size:20px; }
      .muted { color: var(--muted); }
      .badge { display:inline-block; padding:6px 10px; border-radius:999px; background:#111827; border:1px solid var(--border); font-weight:700; }
      .brand { display:flex; align-items:center; gap:10px; margin-bottom:10px; }
      .brand img { height:28px; width:auto; border-radius:6px; }
      .brand-title { font-size:18px; font-weight:800; background: linear-gradient(90deg, #f59e0b, #ec4899); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
      .brand-sub { font-size:12px; color:var(--muted); }
      .form-grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(220px,1fr)); gap:12px 14px; }
      label { display:block; font-size:13px; color:#cbd5e1; margin-bottom:4px; }
      input, select, textarea { width:100%; padding:10px 11px; border-radius:10px; border:1px solid var(--border); background:#0b1224; color:var(--text); }
      textarea { min-height:80px; resize:vertical; }
      .pay-options { display:flex; flex-direction:column; gap:8px; margin-top:8px; }
      .pay-option { display:flex; justify-content:space-between; align-items:center; padding:10px 12px; border:1px solid var(--border); border-radius:12px; background:#0b1224; cursor:pointer; }
      .pay-option.active { border-color: var(--accent-2); box-shadow:0 0 0 1px rgba(14,165,233,0.2); }
      .actions-grid { display:grid; gap:12px; }
      .qr-box { text-align:center; padding:14px; border:1px solid var(--border); border-radius:12px; background:#0b1224; }
      .btn { display:inline-block; text-align:center; padding:11px 14px; border-radius:12px; font-weight:700; text-decoration:none; border:none; cursor:pointer; }
      .btn-primary { background: var(--accent-2); color:#fff; border:1px solid #0ea5e9; }
      .btn-ghost { background:transparent; color:var(--text); border:1px solid var(--border); }
      .app-icons { display:grid; grid-template-columns: repeat(auto-fit,minmax(120px,1fr)); gap:10px; }
      .app-card { display:flex; align-items:center; gap:8px; padding:9px 10px; border:1px solid var(--border); border-radius:10px; background:#111827; color:#e5e7eb; text-decoration:none; }
      .app-card img { width:28px; height:28px; border-radius:6px; }
      .summary-line { display:flex; justify-content:space-between; margin:4px 0; }
      .discount-line { color:#22c55e; font-weight:700; }
      .timer { font-weight:700; color:#22c55e; text-align:right; }
      .hidden-panel { display:none; }
    </style>
</head>
<body>
<div class="wrap">
  <div class="checkout-grid">
    <div class="panel">
      <div class="brand">
        <?php if (!empty($paymentLogo)): ?><img src="<?php echo esc_url($paymentLogo); ?>" alt="Brand"><?php endif; ?>
        <div>
          <div class="brand-title">eGo Payment</div>
          <div class="brand-sub">Tap • Pay • Done.</div>
        </div>
        <div class="timer" id="licd-timer" style="margin-left:auto;">05:00</div>
      </div>
      <h2><?php echo e($planName); ?> (<?php echo ucfirst($cycle); ?>)</h2>
      <div class="muted" style="margin-bottom:16px;"><?php echo e($title); ?></div>
      <?php if ($detailsSaved): ?>
        <div class="badge" style="margin-bottom:10px;">Details saved</div>
      <?php endif; ?>
      <form method="post" id="customer-details-form">
        <input type="hidden" name="action" value="save_details">
        <div class="form-grid">
          <div>
            <label>Full name</label>
            <input type="text" name="customer_name" value="<?php echo e($user['name'] ?? ''); ?>" placeholder="Your name">
          </div>
          <div>
            <label>Email</label>
            <input type="email" name="customer_email" value="<?php echo e($user['email'] ?? ''); ?>" placeholder="you@example.com">
          </div>
          <div>
            <label>Phone</label>
            <input type="text" name="customer_phone" value="<?php echo e($profile['phone'] ?? ''); ?>" placeholder="+91 ...">
          </div>
          <div>
            <label>Address</label>
            <input type="text" name="customer_address" value="<?php echo e($meta['customer_address'] ?? ''); ?>" placeholder="Address">
          </div>
        </div>
        <div style="margin-top:10px;" class="d-flex gap-2 flex-wrap">
          <button class="btn btn-ghost" type="submit">Save details</button>
          <button class="btn btn-primary" type="button" id="pay-now-btn">Pay now</button>
        </div>
      </form>
      <div style="margin-top:14px;">
        <div class="pay-options">
          <div class="pay-option active" data-target="qr">
            <span>Pay using QR</span>
            <span class="badge">Recommended</span>
          </div>
          <?php if (!$isPublic): ?>
            <div class="pay-option" data-target="app">Pay using App</div>
          <?php endif; ?>
          <div class="pay-option" data-target="upi">Pay using preferred UPI app</div>
        </div>
      </div>
    </div>

    <div class="panel actions-grid hidden-panel" id="panel-qr">
      <?php if (($req['state'] ?? '') === 'completed'): ?>
        <div class="badge">Payment confirmed</div>
        <?php if ($downloadUrl): ?>
          <a class="btn btn-primary" href="<?php echo esc_url($downloadUrl); ?>" target="_blank" rel="noopener">Download</a>
        <?php endif; ?>
      <?php endif; ?>
      <div class="summary-line"><span>Amount due</span><strong><?php echo e($currency); ?> <?php echo e(number_format((float)$amount, 2)); ?></strong></div>
      <?php if ($showDiscount): ?>
        <div class="summary-line"><span>Base amount</span><strong><?php echo e($currency); ?> <?php echo e(number_format($baseAmount, 2)); ?></strong></div>
        <div class="summary-line discount-line"><span>Instant discount</span><strong>-<?php echo e($currency); ?> <?php echo e(number_format($discountAmount, 2)); ?><?php echo $discountPercent > 0 ? ' (' . e(number_format($discountPercent, 2)) . '%)' : ''; ?></strong></div>
      <?php endif; ?>
      <div class="summary-line"><span>Merchant</span><strong><?php echo e($merchantName); ?></strong></div>
      <div class="summary-line"><span>UPI ID</span><strong><?php echo e($merchantUpi); ?></strong></div>
      <div class="qr-box" id="qr-box">
        <div class="muted" style="margin-bottom:8px;">Scan the QR from any UPI app</div>
        <img id="upi-qr-d" src="<?php echo esc_url('https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=' . rawurlencode($deeplink)); ?>" alt="UPI QR" style="max-width:220px;">
        <div style="margin-top:10px;">
          <a class="btn btn-ghost" href="<?php echo esc_url('https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . rawurlencode($deeplink)); ?>" download>Download QR</a>
        </div>
      </div>
      <button class="btn btn-primary" onclick="retryPayment('<?php echo e($paymentId); ?>')">Refresh payment</button>
      <div id="proof-area" style="display:none; margin-top:12px;">
        <div class="muted" style="margin-bottom:8px;">If your money has debited from your account please submit details below.</div>
        <?php if ($isPublic): ?>
          <?php if (isset($_GET['proof']) && $_GET['proof'] === 'submitted'): ?>
            <div class="badge" style="margin-bottom:8px;">Request submitted. We will verify soon.</div>
          <?php endif; ?>
          <form method="post" action="payment_proof_public.php" enctype="multipart/form-data">
            <input type="hidden" name="payment_id" value="<?php echo e($paymentId); ?>">
            <input type="hidden" name="token" value="<?php echo e($publicToken); ?>">
            <div class="form-grid">
              <div>
                <label>Payer name</label>
                <input type="text" name="payer_name" required>
              </div>
              <div>
                <label>Payer UPI</label>
                <input type="text" name="payer_upi" required>
              </div>
              <div>
                <label>Txn / UPI Ref</label>
                <input type="text" name="txn_id" required>
              </div>
              <div>
                <label>Screenshot</label>
                <input type="file" name="screenshot" accept="image/*">
              </div>
            </div>
            <div class="d-flex gap-2 flex-wrap" style="margin-top:10px;">
              <button class="btn btn-primary" type="submit">Submit</button>
              <button class="btn btn-ghost" type="button" onclick="retryPayment('<?php echo e($paymentId); ?>')">Retry</button>
            </div>
          </form>
        <?php else: ?>
          <form id="proof" method="post" action="payment_proof.php" enctype="multipart/form-data" onsubmit="return handleProofSubmit(this);">
            <input type="hidden" name="payment_id" value="<?php echo e($paymentId); ?>">
            <div class="form-grid">
              <div>
                <label>Payer name</label>
                <input type="text" name="payer_name" required>
              </div>
              <div>
                <label>Payer UPI</label>
                <input type="text" name="payer_upi" required>
              </div>
              <div>
                <label>Txn / UPI Ref</label>
                <input type="text" name="txn_id" required>
              </div>
              <div>
                <label>Screenshot</label>
                <input type="file" name="screenshot" accept="image/*">
              </div>
            </div>
            <div class="d-flex gap-2 flex-wrap" style="margin-top:10px;">
              <button class="btn btn-primary" type="submit">Submit</button>
              <button class="btn btn-ghost" type="button" onclick="retryPayment('<?php echo e($paymentId); ?>')">Retry</button>
            </div>
          </form>
        <?php endif; ?>
      </div>
    </div>

    <?php if (!$isPublic): ?>
    <div class="panel actions-grid hidden-panel" id="panel-app">
      <div class="summary-line"><span>Amount due</span><strong><?php echo e($currency); ?> <?php echo e(number_format((float)$amount, 2)); ?></strong></div>
      <?php if ($showDiscount): ?>
        <div class="summary-line"><span>Base amount</span><strong><?php echo e($currency); ?> <?php echo e(number_format($baseAmount, 2)); ?></strong></div>
        <div class="summary-line discount-line"><span>Instant discount</span><strong>-<?php echo e($currency); ?> <?php echo e(number_format($discountAmount, 2)); ?><?php echo $discountPercent > 0 ? ' (' . e(number_format($discountPercent, 2)) . '%)' : ''; ?></strong></div>
      <?php endif; ?>
      <p class="muted">If the app is installed and paired, tap below to send the payment request to your phone. Otherwise, install/connect the eGo Payment app first.</p>
      <button class="btn btn-primary" onclick="payOnApp('<?php echo e($paymentId); ?>')">Send to eGo Payment App</button>
      <div class="muted">After sending, open the app on your phone and complete payment. We will auto-confirm on success.</div>
    </div>
    <?php endif; ?>

    <div class="panel actions-grid hidden-panel" id="panel-upi">
      <div class="summary-line"><span>Amount due</span><strong><?php echo e($currency); ?> <?php echo e(number_format((float)$amount, 2)); ?></strong></div>
      <?php if ($showDiscount): ?>
        <div class="summary-line"><span>Base amount</span><strong><?php echo e($currency); ?> <?php echo e(number_format($baseAmount, 2)); ?></strong></div>
        <div class="summary-line discount-line"><span>Instant discount</span><strong>-<?php echo e($currency); ?> <?php echo e(number_format($discountAmount, 2)); ?><?php echo $discountPercent > 0 ? ' (' . e(number_format($discountPercent, 2)) . '%)' : ''; ?></strong></div>
      <?php endif; ?>
      <p class="muted">Choose your preferred UPI app; payment details will be prefilled.</p>
      <div class="app-icons">
        <a class="app-card" href="<?php echo e($deeplink); ?>"><img src="assets/images/gpay.png" alt="GPay"><span>Google Pay</span></a>
        <a class="app-card" href="<?php echo e($deeplink); ?>"><img src="assets/images/phonepe.png" alt="PhonePe"><span>PhonePe</span></a>
        <a class="app-card" href="<?php echo e($deeplink); ?>"><img src="assets/images/paytm.png" alt="Paytm"><span>Paytm</span></a>
        <a class="app-card" href="<?php echo e($deeplink); ?>"><img src="assets/images/BHIM.png" alt="BHIM"><span>BHIM</span></a>
      </div>
    </div>
  </div>

  <?php if (!$isPublic): ?>
  <?php endif; ?>
  </div>

  <?php if ($isPublic): ?>
  <script>
    (function(){
      const form = document.getElementById('customer-details-form');
      if (!form) { return; }
      const fields = ['customer_name','customer_email','customer_phone','customer_address'];
      function collectPayload() {
        const data = new URLSearchParams();
        data.append('action', 'save_details');
        fields.forEach(name => {
          const el = form.querySelector('[name=\"' + name + '\"]');
          if (el && el.value.trim() !== '') {
            data.append(name, el.value.trim());
          }
        });
        return data;
      }
      let saveTimer = null;
      function collect() {
        const data = collectPayload();
        if (![...data.keys()].some(k => k !== 'action')) { return; }
        fetch(window.location.href, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: data.toString()
        }).catch(() => {});
      }
      form.querySelectorAll('input').forEach(input => {
        input.addEventListener('input', () => {
          clearTimeout(saveTimer);
          saveTimer = setTimeout(collect, 500);
        });
      });

      const payBtn = document.getElementById('pay-now-btn');
      if (payBtn) {
        payBtn.addEventListener('click', () => {
          const data = collectPayload();
          if ([...data.keys()].some(k => k !== 'action')) {
            fetch(window.location.href, {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
              body: data.toString()
            }).catch(() => {});
          }
        });
      }
    })();
  </script>
  <?php endif; ?>
  <script>
    (function(){
      const payBtn = document.getElementById('pay-now-btn');
      const panels = ['panel-qr', 'panel-app', 'panel-upi'].map(id => document.getElementById(id)).filter(Boolean);
      if (!payBtn) { return; }
      payBtn.addEventListener('click', () => {
        panels.forEach(panel => {
          panel.classList.remove('hidden-panel');
        });
        if (panels[0]) {
          panels[0].scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    })();
  </script>
<script>
  (function(){
    var timerEl = document.getElementById('licd-timer');
    var seconds = 300;
    if (timerEl) {
      var interval = setInterval(function(){
        seconds--;
        if (seconds <= 0){
          clearInterval(interval);
          timerEl.textContent = 'Expired';
          var qrBox = document.getElementById('qr-box');
          if (qrBox) { qrBox.style.display = 'none'; }
          var proofArea = document.getElementById('proof-area');
          if (proofArea) { proofArea.style.display = 'block'; }
          return;
        }
        var m = String(Math.floor(seconds/60)).padStart(2,'0');
        var s = String(seconds%60).padStart(2,'0');
        timerEl.textContent = m + ':' + s;
      }, 1000);
    }
    document.querySelectorAll('.pay-option').forEach(function(opt){
      opt.addEventListener('click', function(){
        document.querySelectorAll('.pay-option').forEach(function(o){ o.classList.remove('active'); });
        opt.classList.add('active');
        var target = opt.getAttribute('data-target');
        ['qr','app','upi'].forEach(function(k){
          var pane = document.getElementById('panel-' + k);
          if (pane) pane.style.display = (k === target) ? 'block' : 'none';
        });
      });
    });
  })();
  function retryPayment(pid){
    window.location.href = 'checkout.php?id=' + pid;
  }
  function payOnApp(pid){
    alert('If the eGo Payment app is not installed, please install it first. We will redirect you to the dashboard—open the eGo Payment app on your phone to finish payment.');
    window.location.href = 'dashboard.php?app_payment=' + encodeURIComponent(pid);
  }
  function handleProofSubmit(form){
    var btns = form.querySelectorAll('button');
    btns.forEach(function(b){ b.disabled = true; });
    var badge = document.createElement('div');
    badge.className = 'alert alert-success mt-2';
    badge.textContent = 'Request submitted. Redirecting to dashboard...';
    form.appendChild(badge);
    setTimeout(function(){ window.location.href = 'dashboard.php'; }, 1200);
    return true;
  }
</script>
</body>
</html>
