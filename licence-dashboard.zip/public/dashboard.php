<?php
require_once __DIR__ . '/../config.php';

require_auth();
$user = current_user();
$subscription = get_active_subscription_for_user($user['id']);
$availablePlans = list_plans(true);
$paymentLink = null;
$pendingPayment = null;
$downloadTypes = [
    'woo' => 'WooCommerce Plugin',
    'edd' => 'EDD Plugin',
    'standalone' => 'Standalone Plugin',
    'android' => 'Android App',
];
$downloadLinks = [];
foreach ($downloadTypes as $k => $_) {
    $downloadLinks[$k] = get_setting('download_' . $k . '_url', '');
}

if (is_post() && isset($_POST['action']) && $_POST['action'] === 'buy_plan') {
    $planSlug = trim($_POST['plan_slug'] ?? '');
    $cycle    = ($_POST['cycle'] ?? 'monthly') === 'yearly' ? 'yearly' : 'monthly';
    $plan     = $planSlug ? get_plan_by_slug($planSlug) : null;
    if ($plan) {
        $feature = 'subscription';
        $amount = plan_price_for_cycle($plan, $cycle);
        if ($subscription) {
            if ($plan['slug'] === ($licensePayload['plan']['slug'] ?? '')) {
                set_flash('error', 'You already have this plan active.');
                $amount = 0;
            } else {
                $feature = 'upgrade';
                $amount = prorated_upgrade_amount($licensePayload['plan'], $plan, $licensePayload['valid_until'] ?? null, $cycle);
            }
        }
        if ($amount > 0) {
            try {
                $note = $plan['name'] . ' - ' . ($user['email'] ?? $user['name']);
                $payReq = create_payment_request(
                    ['id' => $subscription['id'] ?? null, 'user_id' => $user['id'], 'user' => $user['id']],
                    $feature,
                    $amount,
                    $cycle,
                    $plan['slug'],
                    ['source' => 'dashboard'],
                    null,
                    $note
                );
                set_flash('success', 'Payment request created. Complete the payment to activate your plan.');
                redirect('checkout.php?id=' . $payReq['id']);
                exit;
            } catch (Exception $e) {
                set_flash('error', 'Could not create payment request: ' . $e->getMessage());
            }
        } else {
            set_flash('error', 'Invalid amount for the selected plan.');
        }
    } else {
        set_flash('error', 'Please choose a plan.');
    }
}
$reason = null;
if (is_post() && isset($_POST['action']) && $_POST['action'] === 'domain_request') {
    if (!$subscription) {
        set_flash('error', 'No active subscription to attach the domain.');
        redirect('dashboard.php');
        exit;
    }
    $domainInput = trim($_POST['domain'] ?? '');
    if ($domainInput === '') {
        set_flash('error', 'Please enter a domain.');
    } else {
        if (request_domain_for_subscription($subscription['id'], $domainInput, $reason)) {
            set_flash('success', 'Domain request submitted. It will be auto-approved in a few minutes if within limit.');
        } else {
            set_flash('error', 'Domain request failed: ' . ($reason ?: 'unknown error'));
        }
    }
    redirect('dashboard.php');
    exit;
}
$licensePayload = $subscription ? build_subscription_payload($subscription) : null;
$features = $licensePayload['plan']['features'] ?? [];
$domains = $licensePayload['domains'] ?? [];
$payments = $subscription ? get_subscription_payments($subscription['id']) : [];
$recentPayments = array_slice($payments, 0, 5);
$paymentRequests = [];
if ($user) {
    $stmt = db()->prepare("SELECT pr.*, p.name AS plan_name FROM payment_requests pr JOIN subscriptions s ON s.id = pr.subscription_id JOIN plans p ON p.slug = pr.plan_slug WHERE pr.user_id = ? AND pr.state = 'submitted' ORDER BY pr.created_at DESC");
    $stmt->execute([$user['id']]);
    $paymentRequests = $stmt->fetchAll();
}
$paymentLogs = [];
$totalReceived = 0;
if ($user) {
    $stmt = db()->prepare("SELECT * FROM payment_sync_logs WHERE user_id = ? AND feature <> 'link_view' ORDER BY recorded_at DESC");
    $stmt->execute([$user['id']]);
    $paymentLogs = $stmt->fetchAll();
    foreach ($paymentLogs as $pl) {
        $totalReceived += (float)$pl['amount'];
    }
}
$flashes = pull_all_flash();
$appPaymentId = isset($_GET['app_payment']) ? intval($_GET['app_payment']) : 0;

$tokenStmt = db()->prepare("SELECT * FROM api_tokens WHERE user_id = ? AND active = 1 ORDER BY created_at DESC LIMIT 1");
$tokenStmt->execute([$user['id']]);
$token = $tokenStmt->fetch();
$mainColClass = $licensePayload ? 'col-lg-12' : 'col-lg-8';

function badge_for_status($status)
{
    switch ($status) {
        case 'active':
            return 'success';
        case 'past_due':
            return 'warning';
        case 'cancelled':
            return 'secondary';
        default:
            return 'secondary';
    }
}

function payment_badge($status)
{
    switch ($status) {
        case 'completed':
            return 'success';
        case 'pending':
            return 'warning';
        case 'failed':
            return 'danger';
        default:
            return 'secondary';
    }
}

$domainLimit = $licensePayload['plan']['domain_limit'] ?? 0;
$approvedDomains = $licensePayload['approved_domains_count'] ?? 0;
$pendingDomains = $licensePayload['pending_domains_count'] ?? 0;
$domainUsageLabel = $domainLimit > 0 ? "{$approvedDomains}/{$domainLimit}" : "{$approvedDomains}/unlimited";
$whitelistLimit = $licensePayload['plan']['whitelist_domains_limit'] ?? ($licensePayload['whitelist_domains_limit'] ?? 0);
$whitelistUsed = $licensePayload['quotas']['whitelist_domains_used'] ?? $approvedDomains;
$whitelistUsageLabel = $whitelistLimit > 0 ? "{$whitelistUsed}/{$whitelistLimit}" : "{$whitelistUsed}/unlimited";
$linksLimit = $licensePayload['plan']['payment_links_limit'] ?? ($licensePayload['payment_links_limit'] ?? 0);
$linksUsed = $licensePayload['used_links'] ?? 0;
$linksUsageLabel = $linksLimit > 0 ? "{$linksUsed}/{$linksLimit}" : "{$linksUsed}/unlimited";
$landingLimit = $licensePayload['plan']['landing_pages_limit'] ?? ($licensePayload['landing_pages_limit'] ?? 0);
$landingUsed = $licensePayload['used_landing_pages'] ?? 0;
$landingUsageLabel = $landingLimit > 0 ? "{$landingUsed}/{$landingLimit}" : "{$landingUsed}/unlimited";
$domainPercent = $domainLimit > 0 ? min(100, round(($approvedDomains / $domainLimit) * 100)) : 0;
$whitelistPercent = $whitelistLimit > 0 ? min(100, round(($whitelistUsed / $whitelistLimit) * 100)) : 0;
$linksPercent = $linksLimit > 0 ? min(100, round(($linksUsed / $linksLimit) * 100)) : 0;
$landingPercent = $landingLimit > 0 ? min(100, round(($landingUsed / $landingLimit) * 100)) : 0;
$canBuildLanding = in_array('landing_builder', $features, true);
$linksRemaining = $linksLimit > 0 ? max(0, $linksLimit - $linksUsed) : -1;
$renewAmount = $licensePayload['plan']['pricing']['monthly'] ?? null;
$renewLink = 'upi://pay?pa=ego.payments@okhdfc&pn=eGo+Subscription';
if ($renewAmount) {
    $renewLink .= '&cu=INR&am=' . rawurlencode(number_format($renewAmount, 2, '.', ''));
}
$dnsHost = parse_url(BASE_URL, PHP_URL_HOST) ?: ($_SERVER['HTTP_HOST'] ?? 'your-host');
$dnsScheme = parse_url(BASE_URL, PHP_URL_SCHEME) ?: 'https';
$dnsIp = filter_var($dnsHost, FILTER_VALIDATE_IP) ? $dnsHost : @gethostbyname($dnsHost);
$daysLeft = null;
if (!empty($licensePayload['valid_until'])) {
    $expiresAt = strtotime($licensePayload['valid_until']);
    if ($expiresAt !== false) {
        $daysLeft = max(0, (int)floor(($expiresAt - time()) / 86400));
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Customer Dashboard - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">eGo Customer Portal</a>
                <div class="d-flex gap-2">
                    <?php if ($subscription): ?>
                        <a href="<?php echo e(licd_public_url('user_links.php')); ?>" class="btn btn-outline-light btn-sm">Links</a>
                        <a href="<?php echo e(licd_public_url('user_link_orders.php')); ?>" class="btn btn-outline-light btn-sm">Orders</a>
                        <a href="<?php echo e(licd_public_url('user_leads.php')); ?>" class="btn btn-outline-light btn-sm">Leads</a>
                        <a href="<?php echo e(licd_public_url('app_connect.php')); ?>" class="btn btn-outline-light btn-sm">App Connect</a>
                        <a id="nav-domains" href="<?php echo e(licd_public_url('user_domains.php')); ?>" class="btn btn-outline-light btn-sm">Domains</a>
                    <?php endif; ?>
                    <a href="<?php echo e(licd_public_url('profile.php')); ?>" class="btn btn-outline-light btn-sm">Profile</a>
                    <a href="<?php echo e(licd_public_url('logout.php')); ?>" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </nav>
        <div class="container-fluid py-2">
    <?php foreach ($flashes as $type => $message): ?>
        <div class="alert alert-<?php echo e($type === 'error' ? 'danger' : ($type === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
            <?php echo e($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
    <?php if ($appPaymentId): ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            Please open the eGo Payment app on your phone and complete the payment. Amount and UPI details are prefilled for your request #<?php echo e($appPaymentId); ?>.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <div class="row g-4">
        <div class="<?php echo $mainColClass; ?>">
            <?php if ($licensePayload): ?>
                <div class="card shadow-sm">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <strong>Active Subscription</strong>
                            <div class="small text-muted"><?php echo e($licensePayload['plan']['description']); ?></div>
                        </div>
                        <span class="badge bg-<?php echo e(badge_for_status($licensePayload['status'])); ?>">
                            <?php echo e($licensePayload['status']); ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <p class="mb-1 mt-3">Plan</p>
                        <div class="d-flex flex-wrap gap-2">
                            <span class="badge bg-primary"><?php echo e($licensePayload['plan']['name']); ?></span>
                            <span class="badge border border-secondary text-secondary">Domains: <?php echo e($domainUsageLabel); ?></span>
                            <span class="badge border border-secondary text-secondary">Landing Pages: <?php echo e($landingUsageLabel); ?></span>
                            <span class="badge border border-secondary text-secondary">Payment Links: <?php echo e($linksUsageLabel); ?></span>
                            <span class="badge border border-secondary text-secondary">Whitelist Domains: <?php echo e($whitelistUsageLabel); ?></span>
                            <span class="badge border border-secondary text-secondary">Auto renew: <?php echo $licensePayload['auto_renew'] ? 'Enabled' : 'Disabled'; ?></span>
                        </div>
                        <p class="mt-3 mb-1">Valid until</p>
                        <p class="fw-bold mb-0"><?php echo e($licensePayload['valid_until'] ?? 'No expiry'); ?></p>
                        <?php if ($daysLeft !== null): ?>
                            <small class="text-muted">Expires in <?php echo e($daysLeft); ?> day<?php echo $daysLeft === 1 ? '' : 's'; ?>.</small>
                        <?php endif; ?>
                        <div class="mt-4 d-flex flex-wrap gap-2">
                            <form method="post" class="d-inline">
                                <input type="hidden" name="action" value="buy_plan">
                                <input type="hidden" name="plan_slug" value="<?php echo e($licensePayload['plan']['slug']); ?>">
                                <input type="hidden" name="cycle" value="monthly">
                                <button type="submit" class="btn btn-success btn-sm">Renew Now</button>
                            </form>
                            <a href="pricing.php" class="btn btn-outline-primary btn-sm">Upgrade Plan</a>
                            <a href="profile.php" class="btn btn-outline-secondary btn-sm">Update profile</a>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="card shadow-sm border-danger">
                    <div class="card-body">
                        <h5 class="card-title">No active subscription</h5>
                        <p class="card-text text-muted">You don't have any active subscription. Please buy a plan to continue.</p>
                        <a href="#buy-renew" class="btn btn-primary btn-sm">Go to Buy / Renew</a>
                        <a href="pricing.php" class="btn btn-outline-primary btn-sm">View plans</a>
                        <a href="logout.php" class="btn btn-outline-secondary btn-sm">Logout</a>
                        <?php if ($pendingPayment): ?>
                            <div class="alert alert-success small mt-3">
                                <p class="mb-1"><strong>Payment pending</strong></p>
                                <p class="mb-1">Plan: <?php echo e($pendingPayment['plan']); ?> (<?php echo e(ucfirst($pendingPayment['cycle'])); ?>)</p>
                                <p class="mb-1">Amount: <?php echo e($pendingPayment['currency']); ?> <?php echo e(number_format((float)$pendingPayment['amount'], 2)); ?></p>
                                <div class="mb-2">
                                    <img src="<?php echo esc_url( 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=' . rawurlencode($pendingPayment['deeplink']) ); ?>" alt="UPI QR" />
                                </div>
                                <a href="<?php echo e($pendingPayment['deeplink']); ?>" class="btn btn-success btn-sm w-100">Pay via UPI</a>
                </div>
            <?php endif; ?>
        </div>
        <?php if (!$licensePayload): ?>
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Downloads</strong>
                </div>
                <div class="card-body">
                    <p class="text-muted small">Get the plugins and Android app, then log in using your portal account. If you prefer mobile, scan the QR for the APK.</p>
                    <div class="list-group list-group-flush mb-3">
                        <?php foreach ($downloadTypes as $k => $label): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><?php echo e($label); ?></strong>
                                    <div class="small text-muted"><?php echo $downloadLinks[$k] ? 'Ready to download' : 'Not provided yet'; ?></div>
                                </div>
                                <?php if (!empty($downloadLinks[$k])): ?>
                                    <a class="btn btn-sm btn-outline-primary" href="<?php echo esc_url($downloadLinks[$k]); ?>" target="_blank" rel="noopener">Download</a>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (!empty($downloadLinks['android'])): ?>
                        <div class="text-center">
                            <div class="fw-semibold mb-1">Scan to download Android app</div>
                            <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=<?php echo rawurlencode($downloadLinks['android']); ?>" alt="Android app QR" class="img-fluid rounded border">
                            <div class="small text-muted mt-2">Use your camera/QR scanner to open the download link on your phone.</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="card shadow-sm mt-3">
        <div class="card-header d-flex justify-content-between align-items-center">
            <strong>Usage</strong>
        </div>
        <div class="card-body">
            <div class="usage-grid">
                <div class="usage-card">
                    <div class="usage-label">
                        <span class="text-muted">Allowed Domains</span>
                        <span class="fw-bold"><?php echo e($domainUsageLabel); ?></span>
                    </div>
                    <div class="progress-shell">
                        <div class="progress-fill" style="width: <?php echo e($domainPercent); ?>%;"></div>
                    </div>
                </div>
                <div class="usage-card">
                    <div class="usage-label">
                        <span class="text-muted">Domain Whitelisting</span>
                        <span class="fw-bold"><?php echo e($whitelistUsageLabel); ?></span>
                    </div>
                    <div class="progress-shell">
                        <div class="progress-fill" style="width: <?php echo e($whitelistPercent); ?>%;"></div>
                    </div>
                </div>
                <div class="usage-card">
                    <div class="usage-label">
                        <span class="text-muted">Payment links</span>
                        <span class="fw-bold"><?php echo e($linksUsageLabel); ?></span>
                    </div>
                    <div class="progress-shell">
                        <div class="progress-fill" style="width: <?php echo e($linksPercent); ?>%;"></div>
                    </div>
                </div>
                <div class="usage-card">
                    <div class="usage-label">
                        <span class="text-muted">Landing pages</span>
                        <span class="fw-bold"><?php echo e($landingUsageLabel); ?></span>
                    </div>
                    <div class="progress-shell">
                        <div class="progress-fill" style="width: <?php echo e($landingPercent); ?>%;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm mt-3">
        <div class="card-body d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>
                <strong>Use the Android app as your backend</strong>
                <div class="text-muted small">Scan the connect QR to let the app capture UPI notifications and confirm your links.</div>
            </div>
            <a href="<?php echo e(licd_public_url('app_connect.php')); ?>" class="btn btn-primary btn-sm">Open App Connect</a>
        </div>
    </div>

    <?php if ($canBuildLanding): ?>
    <div class="card shadow-sm mt-3">
                <div class="card-body d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <div>
                        <strong>Payment links / Landing pages</strong>
                        <div class="text-muted small">Used: <?php echo $linksLimit > 0 ? ($linksUsed . '/' . $linksLimit) : ($linksUsed . '/unlimited'); ?></div>
                    </div>
                    <div class="d-flex gap-2 align-items-center">
                        <div class="progress-shell" style="width:160px;">
                            <div class="progress-fill" style="width: <?php echo e($linksPercent); ?>%;"></div>
                        </div>
                        <a href="user_links.php" class="btn btn-outline-secondary btn-sm">View links</a>
                        <a href="link_builder.php" class="btn btn-primary btn-sm <?php echo ($linksLimit > 0 && $linksRemaining <= 0) ? 'disabled' : ''; ?>">
                            Create link / landing page
                        </a>
                    </div>
                </div>
    </div>
    <?php endif; ?>

    <div class="card shadow-sm mt-3" id="domains" style="scroll-margin-top: 96px;">
        <div class="card-header d-flex justify-content-between align-items-center">
            <strong>Domain whitelisting</strong>
            <div class="d-flex align-items-center gap-2">
                <span class="badge bg-dark border border-secondary text-secondary">Approved: <?php echo e($approvedDomains); ?></span>
                <span class="badge bg-dark border border-warning text-warning">Pending: <?php echo e($pendingDomains); ?></span>
                <span class="badge bg-dark border border-secondary text-secondary">Limit: <?php echo e($domainLimit > 0 ? $domainLimit : 'Unlimited'); ?></span>
            </div>
        </div>
        <div class="card-body">
            <div class="row g-2 mb-3">
                <div class="col-md-6">
                    <div class="border rounded p-3 h-100">
                        <div class="fw-semibold mb-1">DNS to point</div>
                        <div class="small text-muted">CNAME target:</div>
                        <code><?php echo e($dnsHost); ?></code>
                        <?php if ($dnsIp): ?>
                        <div class="small text-muted mt-2">A record (fallback):</div>
                        <code><?php echo e($dnsIp); ?></code>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="border rounded p-3 h-100">
                        <div class="fw-semibold mb-1">How to connect a custom domain</div>
                        <ol class="small text-muted mb-0 ps-3">
                            <li>Create a CNAME in your DNS pointing to <code><?php echo e($dnsHost); ?></code> (or A to <?php echo e($dnsIp ?: 'your host'); ?> if CNAME not allowed).</li>
                            <li>Add the domain below and submit a whitelisting request.</li>
                            <li>Once approved, pick it while creating links/landing pages.</li>
                            <li>Limit: <?php echo e($domainLimit > 0 ? $domainLimit : 'Unlimited'); ?> (used: <?php echo e($approvedDomains); ?>).</li>
                        </ol>
                    </div>
                </div>
            </div>
            <form method="post" class="row g-2 mb-3">
                <input type="hidden" name="action" value="domain_request">
                <div class="col-md-8">
                    <input type="text" name="domain" class="form-control" placeholder="example.com" required>
                </div>
                <div class="col-md-4 d-grid">
                    <button type="submit" class="btn btn-primary">Submit domain</button>
                </div>
            </form>
            <?php if (!empty($domains)): ?>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                            <tr>
                                <th>Domain</th>
                                <th>Status</th>
                                <th>Requested</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($domains as $d): ?>
                                <tr>
                                    <td><?php echo e($d['domain']); ?></td>
                                    <td><span class="badge bg-<?php echo $d['status']==='approved'?'success':($d['status']==='pending'?'warning':'secondary'); ?>"><?php echo e($d['status']); ?></span></td>
                                    <td><?php echo e($d['requested_at'] ?? ''); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted mb-0">No domains submitted yet.</p>
            <?php endif; ?>
            <p class="text-muted small mt-2">Primary domain from your profile is auto-whitelisted. Requests auto-approve after a few minutes if under plan limit.</p>
        </div>
    </div>
            <?php endif; ?>

            <div class="card shadow-sm mt-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Total payments received</strong>
                    <span class="text-success fw-bold"><?php echo e(number_format((float)$totalReceived, 2)); ?></span>
                </div>
            </div>

            <div class="card shadow-sm mt-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Recent payments</strong>
                    <a href="user_payment_logs.php" class="btn btn-sm btn-outline-primary">See more</a>
                </div>
                <div class="card-body">
                    <?php if (empty($paymentLogs)): ?>
                        <p class="text-muted small mb-0">No payments recorded yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th>Order</th>
                                        <th>Customer</th>
                                        <th>UPI</th>
                                        <th>Txn</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($paymentLogs, 0, 5) as $payment): ?>
                                        <tr>
                                            <td><?php echo e($payment['id']); ?></td>
                                            <td><?php echo e($user['name'] ?? $user['email']); ?></td>
                                            <td><?php echo e($payment['payer_vpa'] ?? ''); ?></td>
                                            <td><code><?php echo e($payment['txn_id'] ?? ''); ?></code></td>
                                            <td><?php echo e(number_format((float)$payment['amount'], 2)); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card shadow-sm mt-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Recent payment requests</strong>
                    <a href="user_payment_requests.php" class="btn btn-sm btn-outline-primary">See more</a>
                </div>
                <div class="card-body">
                    <?php if (empty($paymentRequests)): ?>
                        <p class="text-muted small mb-0">No submitted payment requests.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Plan</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Submitted</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($paymentRequests, 0, 2) as $req): ?>
                                        <tr>
                                            <td><?php echo e($req['id']); ?></td>
                                            <td><?php echo e($req['plan_name']); ?></td>
                                            <td><?php echo e($req['currency']); ?> <?php echo e(number_format((float)$req['amount'], 2)); ?></td>
                                            <td><span class="badge bg-warning text-dark"><?php echo e($req['state'] ?: 'pending'); ?></span></td>
                                            <td><?php echo e($req['created_at']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <?php if (!$licensePayload): ?>
            <div class="card shadow-sm mt-3">
                <div class="card-header d-flex justify-content-between align-items-center" id="buy-renew">
                    <strong>Buy / renew subscription</strong>
                    <a href="pricing.php" class="btn btn-sm btn-outline-primary">View plans</a>
                </div>
                <div class="card-body">
                    <p class="text-muted small mb-2">
                        Create a payment request via eGo Payments. Your account login is used for access; no license key entry required.
                    </p>
                    <?php if (!empty($availablePlans)): ?>
                        <form method="post" class="mb-2">
                            <input type="hidden" name="action" value="buy_plan">
                            <div class="mb-2">
                                <label class="form-label text-muted">Select plan</label>
                                <select name="plan_slug" class="form-select form-select-sm" required>
                                    <option value="">Choose a plan</option>
                                    <?php foreach ($availablePlans as $plan): ?>
                                        <option value="<?php echo e($plan['slug']); ?>"><?php echo e($plan['name']); ?> (INR <?php echo e(number_format((float)$plan['monthly_price'], 2)); ?>/mo - Domains: <?php echo e($plan['domain_limit'] > 0 ? $plan['domain_limit'] : 'Unlimited'); ?>, Landing: <?php echo e($plan['landing_pages_limit']); ?>, Links: <?php echo e($plan['payment_links_limit']); ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-2">
                                <label class="form-label text-muted">Billing</label>
                                <select name="cycle" class="form-select form-select-sm">
                                    <option value="monthly">Monthly</option>
                                    <option value="yearly">Yearly</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm w-100">Buy / Renew Now</button>
                        </form>
                    <?php else: ?>
                        <p class="text-muted small mb-0">No plans available yet.</p>
                    <?php endif; ?>
                    <?php if ($paymentLink): ?>
                        <div class="alert alert-success small mt-2">
                            <p class="mb-1">Payment link generated. Complete your payment by:</p>
                            <div class="d-grid gap-2">
                                <button type="button" class="btn btn-success btn-sm" onclick="document.getElementById('licd-pay-modal').classList.remove('d-none');">Open Payment Popup</button>
                                <a href="<?php echo e($paymentLink); ?>" class="btn btn-outline-success btn-sm">Open in UPI App</a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($paymentRequests)): ?>
            <div class="card shadow-sm mt-3">
                <div class="card-header">
                    <strong>Your payment requests</strong>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Plan</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($paymentRequests as $req): ?>
                                    <tr>
                                        <td><?php echo e($req['id']); ?></td>
                                        <td><?php echo e($req['plan_name']); ?> (<?php echo e(ucfirst($req['cycle'])); ?>)</td>
                                        <td><?php echo e($req['currency']); ?> <?php echo e(number_format((float)$req['amount'], 2)); ?></td>
                                        <td><span class="badge bg-<?php echo $req['state'] === 'completed' ? 'success' : ($req['state'] === 'submitted' ? 'warning' : 'secondary'); ?>"><?php echo e($req['state'] ?: 'pending'); ?></span></td>
                                        <td><?php echo e($req['created_at']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
    .usage-grid { display:grid; grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap:12px; }
    .usage-card { padding:14px; border:1px solid #1f2937; border-radius:12px; background:#0b1224; }
    .usage-label { display:flex; justify-content:space-between; font-size:13px; color:#cbd5e1; }
    .progress-shell { background:#111827; border-radius:999px; overflow:hidden; height:10px; margin-top:6px; border:1px solid #1f2937; }
    .progress-fill { height:100%; background:linear-gradient(90deg, #10b981, #06b6d4); width:0%; transition:width 0.4s ease; }
</style>
<?php if ($paymentLink): ?>
<style>
    .licd-modal-backdrop {
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.65);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
    }
    .licd-modal {
        background: #0f1115;
        color: #e5e7eb;
        border-radius: 14px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.35);
        max-width: 980px;
        width: 96%;
        padding: 24px;
    }
    .licd-modal .qr-box {
        border: 1px solid #1f2937;
        border-radius: 12px;
        padding: 12px;
        background: #0b0d11;
    }
    .licd-modal .meta-row {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        margin-top: 8px;
    }
    .licd-logo-row {
        text-align: center;
        margin-bottom: 8px;
    }
    .licd-timer {
        font-weight: 700;
        color: #22c55e;
        text-align: center;
        font-size: 18px;
    }
</style>
<div id="licd-pay-modal" class="licd-modal-backdrop d-none">
    <div class="licd-modal">
        <div class="licd-logo-row">
            <div class="text-muted small">Pay securely by</div>
            <div class="fw-bold d-inline-flex align-items-center gap-2">
                <?php $logo = get_payment_logo_url(); ?>
                <?php if (!empty($logo)): ?>
                    <img src="<?php echo esc_url($logo); ?>" alt="Brand logo" style="max-height:28px;">
                <?php endif; ?>
                <span>eGo Payments</span>
            </div>
            <div id="licd-timer" class="licd-timer mt-1">05:00</div>
        </div>
        <div class="d-flex justify-content-end mb-2">
            <button class="btn btn-sm btn-outline-secondary" onclick="document.getElementById('licd-pay-modal').classList.add('d-none');">Cancel</button>
        </div>
        <div class="row g-3 align-items-center">
            <div class="col-md-6 text-center">
                <p class="mb-2">Scan this QR from any UPI app</p>
                <div class="qr-box mb-2">
                    <img src="<?php echo esc_url('https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=' . rawurlencode($paymentLink)); ?>" alt="UPI QR">
                </div>
                <small class="text-muted">Scan this QR to pay</small>
            </div>
            <div class="col-md-6">
                <div class="meta-row">
                    <span>Amount due</span>
                    <strong><?php echo e($pendingPayment['currency'] ?? 'INR'); ?> <?php echo e(number_format((float)($pendingPayment['amount'] ?? 0), 2)); ?></strong>
                </div>
                <div class="meta-row">
                    <span>UPI ID</span>
                    <strong><?php echo e(get_payment_gateway_upi()); ?></strong>
                </div>
                <div class="meta-row">
                    <span>Plan</span>
                    <strong><?php echo e($pendingPayment['plan'] ?? ''); ?></strong>
                </div>
                <hr class="text-secondary my-3">
                <form id="licd-proof-form" method="post" action="payment_proof.php" enctype="multipart/form-data" class="small d-none">
                    <p class="text-warning small">Timer expired. Submit payment details for review.</p>
                    <input type="hidden" name="payment_id" value="<?php echo e($pendingPayment['id'] ?? 0); ?>">
                    <div class="mb-2">
                        <label class="form-label text-muted">Payer name</label>
                        <input type="text" name="payer_name" class="form-control form-control-sm" required>
                    </div>
                    <div class="mb-2">
                        <label class="form-label text-muted">Payer UPI ID</label>
                        <input type="text" name="payer_upi" class="form-control form-control-sm" required>
                    </div>
                    <div class="mb-2">
                        <label class="form-label text-muted">Txn ID / UPI Ref</label>
                        <input type="text" name="txn_id" class="form-control form-control-sm" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted">Screenshot</label>
                        <input type="file" name="screenshot" class="form-control form-control-sm" accept="image/*">
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm w-100">Submit payment details</button>
                </form>
                <div id="licd-proof-locked" class="text-muted small">Waiting for confirmation. The submission form will appear if the timer expires.</div>
            </div>
        </div>
    </div>
</div>
<script>
    (function(){
        var timerEl = document.getElementById('licd-timer');
        if (!timerEl) return;
        var seconds = 300;
        var interval = setInterval(function(){
            seconds--;
            if (seconds <= 0) {
                clearInterval(interval);
                timerEl.textContent = 'Expired';
                var form = document.getElementById('licd-proof-form');
                var locked = document.getElementById('licd-proof-locked');
                if (form) form.classList.remove('d-none');
                if (locked) locked.classList.add('d-none');
                return;
            }
            var m = Math.floor(seconds/60).toString().padStart(2,'0');
            var s = (seconds%60).toString().padStart(2,'0');
            timerEl.textContent = m + ':' + s;
        }, 1000);
    })();
</script>
<?php endif; ?>
</body>
</html>
