<?php
require_once __DIR__ . '/../config.php';

$error = '';
$success = '';
$selectedPlan = sanitize_text_field($_GET['plan'] ?? '');
$selectedCycle = ($_GET['cycle'] ?? 'monthly') === 'yearly' ? 'yearly' : 'monthly';

if (is_post()) {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';
    $phone = trim($_POST['phone'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $trade = trim($_POST['trade_name'] ?? '');
    $hasWebsite = ($_POST['has_website'] ?? '') === 'yes';
    $website = trim($_POST['website_url'] ?? '');
    $turnover = $_POST['turnover'] ?? '';
    $category = trim($_POST['business_category'] ?? '');
    $regions = trim($_POST['regions'] ?? '');
    $about = trim($_POST['about'] ?? '');
    $accepted = isset($_POST['accept_terms']);

    if (!$accepted) {
        $error = 'You must accept the terms and conditions.';
    } elseif ($password !== $password_confirm) {
        $error = 'Passwords do not match.';
    } elseif (licd_get_user_by_email($email)) {
        $error = 'Email is already in use.';
    } else {
        $user_id = licd_create_user($name, $email, $password, 'customer');
        save_user_profile($user_id, [
            'phone' => $phone,
            'country' => $country,
            'username' => $username,
            'trade_name' => $trade,
            'has_website' => $hasWebsite,
            'website_url' => $website,
            'turnover_range' => $turnover,
            'business_category' => $category,
            'regions' => $regions,
            'about' => $about,
        ]);
        $_SESSION['user_id'] = $user_id;
        set_flash('success', '🎉 Welcome to eGo Payment! You can now accept payments with zero processing fee.');
        redirect('dashboard.php');
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>eGo Signup</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="auth-card card auth-paper">
        <div class="auth-header text-center mb-3">
            <p class="text-muted mb-0">SecurePay Gateway</p>
            <h4 class="mb-1">Create account to continue</h4>
        </div>
        <?php if ($error): ?>
            <div class="alert alert-danger text-center"><?php echo e($error); ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="mb-3">
                <label class="form-label text-muted">Full name</label>
                <input type="text" name="name" class="form-control" placeholder="John Doe" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Username</label>
                <input type="text" name="username" class="form-control" placeholder="yourusername" required value="<?php echo e($selectedPlan ? $selectedPlan . '_' : ''); ?>">
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Email</label>
                <input type="email" name="email" class="form-control" placeholder="you@example.com" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Phone</label>
                <input type="text" name="phone" class="form-control" placeholder="+91-XXXXXXXXXX" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Country</label>
                <input type="text" name="country" class="form-control" placeholder="India" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Trade name / Company</label>
                <input type="text" name="trade_name" class="form-control" placeholder="Your business name" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Do you have a website?</label>
                <select name="has_website" class="form-select" required>
                    <option value="no">No</option>
                    <option value="yes">Yes</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Website URL (if any)</label>
                <input type="url" name="website_url" class="form-control" placeholder="https://example.com">
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Monthly turnover</label>
                <select name="turnover" class="form-select" required>
                    <option value="0-50k">0-50k</option>
                    <option value="50k-100k">50k-100k</option>
                    <option value="100k-plus">More than 100k</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Business category</label>
                <input type="text" name="business_category" class="form-control" placeholder="e.g., SaaS, Retail" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Regions / Countries of business</label>
                <input type="text" name="regions" class="form-control" placeholder="India, UAE" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Please tell us about your business</label>
                <textarea name="about" class="form-control" rows="3" placeholder="Short description" required></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Min. 8 characters" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Confirm Password</label>
                <input type="password" name="password_confirm" class="form-control" placeholder="Repeat your password" required>
            </div>
            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" name="accept_terms" id="acceptTerms" required>
                <label class="form-check-label text-muted" for="acceptTerms">I accept the terms &amp; conditions</label>
            </div>
            <button type="submit" class="btn btn-primary w-100">Create account &amp; pay</button>
        </form>
        <div class="text-center mt-3">
            <small class="text-muted">Cards are processed by your trusted provider.</small>
        </div>
        <div class="text-center mt-2">
            <a href="pricing.php" class="btn btn-outline-light btn-sm">View plans</a>
        </div>
        <div class="text-center mt-3">
            <a href="login.php" class="btn btn-outline-light btn-sm">Log in instead</a>
        </div>
    </div>
</div>
</body>
</html>
