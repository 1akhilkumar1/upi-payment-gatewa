<?php
require_once __DIR__ . '/../config.php';

require_auth();
$user = current_user();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    set_flash('error', 'Order not found.');
    redirect('user_link_orders.php');
    exit;
}

$stmt = db()->prepare("SELECT * FROM payment_requests WHERE id = ? AND user_id = ? AND feature = 'link' LIMIT 1");
$stmt->execute([$id, $user['id']]);
$order = $stmt->fetch();
if (!$order) {
    set_flash('error', 'Order not found.');
    redirect('user_link_orders.php');
    exit;
}

$meta = $order['metadata'] ? json_decode($order['metadata'], true) : [];
$response = $order['response_json'] ? json_decode($order['response_json'], true) : [];
$linkSlug = $meta['link_slug'] ?? '';
$linkTitle = $meta['link_title'] ?? '';
$customerName = $meta['customer_name'] ?? '';
$customerEmail = $meta['customer_email'] ?? '';
$customerPhone = $meta['customer_phone'] ?? '';
$customerAddress = $meta['customer_address'] ?? '';
$invoice = $meta['invoice'] ?? '';
$payerName = $response['payer_name'] ?? ($meta['payer_name'] ?? '');
$payerUpi = $response['payer_upi'] ?? ($meta['payer_upi'] ?? '');
$payerTxn = $response['txn_id'] ?? ($meta['txn_id'] ?? '');
$proofShot = $response['screenshot'] ?? ($meta['screenshot'] ?? '');
$proofSubmitted = !empty($payerName) || !empty($payerUpi) || !empty($payerTxn) || !empty($proofShot);
$domain = DEFAULT_HOSTED_DOMAIN;
if ($linkSlug !== '') {
    $domain = $meta['domain'] ?? $domain;
    $domain = $domain !== '' ? $domain : DEFAULT_HOSTED_DOMAIN;
    $linkUrl = rtrim($domain, '/') . '/link/' . urlencode($linkSlug);
} else {
    $linkUrl = '';
}

$downloadUrl = '';
if ($linkSlug !== '' && !empty($order['subscription_id'])) {
    $stmt = db()->prepare("SELECT payload FROM hosted_links WHERE subscription_id = ? AND slug = ? LIMIT 1");
    $stmt->execute([$order['subscription_id'], $linkSlug]);
    $row = $stmt->fetch();
    if ($row && !empty($row['payload'])) {
        $payload = json_decode($row['payload'], true);
        if (is_array($payload)) {
            $downloadUrl = $payload['digital_file_url'] ?? '';
        }
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Order Details - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">eGo Customer Portal</a>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(licd_public_url('user_link_orders.php')); ?>" class="btn btn-outline-light btn-sm">Back to Orders</a>
                    <a href="<?php echo e(licd_public_url('dashboard.php')); ?>" class="btn btn-outline-light btn-sm">Dashboard</a>
                </div>
            </div>
        </nav>

        <div class="container-fluid py-2">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                        <div>
                            <h4 class="mb-1">Order Details</h4>
                            <div class="text-muted small"><?php echo e($order['created_at']); ?></div>
                        </div>
                        <span class="badge bg-<?php echo $order['state'] === 'completed' ? 'success' : ($order['state'] === 'submitted' ? 'warning' : 'secondary'); ?>">
                            <?php echo e($order['state']); ?>
                        </span>
                    </div>

                    <div class="row g-3 mt-2">
                        <div class="col-md-6">
                            <div class="small text-muted">Link title</div>
                            <div><?php echo e($linkTitle); ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="small text-muted">Amount</div>
                            <div><?php echo e(number_format((float)$order['amount'], 2)); ?> <?php echo e($order['currency']); ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="small text-muted">Customer</div>
                            <div><?php echo e($customerName); ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="small text-muted">Email</div>
                            <div><?php echo e($customerEmail); ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="small text-muted">Phone</div>
                            <div><?php echo e($customerPhone); ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="small text-muted">Address</div>
                            <div><?php echo e($customerAddress); ?></div>
                        </div>
                        <?php if ($invoice): ?>
                        <div class="col-md-6">
                            <div class="small text-muted">Invoice</div>
                            <div><?php echo e($invoice); ?></div>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($order['txn_id'])): ?>
                        <div class="col-md-6">
                            <div class="small text-muted">Payment UTR</div>
                            <div><?php echo e($order['txn_id']); ?></div>
                        </div>
                        <?php endif; ?>
                        <?php if ($payerName || $payerUpi || $payerTxn || $proofShot): ?>
                        <div class="col-12">
                            <div class="small text-muted">Submitted proof</div>
                            <div class="d-flex flex-wrap gap-3 mt-1">
                                <?php if ($payerName): ?><div><strong>Name:</strong> <?php echo e($payerName); ?></div><?php endif; ?>
                                <?php if ($payerUpi): ?><div><strong>UPI:</strong> <?php echo e($payerUpi); ?></div><?php endif; ?>
                                <?php if ($payerTxn): ?><div><strong>Txn:</strong> <?php echo e($payerTxn); ?></div><?php endif; ?>
                                <?php if ($proofShot): ?><div><a href="<?php echo e($proofShot); ?>" target="_blank" rel="noopener">View screenshot</a></div><?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if ($linkUrl): ?>
                        <div class="col-md-6">
                            <div class="small text-muted">Link</div>
                            <div><a href="<?php echo e($linkUrl); ?>" target="_blank" rel="noopener">Open link</a></div>
                        </div>
                        <?php endif; ?>
                        <?php if ($downloadUrl && $order['state'] === 'completed'): ?>
                        <div class="col-md-6">
                            <div class="small text-muted">Download</div>
                            <div><a href="<?php echo e($downloadUrl); ?>" target="_blank" rel="noopener">Download file</a></div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if (in_array($order['state'], ['submitted', 'pending'], true) || $proofSubmitted): ?>
                        <div class="d-flex gap-2 mt-3">
                            <form method="post" action="user_link_order_action.php">
                                <input type="hidden" name="order_id" value="<?php echo e($order['id']); ?>">
                                <input type="hidden" name="action" value="approve">
                                <button class="btn btn-success btn-sm" type="submit">Approve</button>
                            </form>
                            <form method="post" action="user_link_order_action.php">
                                <input type="hidden" name="order_id" value="<?php echo e($order['id']); ?>">
                                <input type="hidden" name="action" value="reject">
                                <button class="btn btn-outline-danger btn-sm" type="submit">Reject</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
