<?php
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['admin_original_user_id'])) {
    set_flash('error', 'No admin session to restore.');
    redirect('login.php');
    exit;
}
$adminId = (int)$_SESSION['admin_original_user_id'];
$admin = licd_get_user_by_id($adminId);
if (!$admin || $admin['role'] !== 'admin') {
    unset($_SESSION['admin_original_user_id']);
    set_flash('error', 'Original admin session not found.');
    redirect('login.php');
    exit;
}
$_SESSION['user_id'] = $adminId;
unset($_SESSION['admin_original_user_id']);
set_flash('success', 'Restored admin session.');
redirect('admin_dashboard.php');
