<?php
require_once __DIR__ . '/../config.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$user = licd_get_user_by_id($id);
if (!$user) {
    set_flash('error', 'User not found.');
    redirect('manage_users.php');
    exit;
}
$profile = get_user_profile($id) ?: [];

if (is_post()) {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? $user['role'];
    $status = $_POST['status'] ?? $user['status'];
    $password = $_POST['password'] ?? '';
    $profileData = [
        'phone' => trim($_POST['phone'] ?? ''),
        'country' => trim($_POST['country'] ?? ''),
        'username' => trim($_POST['username'] ?? ''),
        'trade_name' => trim($_POST['trade_name'] ?? ''),
        'has_website' => !empty($_POST['has_website']),
        'website_url' => trim($_POST['website_url'] ?? ''),
        'turnover_range' => trim($_POST['turnover_range'] ?? ''),
        'business_category' => trim($_POST['business_category'] ?? ''),
        'regions' => trim($_POST['regions'] ?? ''),
        'about' => trim($_POST['about'] ?? ''),
    ];
    $stmt = db()->prepare("UPDATE users SET name = ?, email = ?, role = ?, status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$name, $email, $role, $status, $id]);
    if ($password !== '') {
        update_user_password($id, $password);
    }
    save_user_profile($id, $profileData);
    set_flash('success', 'User updated.');
    redirect('admin_user_edit.php?id=' . $id);
    exit;
}
$flashes = pull_all_flash();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit user - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Edit user</h3>
        <a href="manage_users.php" class="btn btn-outline-secondary btn-sm">Back</a>
    </div>
    <?php foreach ($flashes as $key => $message): ?>
        <div class="alert alert-<?php echo e($key === 'error' ? 'danger' : ($key === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
            <?php echo e($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
    <form method="post" class="card shadow-sm p-3">
        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($user['name']); ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo e($user['email']); ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Password (leave blank to keep)</label>
                <input type="password" name="password" class="form-control">
            </div>
            <div class="col-md-3">
                <label class="form-label">Role</label>
                <select name="role" class="form-select">
                    <option value="admin" <?php echo $user['role']==='admin'?'selected':''; ?>>Admin</option>
                    <option value="customer" <?php echo $user['role']==='customer'?'selected':''; ?>>Customer</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="active" <?php echo $user['status']==='active'?'selected':''; ?>>Active</option>
                    <option value="inactive" <?php echo $user['status']==='inactive'?'selected':''; ?>>Inactive</option>
                </select>
            </div>
        </div>
        <hr>
        <h5>Profile</h5>
        <div class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Phone</label>
                <input type="text" name="phone" class="form-control" value="<?php echo e($profile['phone'] ?? ''); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Country</label>
                <input type="text" name="country" class="form-control" value="<?php echo e($profile['country'] ?? ''); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" value="<?php echo e($profile['username'] ?? ''); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Trade name</label>
                <input type="text" name="trade_name" class="form-control" value="<?php echo e($profile['trade_name'] ?? ''); ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Website</label>
                <input type="url" name="website_url" class="form-control" value="<?php echo e($profile['website_url'] ?? ''); ?>">
            </div>
            <div class="col-md-2">
                <div class="form-check mt-4">
                    <input class="form-check-input" type="checkbox" name="has_website" id="hasWebsite" <?php echo !empty($profile['has_website'])?'checked':''; ?>>
                    <label class="form-check-label" for="hasWebsite">Has website</label>
                </div>
            </div>
            <div class="col-md-4">
                <label class="form-label">Turnover range</label>
                <input type="text" name="turnover_range" class="form-control" value="<?php echo e($profile['turnover_range'] ?? ''); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Business category</label>
                <input type="text" name="business_category" class="form-control" value="<?php echo e($profile['business_category'] ?? ''); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Regions</label>
                <input type="text" name="regions" class="form-control" value="<?php echo e($profile['regions'] ?? ''); ?>">
            </div>
            <div class="col-12">
                <label class="form-label">About</label>
                <textarea name="about" class="form-control"><?php echo e($profile['about'] ?? ''); ?></textarea>
            </div>
        </div>
        <div class="mt-3">
            <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
