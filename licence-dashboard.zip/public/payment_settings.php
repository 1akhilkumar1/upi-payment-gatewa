<?php
require_once __DIR__ . '/../config.php';

require_admin();
if (!is_post()) {
    redirect('admin_dashboard.php');
}

$gateway = trim($_POST['gateway_name'] ?? '');
$upi = trim($_POST['gateway_upi'] ?? '');
$currency = trim($_POST['gateway_currency'] ?? 'INR');
$domainFee = $_POST['extra_domain_fee'] ?? '';
$linkFee = $_POST['extra_link_fee'] ?? '';
$upgradeFee = $_POST['upgrade_fee'] ?? '';
$allowedPkgs = trim($_POST['allowed_packages'] ?? '');
$logoUrl = trim($_POST['payment_logo_url'] ?? '');
$reminderDays = (int)($_POST['renewal_reminder_days'] ?? 2);
$domainAutoApproveMinutes = (int)($_POST['domain_auto_approve_minutes'] ?? 5);
$regenerateSecret = isset($_POST['regenerate_secret']) && $_POST['regenerate_secret'] === '1';
$regenerateAdminKey = isset($_POST['regenerate_admin_key']) && $_POST['regenerate_admin_key'] === '1';

if ($gateway !== '') {
    set_payment_gateway_name($gateway);
}
if ($upi !== '') {
    set_payment_gateway_upi($upi);
}
if ($currency !== '') {
    set_setting('payment_gateway_currency', strtoupper($currency));
}
set_extra_domain_fee($domainFee);
set_extra_link_fee($linkFee);
set_upgrade_fee($upgradeFee);
if ($allowedPkgs !== '') {
    set_android_allowed_packages($allowedPkgs);
}
set_payment_logo_url($logoUrl);
if (!in_array($reminderDays, [2,3,7], true)) {
    $reminderDays = 2;
}
set_setting('renewal_reminder_days', $reminderDays);
if ($domainAutoApproveMinutes <= 0) {
    $domainAutoApproveMinutes = 5;
}
set_setting('domain_auto_approve_minutes', $domainAutoApproveMinutes);
if ($regenerateSecret) {
    set_app_hmac_secret(bin2hex(random_bytes(16)));
}
if ($regenerateAdminKey) {
    $ring = licd_get_app_keyring();
    $keyId = 'admin-' . substr(bin2hex(random_bytes(6)), 0, 8);
    $secret = bin2hex(random_bytes(16));
    $ring[$keyId] = $secret;
    update_option('licd_app_keyring', $ring, false);
    set_flash('success', 'Admin app key regenerated. Key ID: ' . $keyId);
}

set_flash('success', 'Payment gateway fees updated.');
redirect('admin_dashboard.php');
