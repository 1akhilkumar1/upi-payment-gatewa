<?php
require_once __DIR__ . '/../config.php';

if (!is_post()) {
    http_response_code(405);
    exit;
}

$paymentId = (int)($_POST['payment_id'] ?? 0);
$token = trim($_POST['token'] ?? '');
$payerName = trim($_POST['payer_name'] ?? '');
$payerUpi  = trim($_POST['payer_upi'] ?? '');
$txnId     = trim($_POST['txn_id'] ?? '');

if ($paymentId <= 0 || $token === '' || $payerName === '' || $payerUpi === '' || $txnId === '') {
    http_response_code(400);
    echo 'All fields are required.';
    exit;
}

$req = get_payment_request($paymentId);
if (!$req) {
    http_response_code(404);
    echo 'Payment request not found.';
    exit;
}
if (!verify_public_checkout_token($paymentId, $req['user_id'], $token)) {
    http_response_code(403);
    echo 'Invalid checkout token.';
    exit;
}

$proofPath = null;
if (!empty($_FILES['screenshot']['name'])) {
    $uploadsDir = __DIR__ . '/../logs/payment_proofs';
    if (!is_dir($uploadsDir)) {
        @mkdir($uploadsDir, 0755, true);
    }
    $ext = pathinfo($_FILES['screenshot']['name'], PATHINFO_EXTENSION);
    $filename = 'proof_' . $paymentId . '_' . time() . '.' . $ext;
    $dest = $uploadsDir . '/' . $filename;
    if (move_uploaded_file($_FILES['screenshot']['tmp_name'], $dest)) {
        $proofPath = rtrim(defined('LICD_PLUGIN_URL') ? LICD_PLUGIN_URL : (BASE_URL . '/wp-content/plugins/licence-dashboard/'), '/');
        $proofPath .= '/logs/payment_proofs/' . $filename;
    }
}

mark_payment_request($paymentId, 'submitted', $txnId, [
    'payer_name' => $payerName,
    'payer_upi'  => $payerUpi,
    'txn_id'     => $txnId,
    'screenshot' => $proofPath,
]);
update_payment_request_metadata($paymentId, [
    'payer_name' => $payerName,
    'payer_upi' => $payerUpi,
    'txn_id' => $txnId,
    'screenshot' => $proofPath,
]);

$redirect = 'checkout.php?id=' . urlencode((string)$paymentId) . '&public=1&token=' . urlencode($token) . '&proof=submitted';
header('Location: ' . $redirect);
exit;
