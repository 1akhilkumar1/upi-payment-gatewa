<?php
require_once __DIR__ . '/../config.php';
require_admin();
$export = isset($_GET['export']) && $_GET['export'] === 'csv';
$plans = list_plans(false);

if ($export) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=plans.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Slug','Name','Monthly','Annual','Domain limit','Active']);
    foreach ($plans as $p) {
        fputcsv($out, [$p['slug'], $p['name'], $p['monthly_price'], $p['annual_price'], $p['domain_limit'], $p['is_active'] ? 'yes' : 'no']);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Plan Library - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Plan library</h3>
        <div class="d-flex gap-2">
            <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back</a>
            <a href="?export=csv" class="btn btn-outline-primary btn-sm">Export CSV</a>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-striped">
            <thead>
                <tr>
                    <th>Slug</th>
                    <th>Name</th>
                    <th>Monthly</th>
                    <th>Annual</th>
                    <th>Domain limit</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($plans as $p): ?>
                    <tr>
                        <td><?php echo e($p['slug']); ?></td>
                        <td><?php echo e($p['name']); ?></td>
                        <td><?php echo e(number_format((float)$p['monthly_price'], 2)); ?></td>
                        <td><?php echo e(number_format((float)$p['annual_price'], 2)); ?></td>
                        <td><?php echo e($p['domain_limit']); ?></td>
                        <td><span class="badge bg-<?php echo $p['is_active'] ? 'success' : 'secondary'; ?>"><?php echo $p['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
