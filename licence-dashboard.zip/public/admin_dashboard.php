
<?php
require_once __DIR__ . '/../config.php';

require_admin();

$downloadTypes = [
    'woo' => 'WooCommerce Plugin',
    'edd' => 'EDD Plugin',
    'standalone' => 'Standalone Plugin',
    'android' => 'Android App',
];
$downloadLinks = [];
foreach ($downloadTypes as $k => $_) {
    $downloadLinks[$k] = get_setting('download_' . $k . '_url', '');
}
if (is_post() && isset($_POST['action']) && $_POST['action'] === 'upload_download') {
    $type = $_POST['download_type'] ?? '';
    if (!isset($downloadTypes[$type])) {
        set_flash('error', 'Invalid download type.');
        redirect('admin_dashboard.php');
        exit;
    }
    $customUrl = trim($_POST['download_url'] ?? '');
    $finalUrl = '';
    if (!empty($_FILES['download_file']['tmp_name'])) {
        $uploadsDir = LICD_PLUGIN_DIR . 'downloads';
        if (!is_dir($uploadsDir)) {
            @mkdir($uploadsDir, 0755, true);
        }
        $original = basename($_FILES['download_file']['name']);
        $safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', $original);
        $target = $uploadsDir . '/' . uniqid($type . '_', true) . '_' . $safeName;
        if (@move_uploaded_file($_FILES['download_file']['tmp_name'], $target)) {
            $finalUrl = rtrim(LICD_PLUGIN_URL, '/') . '/downloads/' . basename($target);
        } else {
            set_flash('error', 'Upload failed. Please try again.');
            redirect('admin_dashboard.php');
            exit;
        }
    } elseif ($customUrl !== '') {
        $finalUrl = $customUrl;
    } else {
        set_flash('error', 'Please upload a file or provide a URL.');
        redirect('admin_dashboard.php');
        exit;
    }
    set_setting('download_' . $type . '_url', $finalUrl);
    set_flash('success', $downloadTypes[$type] . ' link updated.');
    redirect('admin_dashboard.php');
    exit;
}
$totalUsers = db()->query("SELECT COUNT(*) AS c FROM users")->fetch()['c'];
$totalSubs  = db()->query("SELECT COUNT(*) AS c FROM subscriptions")->fetch()['c'];
$activeSubs = db()->query("SELECT COUNT(*) AS c FROM subscriptions WHERE status = 'active'")->fetch()['c'];
$pendingRequests = list_pending_domain_requests();
$plans = list_plans(false);
$renewalReminderDays = (int)get_setting('renewal_reminder_days', 2);
if (!in_array($renewalReminderDays, [2,3,7], true)) { $renewalReminderDays = 2; }
$renewals = upcoming_renewals($renewalReminderDays);
$linkStats = hosted_link_stats();
$recentPayments = recent_payment_syncs(10);
$gatewayName = get_payment_gateway_name();
$gatewayUpi = get_payment_gateway_upi();
$paymentLogo = get_payment_logo_url();
$allowedPkgs = get_android_allowed_packages();
$domainAutoApproveMinutes = (int)get_setting('domain_auto_approve_minutes', 5);
if ($domainAutoApproveMinutes <= 0) { $domainAutoApproveMinutes = 5; }
$appSecret = get_app_hmac_secret();
$appKeyring = licd_get_app_keyring();
$adminKeyId = '';
$adminKeySecret = '';
foreach ($appKeyring as $kid => $sec) {
    if ($kid !== 'primary') { $adminKeyId = $kid; $adminKeySecret = $sec; break; }
}
if ($adminKeyId === '' && $appSecret) {
    $adminKeyId = 'primary';
    $adminKeySecret = $appSecret;
}
$extraDomainFee = get_extra_domain_fee();
$extraLinkFee = get_extra_link_fee();
$upgradeFee = get_upgrade_fee();
$flashes = pull_all_flash();
$lastPing = get_option('licd_last_app_ping', []);
$connectedAgo = null;
if (!empty($lastPing['ts'])) {
    $connectedAgo = time() - intval($lastPing['ts']);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">eGo Admin</a>
                <div class="d-flex gap-2">
                    <a class="btn btn-outline-light btn-sm" href="admin_logs.php">Logs</a>
                    <a class="btn btn-outline-light btn-sm" href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
        <div class="container-fluid py-2">
            <?php foreach ($flashes as $key => $message): ?>
                <div class="alert alert-<?php echo e($key === 'error' ? 'danger' : ($key === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
                    <?php echo e($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <p class="text-muted small mb-1">Total users</p>
                            <h5><?php echo e($totalUsers); ?></h5>
                            <small class="text-muted">People registered on the platform.</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <p class="text-muted small mb-1">Total subscriptions</p>
                            <h5><?php echo e($totalSubs); ?></h5>
                            <small class="text-muted">All license records.</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <p class="text-muted small mb-1">Active subscriptions</p>
                            <h5><?php echo e($activeSubs); ?></h5>
                            <small class="text-muted">Currently unlocked users.</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-7">
                    <div class="card shadow-sm">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <strong>Pending domain requests</strong>
                            <span class="small text-muted"><?php echo e(count($pendingRequests)); ?> waiting</span>
                        </div>
                        <div class="card-body">
                            <?php if (empty($pendingRequests)): ?>
                                <p class="text-muted mb-0">All domain requests have been reviewed.</p>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-sm mb-0 table-borderless">
                                        <thead>
                                            <tr>
                                                <th>Domain</th>
                                                <th>User</th>
                                                <th>Plan</th>
                                                <th>Requested</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($pendingRequests as $request): ?>
                                                <tr>
                                                    <td><?php echo e($request['domain']); ?></td>
                                                    <td><?php echo e($request['user_email']); ?></td>
                                                    <td><?php echo e($request['plan_slug']); ?></td>
                                                    <td><?php echo e($request['requested_at']); ?></td>
                                                    <td>
                                                        <form method="post" action="update_domain_request.php" class="d-flex gap-1 align-items-center flex-wrap">
                                                            <input type="hidden" name="domain_id" value="<?php echo e($request['id']); ?>">
                                                            <select name="action" class="form-select form-select-sm">
                                                                <option value="approve">Approve</option>
                                                                <option value="reject">Reject</option>
                                                                <option value="pending">Keep pending</option>
                                                            </select>
                                                            <input type="text" name="admin_note" class="form-control form-control-sm" placeholder="Note (optional)">
                                                            <button class="btn btn-sm btn-primary" type="submit">Save</button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <strong>Quick actions</strong>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="manage_users.php" class="btn btn-outline-primary btn-sm">Manage users</a>
                                <a href="manage_subscriptions.php" class="btn btn-outline-secondary btn-sm">Review subscriptions</a>
                                <a href="manage_plans.php" class="btn btn-outline-success btn-sm">Edit plans</a>
                                <a href="admin_domains.php" class="btn btn-outline-warning btn-sm">Domain setup & approvals</a>
                                <a href="admin_payment_requests.php" class="btn btn-outline-info btn-sm">Payment proofs</a>
                                <a href="admin_app_pairs.php" class="btn btn-outline-light btn-sm">App pairing status</a>
                            </div>
                            <p class="text-muted small mt-2">Plan updates can be created or toggled from the Plans page. Domain approvals sync instantly.</p>
                        </div>
                    </div>
                    <div class="card shadow-sm mt-3">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <strong>Plan library</strong>
                            <a href="plan_library_all.php" class="btn btn-sm btn-outline-primary">See more</a>
                        </div>
                        <div class="card-body">
                            <?php if (empty($plans)): ?>
                                <p class="text-muted small mb-0">No plans defined yet.</p>
                            <?php else: ?>
                                <?php foreach ($plans as $plan): ?>
                                    <div class="border rounded mb-2 p-2">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong><?php echo e($plan['name']); ?></strong>
                                                <div class="small text-muted">Slug: <?php echo e($plan['slug']); ?></div>
                                            </div>
                                            <span class="badge bg-<?php echo $plan['is_active'] ? 'success' : 'secondary'; ?>">
                                                <?php echo $plan['is_active'] ? 'Active' : 'Inactive'; ?>
                                            </span>
                                        </div>
                                        <div class="small text-muted mt-1">Domain limit: <?php echo e($plan['domain_limit'] > 0 ? $plan['domain_limit'] : 'Unlimited'); ?></div>
                                        <div class="small text-muted">Price: INR <?php echo e($plan['monthly_price']); ?> / month</div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            <a href="manage_plans.php" class="btn btn-link btn-sm">Go to plan editor</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-4 mt-4">
                <div class="col-lg-6">
                    <div class="card shadow-sm">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <strong>Upcoming renewals</strong>
                            <div class="d-flex gap-2 align-items-center">
                                <span class="small text-muted"><?php echo e(count($renewals)); ?> expiring soon</span>
                                <a href="renewals_all.php" class="btn btn-sm btn-outline-primary">See more</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php if (empty($renewals)): ?>
                                <p class="text-muted mb-0">No renewals due in the next 48 hours.</p>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-sm mb-0">
                                        <thead>
                                            <tr>
                                                <th>User</th>
                                                <th>Plan</th>
                                                <th>Valid until</th>
                                                <th>Left</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($renewals as $renewal): ?>
                                                <?php $expiry = strtotime($renewal['valid_until']); $daysLeft = $expiry ? max(0, ceil(($expiry - time()) / 86400)) : null; ?>
                                                <tr>
                                                    <td><?php echo e($renewal['user_email']); ?></td>
                                                    <td><span class="badge bg-info text-dark"><?php echo e($renewal['plan_slug']); ?></span></td>
                                                    <td><?php echo e($renewal['valid_until']); ?></td>
                                                    <td>
                                                        <?php if ($daysLeft !== null): ?>
                                                            <span class="badge bg-warning text-dark"><?php echo e($daysLeft); ?> day<?php echo $daysLeft === 1 ? '' : 's'; ?></span>
                                                        <?php else: ?>
                                                            <span class="text-muted small">Unknown</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <strong>Hosted link usage</strong>
                                <a href="links_usage_all.php" class="btn btn-sm btn-outline-primary">See more</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php if (empty($linkStats)): ?>
                                <p class="text-muted mb-0">No hosted links have been created yet.</p>
                            <?php else: ?>
                                <?php foreach ($linkStats as $stat): ?>
                                    <?php $limit = (int)$stat['payment_links_limit']; $available = $limit > 0 ? max(0, $limit - (int)$stat['used_links']) : null; ?>
                                    <div class="border rounded p-2 mb-2">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong><?php echo e($stat['plan_name']); ?></strong>
                                                <div class="small text-muted">Slug: <?php echo e($stat['plan_slug']); ?></div>
                                            </div>
                                            <span class="badge bg-<?php echo $limit === 0 ? 'secondary' : 'primary'; ?>">
                                                <?php echo e($limit > 0 ? $limit : 'Unlimited'); ?> links
                                            </span>
                                        </div>
                                        <p class="mb-1 small text-muted">
                                            Used: <?php echo e($stat['used_links']); ?> /
                                            <?php echo e($limit > 0 ? $limit : 'Unlimited'); ?>
                                        </p>
                                        <p class="mb-0 small text-muted">
                                            Remaining: <?php echo e($available !== null ? $available : 'Unlimited'); ?>
                                        </p>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card shadow-sm mt-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Recent payment sync logs</strong>
                    <div class="d-flex gap-2 align-items-center">
                        <span class="small text-muted"><?php echo e(count($recentPayments)); ?> records</span>
                        <a href="payment_sync_all.php" class="btn btn-sm btn-outline-primary">See more</a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (empty($recentPayments)): ?>
                        <p class="text-muted mb-0">No payment syncs recorded yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>User</th>
                                        <th>Feature</th>
                                        <th>Amount</th>
                                        <th>Payer VPA</th>
                                        <th>Txn</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentPayments as $payment): ?>
                                        <tr>
                                            <td><?php echo e(date('M d, Y H:i', strtotime($payment['recorded_at']))); ?></td>
                                            <td>
                                                <?php echo e($payment['email'] ?? 'Unknown'); ?>
                                                <div class="small text-muted"><?php echo e($payment['plan_slug']); ?></div>
                                            </td>
                                            <td>
                                                <?php echo e($payment['feature']); ?>
                                                <div class="small text-muted"><?php echo e($payment['source']); ?></div>
                                            </td>
                                            <td><?php echo e(number_format($payment['amount'], 2)); ?></td>
                                            <td><?php echo e($payment['payer_vpa'] ?? ''); ?></td>
                                            <td><code><?php echo e($payment['txn_id'] ?? ''); ?></code></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card shadow-sm mt-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Payment gateway settings</strong>
                    <div class="d-flex align-items-center gap-2">
                        <small class="text-muted">App uses these UPI details</small>
                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="document.getElementById('gw-settings-body').classList.toggle('d-none');">Show / Hide</button>
                    </div>
                </div>
                <div class="card-body" id="gw-settings-body">
                    <p class="small text-muted mb-2">Configure the UPI receiver details and per-feature fees.</p>
                    <form method="post" action="payment_settings.php" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Gateway name</label>
                            <input type="text" name="gateway_name" class="form-control form-control-sm" value="<?php echo e($gatewayName); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">UPI ID</label>
                            <input type="text" name="gateway_upi" class="form-control form-control-sm" value="<?php echo e($gatewayUpi); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Currency</label>
                            <input type="text" name="gateway_currency" class="form-control form-control-sm" value="<?php echo e(get_setting('payment_gateway_currency', 'INR')); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">App connection status</label>
                            <?php
                                $statusClass = 'secondary';
                                $statusText = 'Waiting for app';
                                if ($connectedAgo !== null) {
                                    if ($connectedAgo < 600) { $statusClass = 'success'; $statusText = 'Connected (last ping ' . intval($connectedAgo/60) . ' min ago)'; }
                                    else { $statusClass = 'warning'; $statusText = 'No ping in ' . intval($connectedAgo/60) . ' min'; }
                                }
                            ?>
                            <div class="alert alert-<?php echo $statusClass; ?> py-2 mb-2">
                                <strong><?php echo e($statusText); ?></strong>
                                <?php if (!empty($lastPing['device'])): ?>
                                    <div class="small text-muted">Device: <?php echo e($lastPing['device']); ?></div>
                                <?php endif; ?>
                            </div>
                            <small class="text-muted">App pings update this status when connected with valid signature.</small>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Payment popup logo URL</label>
                            <input type="url" name="payment_logo_url" class="form-control form-control-sm" placeholder="https://example.com/logo.png" value="<?php echo e($paymentLogo); ?>">
                            <small class="text-muted">Shown on the payment popup for branding (optional).</small>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Renewal reminder days</label>
                            <select name="renewal_reminder_days" class="form-select form-select-sm">
                                <?php foreach ([2,3,7] as $opt): ?>
                                    <option value="<?php echo e($opt); ?>" <?php echo $renewalReminderDays === $opt ? 'selected' : ''; ?>><?php echo e($opt); ?> days</option>
                                <?php endforeach; ?>
                            </select>
                            <small class="text-muted">Send expiry reminders before plan ends.</small>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Domain auto-approve (minutes)</label>
                            <input type="number" min="1" step="1" name="domain_auto_approve_minutes" class="form-control form-control-sm" value="<?php echo e($domainAutoApproveMinutes); ?>">
                            <small class="text-muted">Auto-approve pending domains after this delay.</small>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Extra domain fee (INR)</label>
                            <input type="number" step="0.01" min="0" name="extra_domain_fee" class="form-control form-control-sm" value="<?php echo e($extraDomainFee); ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Extra link fee (INR)</label>
                            <input type="number" step="0.01" min="0" name="extra_link_fee" class="form-control form-control-sm" value="<?php echo e($extraLinkFee); ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Upgrade fee (INR)</label>
                            <input type="number" step="0.01" min="0" name="upgrade_fee" class="form-control form-control-sm" value="<?php echo e($upgradeFee); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Allowed UPI app packages (CSV)</label>
                            <input type="text" name="allowed_packages" class="form-control form-control-sm" placeholder="com.google.android.apps.nbu.paisa.user, com.phonepe.app" value="<?php echo e($allowedPkgs); ?>">
                            <small class="text-muted">Optional list to push into the Android app capture filter.</small>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">App HMAC secret</label>
                            <div class="input-group input-group-sm">
                                <input type="text" readonly class="form-control" value="<?php echo e($appSecret); ?>">
                                <input type="hidden" name="regenerate_secret" value="0">
                                <button type="submit" class="btn btn-outline-danger" onclick="this.form.regenerate_secret.value='1'">Regenerate</button>
                            </div>
                            <small class="text-muted">Shared with the Android app for request signatures.</small>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Admin app key</label>
                            <div class="input-group input-group-sm">
                                <input type="text" readonly class="form-control" value="<?php echo e($adminKeyId ? ($adminKeyId . ' | ' . $adminKeySecret) : 'Not generated'); ?>">
                                <input type="hidden" name="regenerate_admin_key" value="0">
                                <button type="submit" class="btn btn-outline-primary" onclick="this.form.regenerate_admin_key.value='1'">Generate new admin key</button>
                            </div>
                            <small class="text-muted">Used by the admin Android app for payment confirmations.</small>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-sm btn-primary">Save gateway settings</button>
                        </div>
                    </form>
                    <div class="row mt-3 g-3">
                        <div class="col-md-6">
                            <?php
                                $baseApi = defined('LICD_PLUGIN_URL') ? rtrim(LICD_PLUGIN_URL, '/') : rtrim(site_url(), '/');
                                $appPayload = 'fourego://connect?base=' . rawurlencode($baseApi) . '&secret=' . rawurlencode($appSecret) . '&allowed=' . rawurlencode($allowedPkgs);
                            ?>
                            <p class="small text-muted mb-1">Android app connect QR</p>
                            <div class="d-flex gap-2 align-items-center">
                                <img src="<?php echo esc_url('https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . rawurlencode($appPayload)); ?>" alt="App connect QR" style="border:1px solid #e5e7eb;padding:6px;border-radius:6px;">
                                <div class="small text-muted">Scan in the Android app to set server URL, HMAC secret, and allowed UPI apps.</div>
                            </div>
                            <div class="mt-2">
                                <code class="small"><?php echo e($appPayload); ?></code>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <p class="small text-muted mb-1">UPI details</p>
                            <div class="alert alert-secondary small mb-0">
                                <div><strong>Merchant:</strong> <?php echo e($gatewayName); ?></div>
                                <div><strong>UPI ID:</strong> <?php echo e($gatewayUpi); ?></div>
                                <div><strong>Currency:</strong> <?php echo e(get_setting('payment_gateway_currency', 'INR')); ?></div>
                            </div>
                        </div>
                    </div>
                    <p class="small text-muted mt-2">Fees apply whenever a user requests an add-on or plan upgrade via the control panel.</p>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
