<?php
require_once __DIR__ . '/../config.php';

$slug = isset($_GET['slug']) ? trim($_GET['slug']) : '';
if ($slug === '') {
    http_response_code(404);
    echo 'Link not found.';
    exit;
}

$stmt = db()->prepare("SELECT * FROM hosted_links WHERE slug = ? LIMIT 1");
$stmt->execute([$slug]);
$link = $stmt->fetch();
if (!$link) {
    http_response_code(404);
    echo 'Link not found.';
    exit;
}

$payload = [];
if (!empty($link['payload'])) {
    $decoded = json_decode($link['payload'], true);
    $payload = is_array($decoded) ? $decoded : [];
}

$linkType = $payload['link_type'] ?? '';
if (!in_array($linkType, ['payment_link', 'payment_page'], true)) {
    header('Location: link.php?slug=' . urlencode($slug));
    exit;
}

$subscription = get_subscription_by_id($link['subscription_id']);
if (!$subscription) {
    http_response_code(403);
    echo 'Subscription not found.';
    exit;
}

$payAmount = 0;
if ($linkType === 'payment_link') {
    $payAmount = (float)($payload['payment_amount'] ?? ($link['amount'] ?? 0));
} elseif ($linkType === 'payment_page') {
    $regular = (float)($payload['regular_price'] ?? 0);
    $sale = (float)($payload['sale_price'] ?? 0);
    $payAmount = $sale > 0 ? $sale : ($regular > 0 ? $regular : (float)$link['amount']);
}
if ($payAmount <= 0) {
    http_response_code(400);
    echo 'Invalid amount.';
    exit;
}

$ownerProfile = get_user_profile($subscription['user_id']) ?: [];
$merchantUpi = trim((string)($ownerProfile['upi_id'] ?? ''));
$merchantName = trim((string)($ownerProfile['upi_name'] ?? ''));
if ($merchantUpi === '' || $merchantName === '') {
    http_response_code(400);
    echo 'Merchant UPI details are missing.';
    exit;
}

$meta = [
    'link_title' => $link['title'] ?? '',
    'product' => $slug,
    'link_slug' => $slug,
    'merchant_name' => $merchantName,
    'merchant_upi' => $merchantUpi,
];
$note = $link['title'] ?? 'Payment link';

$payment = create_payment_request(
    $subscription,
    'link',
    $payAmount,
    'one_time',
    $subscription['plan_slug'] ?? null,
    $meta,
    null,
    $note
);

if (!empty($payment['id'])) {
    $token = generate_public_checkout_token($payment['id'], $subscription['user_id']);
    $url = 'checkout.php?id=' . urlencode($payment['id']) . '&public=1&token=' . urlencode($token);
    header('Location: ' . $url);
    exit;
}

http_response_code(500);
echo 'Could not start checkout.';
