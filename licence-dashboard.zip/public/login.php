<?php
require_once __DIR__ . '/../config.php';

$error = '';
if (is_post()) {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($user = attempt_login($email, $password)) {
        set_flash('success', 'Welcome back ' . e($user['name'] ?? ''));
        if ($user['role'] === 'admin') {
            redirect('admin_dashboard.php');
        } else {
            redirect('dashboard.php');
        }
    } else {
        $error = 'Invalid credentials or inactive account.';
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>eGo Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="auth-card card auth-paper">
        <div class="auth-header text-center mb-3">
            <p class="text-muted mb-0">SecurePay Gateway</p>
            <h4 class="mb-1">Sign in to complete your payment</h4>
        </div>
        <?php if ($error): ?>
            <div class="alert alert-danger text-center"><?php echo e($error); ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="mb-3">
                <label class="form-label text-muted">Email</label>
                <input type="email" name="email" class="form-control" placeholder="you@example.com" required>
            </div>
            <div class="mb-3">
                <label class="form-label text-muted">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
            </div>
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="keepSignedIn">
                    <label class="form-check-label text-muted" for="keepSignedIn">Keep me signed in</label>
                </div>
                <?php $forgotUrl = function_exists('wp_lostpassword_url') ? wp_lostpassword_url() : (function_exists('licd_public_url') ? licd_public_url('forgot_password.php') : '#'); ?>
                <a href="<?php echo esc_url($forgotUrl); ?>" class="text-muted">Forgot password?</a>
            </div>
            <button type="submit" class="btn btn-primary w-100">Continue to payment</button>
        </form>
        <div class="text-center mt-3">
            <small class="text-muted">Having trouble? <a href="#">Contact support</a> before reloading.</small>
        </div>
        <div class="text-center mt-3">
            <a href="pricing.php" class="btn btn-outline-light btn-sm">View plans</a>
        </div>
        <div class="text-center mt-3">
            <a href="register.php" class="btn btn-outline-light btn-sm">Create account</a>
        </div>
    </div>
</div>
</body>
</html>
