<?php
require_once __DIR__ . '/../config.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$user = licd_get_user_by_id($id);
if (!$user) {
    set_flash('error', 'User not found.');
    redirect('manage_users.php');
    exit;
}
if (!isset($_SESSION['admin_original_user_id'])) {
    $_SESSION['admin_original_user_id'] = current_user()['id'] ?? null;
}
$_SESSION['user_id'] = $id;
set_flash('success', 'You are now logged in as ' . $user['email'] . '.');
redirect('dashboard.php');
