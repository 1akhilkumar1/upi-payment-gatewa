<?php
require_once __DIR__ . '/../config.php';

require_admin();

$formError = '';
$formSuccess = '';

if (is_post()) {
    if (isset($_POST['create'])) {
        $userId = (int)($_POST['user_id'] ?? 0);
        $planSlug = $_POST['plan'] ?? '';
        $validUntil = $_POST['valid_until'] ?? null;
        if ($validUntil) {
            $validUntil .= ' 23:59:59';
        }
        $autoRenew = isset($_POST['auto_renew']) ? 1 : 0;
        try {
            create_subscription($userId, $planSlug, $validUntil, $autoRenew, 'active');
            $formSuccess = 'Subscription created successfully.';
        } catch (Exception $exception) {
            $formError = $exception->getMessage();
        }
    } elseif (isset($_POST['update_sub'])) {
        $subId = (int)($_POST['sub_id'] ?? 0);
        $planSlug = $_POST['plan'] ?? '';
        $validUntil = $_POST['valid_until'] ?? null;
        if ($validUntil) {
            $validUntil .= ' 23:59:59';
        }
        $autoRenew = isset($_POST['auto_renew']) ? 1 : 0;
        $status = $_POST['status'] ?? 'active';
        try {
            update_subscription_details($subId, $planSlug, $validUntil, $autoRenew, $status);
            set_flash('success', 'Subscription updated.');
        } catch (Exception $e) {
            set_flash('error', 'Update failed: ' . $e->getMessage());
        }
        redirect('manage_subscriptions.php');
    } elseif (isset($_POST['delete_sub'])) {
        $subId = (int)($_POST['sub_id'] ?? 0);
        delete_subscription($subId);
        set_flash('success', 'Subscription deleted.');
        redirect('manage_subscriptions.php');
    }
}

$users = db()->query("SELECT id, email FROM users ORDER BY email ASC")->fetchAll();
$plans = list_plans();
$subs  = list_subscriptions();
$flashes = pull_all_flash();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Subscriptions - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Subscription Management</h3>
        <div>
            <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back to Dashboard</a>
            <a href="manage_plans.php" class="btn btn-outline-success btn-sm">Plan editor</a>
        </div>
    </div>
    <?php foreach ($flashes as $key => $message): ?>
        <div class="alert alert-<?php echo e($key === 'error' ? 'danger' : ($key === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
            <?php echo e($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>

    <?php if ($formError): ?>
        <div class="alert alert-danger"><?php echo e($formError); ?></div>
    <?php elseif ($formSuccess): ?>
        <div class="alert alert-success"><?php echo e($formSuccess); ?></div>
    <?php endif; ?>

    <div class="row g-4">
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-header">
                    <strong>Create subscription</strong>
                </div>
                <div class="card-body">
                    <form method="post">
                        <input type="hidden" name="create" value="1">
                        <div class="mb-2">
                            <label>User</label>
                            <select name="user_id" class="form-select form-select-sm" required>
                                <option value="">Select user</option>
                                <?php foreach ($users as $u): ?>
                                    <option value="<?php echo e($u['id']); ?>"><?php echo e($u['email']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-2">
                            <label>Plan</label>
                            <select name="plan" class="form-select form-select-sm" required>
                                <?php foreach ($plans as $plan): ?>
                                    <option value="<?php echo e($plan['slug']); ?>"><?php echo e($plan['name']); ?> (<?php echo e($plan['slug']); ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-2">
                            <label>Valid until</label>
                            <input type="date" name="valid_until" class="form-control form-control-sm">
                        </div>
                        <div class="mb-2 form-check">
                            <input class="form-check-input" type="checkbox" name="auto_renew" id="autoRenew" checked>
                            <label class="form-check-label" for="autoRenew">Enable auto-renew</label>
                        </div>
                        <button type="submit" class="btn btn-primary btn-sm w-100">Create subscription</button>
                    </form>
                    <p class="small text-muted mt-2">Access is tied to the user login; no license entry needed.</p>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header">
                    <strong>All subscriptions</strong>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>User</th>
                                    <th>Plan</th>
                                    <th>Status</th>
                                    <th>Valid until</th>
                                    <th>Domain usage</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($subs as $s): ?>
                                    <tr>
                                        <td><?php echo e($s['id']); ?></td>
                                        <td><?php echo e($s['email']); ?></td>
                                        <td><?php echo e($s['plan_name']); ?> (<?php echo e($s['plan_slug']); ?>)</td>
                                        <td>
                                            <span class="badge bg-<?php echo e($s['status'] === 'active' ? 'success' : 'warning'); ?>">
                                                <?php echo e($s['status']); ?>
                                            </span>
                                            <?php if ($s['auto_renew']): ?>
                                                <span class="badge bg-info text-dark">Auto-renew</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($s['valid_until'] ?? ''); ?></td>
                                        <td>
                                            <?php echo e($s['approved_domains']); ?> approved /
                                            <?php echo e($s['domain_limit'] > 0 ? $s['domain_limit'] : ''); ?>
                                        </td>
                                        <td>
                                            <form method="post" class="row g-1 align-items-center">
                                                <input type="hidden" name="sub_id" value="<?php echo e($s['id']); ?>">
                                                <div class="col-12">
                                                    <select name="plan" class="form-select form-select-sm">
                                                        <?php foreach ($plans as $plan): ?>
                                                            <option value="<?php echo e($plan['slug']); ?>" <?php if ($plan['slug'] === $s['plan_slug']) echo 'selected'; ?>>
                                                                <?php echo e($plan['name']); ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class="col-6">
                                                    <input type="date" name="valid_until" class="form-control form-control-sm" value="<?php echo e($s['valid_until'] ? substr($s['valid_until'], 0, 10) : ''); ?>">
                                                </div>
                                                <div class="col-6">
                                                    <select name="status" class="form-select form-select-sm">
                                                        <option value="active" <?php if ($s['status'] === 'active') echo 'selected'; ?>>active</option>
                                                        <option value="past_due" <?php if ($s['status'] === 'past_due') echo 'selected'; ?>>past_due</option>
                                                        <option value="cancelled" <?php if ($s['status'] === 'cancelled') echo 'selected'; ?>>cancelled</option>
                                                    </select>
                                                </div>
                                                <div class="col-6 form-check ms-1">
                                                    <input class="form-check-input" type="checkbox" name="auto_renew" id="autoRenew-<?php echo e($s['id']); ?>" <?php echo $s['auto_renew'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label small" for="autoRenew-<?php echo e($s['id']); ?>">Auto renew</label>
                                                </div>
                                                <div class="col-6 d-flex justify-content-end gap-1">
                                                    <button type="submit" name="update_sub" class="btn btn-sm btn-outline-primary">Save</button>
                                                    <button type="submit" name="delete_sub" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this subscription?');">Delete</button>
                                                </div>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
