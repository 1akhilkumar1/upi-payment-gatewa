<?php
require_once __DIR__ . '/../config.php';
require_auth();
$user = current_user();

// Simple token generation
$tokenValue = bin2hex(random_bytes(24));

// Deactivate existing tokens
$stmt = db()->prepare("UPDATE api_tokens SET active = 0 WHERE user_id = ?");
$stmt->execute([$user['id']]);

// Insert new token
$stmt = db()->prepare("INSERT INTO api_tokens (user_id, token, scopes, active, created_at)
                       VALUES (?, ?, 'wp_plugin,app', 1, NOW())");
$stmt->execute([$user['id'], $tokenValue]);

redirect('dashboard.php');
