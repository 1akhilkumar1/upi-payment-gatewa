<?php
require_once __DIR__ . '/../config.php';

require_auth();
$user = current_user();
$subscription = get_active_subscription_for_user($user['id']);
if (!$subscription) {
    set_flash('error', 'You need an active subscription to connect the mobile app.');
    redirect('dashboard.php');
    exit;
}

$flashes = pull_all_flash();
$baseUrl = rtrim(BASE_URL, '/');
$apiBase = $baseUrl;
$userKey = ensure_user_app_key($user['id']);
$secret = $userKey['secret'];
$keyId = $userKey['key_id'];
$lastPing = $userKey['last_ping'] ?? null;
$device = $userKey['device'] ?? '';
$pingAgo = null;
if ($lastPing) {
    $pingAgo = time() - strtotime($lastPing);
}
$allowed = get_android_allowed_packages();
$defaultAllowed = 'com.google.android.apps.nbu.paisa.user, com.phonepe.app, net.one97.paytm, in.org.npci.bhim';
$allowedLabel = $allowed !== '' ? $allowed : $defaultAllowed;

$qrPayload = 'fourego://connect?base=' . rawurlencode($apiBase) . '&secret=' . rawurlencode($secret) . '&key_id=' . rawurlencode($keyId) . '&user_id=' . rawurlencode($user['id']) . '&license_key=' . rawurlencode($subscription['license_key']);
if ($allowedLabel !== '') {
    $qrPayload .= '&allowed=' . rawurlencode($allowedLabel);
}

$androidDownload = get_setting('download_android_url', '');

if (is_post() && isset($_POST['action']) && $_POST['action'] === 'regenerate_key') {
    regenerate_user_app_key($user['id']);
    set_flash('success', 'App key regenerated. Please rescan the QR in your app.');
    redirect('app_connect.php');
    exit;
}
if (is_post() && isset($_POST['action']) && $_POST['action'] === 'save_logs') {
    $enabled = isset($_POST['save_logs']) && $_POST['save_logs'] ? 1 : 0;
    update_user_app_save_logs($user['id'], $enabled);
    set_flash('success', 'Saved log preference updated.');
    redirect('app_connect.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>App Connect - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">eGo Customer Portal</a>
                <div class="d-flex gap-2">
                    <a href="dashboard.php" class="btn btn-outline-light btn-sm">Dashboard</a>
                    <a href="user_links.php" class="btn btn-outline-light btn-sm">Links</a>
                    <a href="user_link_orders.php" class="btn btn-outline-light btn-sm">Orders</a>
                    <a href="user_leads.php" class="btn btn-outline-light btn-sm">Leads</a>
                    <a href="app_connect.php" class="btn btn-primary btn-sm">App Connect</a>
                    <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </nav>

        <div class="container-fluid py-2">
            <?php foreach ($flashes as $type => $message): ?>
                <div class="alert alert-<?php echo e($type === 'error' ? 'danger' : ($type === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
                    <?php echo e($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>

            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="card shadow-sm">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <strong>Connect Android app</strong>
                            <?php if (!empty($androidDownload)): ?>
                                <a href="<?php echo esc_url($androidDownload); ?>" target="_blank" rel="noopener" class="btn btn-outline-light btn-sm">Download APK</a>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <p class="text-muted small mb-3">Use this QR to point the mobile app to your account. We embed the API base, HMAC secret, and allowed payment apps.</p>
                            <div class="row g-3 align-items-center">
                                <div class="col-md-6 text-center">
                                    <div class="border rounded-3 p-3 bg-dark-subtle">
                                        <img src="<?php echo esc_url('https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=' . rawurlencode($qrPayload)); ?>" alt="Connect QR" class="img-fluid">
                                    </div>
                                    <div class="small text-muted mt-2">Scan from the eGo Payment app (Scan QR on home screen).</div>
                                    <div class="mt-2">
                                        <a href="<?php echo e($qrPayload); ?>" class="btn btn-outline-primary btn-sm">Open on this device</a>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label text-muted">API base (server)</label>
                                        <div class="input-group input-group-sm">
                                            <input type="text" id="licd-api-base" class="form-control" value="<?php echo e($apiBase); ?>" readonly>
                                            <button class="btn btn-outline-secondary" type="button" onclick="licdCopy('licd-api-base')">Copy</button>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label text-muted">User app key ID</label>
                                        <div class="input-group input-group-sm">
                                            <input type="text" id="licd-key-id" class="form-control" value="<?php echo e($keyId); ?>" readonly>
                                            <button class="btn btn-outline-secondary" type="button" onclick="licdCopy('licd-key-id')">Copy</button>
                                        </div>
                                        <small class="text-muted">Each user gets a unique key ID for pairing.</small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label text-muted">HMAC secret</label>
                                        <div class="input-group input-group-sm">
                                            <input type="password" id="licd-secret" class="form-control" value="<?php echo e($secret); ?>" readonly>
                                            <button class="btn btn-outline-secondary" type="button" onclick="licdToggle('licd-secret')">Show</button>
                                            <button class="btn btn-outline-secondary" type="button" onclick="licdCopy('licd-secret')">Copy</button>
                                        </div>
                                        <small class="text-muted">Used by the app to sign /ping and /notify requests.</small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label text-muted">Allowed payment apps (comma separated packages)</label>
                                        <div class="input-group input-group-sm">
                                            <input type="text" id="licd-allowed" class="form-control" value="<?php echo e($allowedLabel); ?>" readonly>
                                            <button class="btn btn-outline-secondary" type="button" onclick="licdCopy('licd-allowed')">Copy</button>
                                        </div>
                                        <small class="text-muted">Edit in settings if you need more UPI apps. The QR already carries this list.</small>
                                    </div>
                                    <form method="post" class="mb-0">
                                        <?php // toggle save logs for this user ?>
                                        <input type="hidden" name="action" value="save_logs">
                                        <?php $userKeyRow = get_user_app_key($user['id']); $saveLogs = !empty($userKeyRow['save_logs']); ?>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="checkbox" value="1" id="saveLogs" name="save_logs" <?php echo $saveLogs ? 'checked' : ''; ?>>
                                            <label class="form-check-label small text-muted" for="saveLogs">Save app ↔ LM logs (auto-delete after 12 hours)</label>
                                        </div>
                                        <button class="btn btn-outline-primary btn-sm" type="submit">Save</button>
                                    </form>
                                    <div class="alert alert-info small mb-0">
                                        <strong>How to connect:</strong>
                                        <ol class="mb-0 ps-3">
                                            <li>Install the eGo Payment Android app.</li>
                                            <li>Open the app → tap "Scan QR" on Home.</li>
                                            <li>Scan the QR on this page (or tap "Open on this device").</li>
                                            <li>Allow notification access so payments are captured.</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card shadow-sm mb-3">
                        <div class="card-header">
                            <strong>Use dashboard as backend</strong>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled mb-3 small text-muted">
                                <li class="mb-2">Create payment links or landing pages from <a href="link_builder.php">Link Builder</a>.</li>
                                <li class="mb-2">Share the link; when a customer pays, your Android app sends the UPI notification to this dashboard.</li>
                                <li>We match the amount + invoice token to auto-confirm the payment request.</li>
                            </ul>
                            <a href="link_builder.php" class="btn btn-primary btn-sm w-100 mb-2">Create new link / landing page</a>
                            <a href="user_links.php" class="btn btn-outline-secondary btn-sm w-100">Manage links</a>
                        </div>
                    </div>
                    <div class="card shadow-sm mb-3">
                        <div class="card-header">
                            <strong>App status</strong>
                        </div>
                        <div class="card-body">
                            <?php if ($pingAgo !== null): ?>
                                <div class="alert alert-success py-2 mb-2">
                                    Last ping: <?php echo e(intval($pingAgo / 60)); ?> min ago
                                </div>
                            <?php else: ?>
                                <div class="alert alert-secondary py-2 mb-2">No app ping yet.</div>
                            <?php endif; ?>
                            <?php if ($device): ?>
                                <div class="small text-muted">Device: <?php echo e($device); ?></div>
                            <?php endif; ?>
                            <form method="post" class="mt-2">
                                <input type="hidden" name="action" value="regenerate_key">
                                <button class="btn btn-outline-danger btn-sm w-100" type="submit">Regenerate app key</button>
                            </form>
                        </div>
                    </div>
                    <?php if (!empty($androidDownload)): ?>
                    <div class="card shadow-sm">
                        <div class="card-header">
                            <strong>Download app</strong>
                        </div>
                        <div class="card-body text-center">
                            <a href="<?php echo esc_url($androidDownload); ?>" target="_blank" rel="noopener" class="btn btn-outline-primary btn-sm mb-2">Download APK</a>
                            <div class="text-muted small">Scan or open to install on your phone.</div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function licdCopy(id){
        var el = document.getElementById(id);
        if (!el) return;
        el.type === 'password' && (el.type = 'text');
        el.select();
        el.setSelectionRange(0, 99999);
        try { document.execCommand('copy'); } catch (_) {}
    }
    function licdToggle(id){
        var el = document.getElementById(id);
        if (!el) return;
        el.type = el.type === 'password' ? 'text' : 'password';
    }
</script>
</body>
</html>
