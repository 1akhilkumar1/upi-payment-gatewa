<?php
require_once __DIR__ . '/../config.php';

$token = trim($_GET['token'] ?? $_POST['token'] ?? '');
$error = '';
$success = '';
$resetRow = $token ? get_password_reset($token) : null;

if (is_post()) {
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['password_confirm'] ?? '';
    if (!$resetRow) {
        $error = 'Reset link is invalid or expired.';
    } elseif ($password === '' || $confirm === '') {
        $error = 'All fields are required.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        if (consume_password_reset($token, $password)) {
            $success = 'Password updated. You can log in now.';
        } else {
            $error = 'Reset link is invalid or expired.';
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Set new password - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="auth-card card auth-paper">
        <div class="auth-header text-center mb-3">
            <h4 class="mb-1">Set a new password</h4>
        </div>
        <?php if ($error): ?>
            <div class="alert alert-danger text-center"><?php echo e($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success text-center"><?php echo e($success); ?></div>
            <div class="text-center mt-3">
                <a href="login.php" class="btn btn-outline-light btn-sm">Go to login</a>
            </div>
        <?php else: ?>
            <form method="post">
                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                <div class="mb-3">
                    <label class="form-label text-muted">New password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label text-muted">Confirm password</label>
                    <input type="password" name="password_confirm" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Update password</button>
            </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
