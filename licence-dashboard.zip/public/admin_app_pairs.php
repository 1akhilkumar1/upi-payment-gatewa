<?php
require_once __DIR__ . '/../config.php';

require_admin();

if (is_post() && isset($_POST['action']) && $_POST['action'] === 'regenerate_key') {
    $userId = (int)($_POST['user_id'] ?? 0);
    if ($userId > 0) {
        regenerate_user_app_key($userId);
        set_flash('success', 'App key regenerated for user ID ' . $userId);
    }
    redirect('admin_app_pairs.php');
    exit;
}

ensure_user_app_keys_table();
$stmt = db()->query("SELECT u.id, u.email, u.name, u.status, k.key_id, k.device, k.last_ping
                     FROM users u
                     LEFT JOIN user_app_keys k ON k.user_id = u.id
                     ORDER BY u.created_at DESC");
$rows = $stmt->fetchAll();
$flashes = pull_all_flash();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>App Pairing Status - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin_dashboard.php">eGo Admin</a>
                <div class="d-flex gap-2">
                    <a class="btn btn-outline-light btn-sm" href="admin_dashboard.php">Dashboard</a>
                    <a class="btn btn-outline-light btn-sm" href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
        <div class="container-fluid py-2">
            <?php foreach ($flashes as $type => $message): ?>
                <div class="alert alert-<?php echo e($type === 'error' ? 'danger' : ($type === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
                    <?php echo e($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>App pairing status</strong>
                    <span class="small text-muted"><?php echo e(count($rows)); ?> users</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Status</th>
                                    <th>Key ID</th>
                                    <th>Device</th>
                                    <th>Last ping</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows as $row): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-semibold"><?php echo e($row['name']); ?></div>
                                            <div class="small text-muted"><?php echo e($row['email']); ?></div>
                                        </td>
                                        <td><span class="badge bg-<?php echo $row['status']==='active'?'success':'secondary'; ?>"><?php echo e($row['status']); ?></span></td>
                                        <td><code><?php echo e($row['key_id'] ?? '—'); ?></code></td>
                                        <td><?php echo e($row['device'] ?? ''); ?></td>
                                        <td><?php echo e($row['last_ping'] ?? ''); ?></td>
                                        <td>
                                            <form method="post" onsubmit="return confirm('Regenerate app key for this user?');">
                                                <input type="hidden" name="action" value="regenerate_key">
                                                <input type="hidden" name="user_id" value="<?php echo e($row['id']); ?>">
                                                <button type="submit" class="btn btn-outline-danger btn-sm">Regenerate</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
