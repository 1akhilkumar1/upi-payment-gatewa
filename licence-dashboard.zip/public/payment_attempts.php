<?php
require_once __DIR__ . '/../config.php';
require_admin();

$export = isset($_GET['export']) && $_GET['export'] === 'csv';

$stmt = db()->query("SELECT pr.*, u.email AS user_email, p.name AS plan_name, p.slug AS plan_slug
                     FROM payment_requests pr
                     JOIN subscriptions s ON s.id = pr.subscription_id
                     JOIN users u ON u.id = pr.user_id
                     LEFT JOIN plans p ON p.slug = pr.plan_slug
                     ORDER BY pr.created_at DESC");
$rows = $stmt->fetchAll();

if ($export) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=payment_attempts.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID','User','Plan','Cycle','Amount','Currency','Status','Txn ID','Created','Updated']);
    foreach ($rows as $r) {
        fputcsv($out, [
            $r['id'],
            $r['user_email'],
            $r['plan_name'],
            ucfirst($r['cycle']),
            $r['amount'],
            $r['currency'],
            $r['state'] ?: 'pending',
            $r['txn_id'],
            $r['created_at'],
            $r['updated_at'],
        ]);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment Attempts - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Leads / Payment attempts</h3>
        <div class="d-flex gap-2">
            <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back</a>
            <a href="?export=csv" class="btn btn-outline-primary btn-sm">Export CSV</a>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>Plan</th>
                    <th>Cycle</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Txn ID</th>
                    <th>Created</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><?php echo e($r['id']); ?></td>
                        <td><?php echo e($r['user_email']); ?></td>
                        <td><?php echo e($r['plan_name']); ?></td>
                        <td><?php echo e(ucfirst($r['cycle'])); ?></td>
                        <td><?php echo e($r['currency']); ?> <?php echo e(number_format((float)$r['amount'], 2)); ?></td>
                        <td><span class="badge bg-<?php echo $r['state'] === 'completed' ? 'success' : ($r['state'] === 'submitted' ? 'warning' : 'secondary'); ?>"><?php echo e($r['state'] ?: 'pending'); ?></span></td>
                        <td><?php echo e($r['txn_id'] ?? ''); ?></td>
                        <td><?php echo e($r['created_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
