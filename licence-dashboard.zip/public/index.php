<?php
require_once __DIR__ . '/../config.php';

if (!empty($_SESSION['user_id'])) {
    $user = current_user();
    if ($user && $user['role'] === 'admin') {
        redirect('admin_dashboard.php');
    } else {
        redirect('dashboard.php');
    }
} else {
    redirect('login.php');
}
