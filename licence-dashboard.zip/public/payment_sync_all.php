<?php
require_once __DIR__ . '/../config.php';
require_admin();
$export = isset($_GET['export']) && $_GET['export'] === 'csv';

$pdo = db();
$stmt = $pdo->query("SELECT l.*, u.email AS user_email, s.license_key FROM payment_sync_logs l JOIN users u ON u.id = l.user_id JOIN subscriptions s ON s.id = l.subscription_id ORDER BY l.recorded_at DESC");
$rows = $stmt->fetchAll();

if ($export) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=payment_sync_logs.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID','User','License','Feature','Amount','Txn','Payer VPA','Source','Recorded']);
    foreach ($rows as $r) {
        fputcsv($out, [$r['id'], $r['user_email'], $r['license_key'], $r['feature'], $r['amount'], $r['txn_id'], $r['payer_vpa'], $r['source'], $r['recorded_at']]);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment Sync Logs - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Payment sync logs</h3>
        <div class="d-flex gap-2">
            <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back</a>
            <a href="?export=csv" class="btn btn-outline-primary btn-sm">Export CSV</a>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>License</th>
                    <th>Feature</th>
                    <th>Amount</th>
                    <th>Txn</th>
                    <th>Payer</th>
                    <th>Recorded</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><?php echo e($r['id']); ?></td>
                        <td><?php echo e($r['user_email']); ?></td>
                        <td><code><?php echo e($r['license_key']); ?></code></td>
                        <td><?php echo e($r['feature']); ?></td>
                        <td><?php echo e(number_format((float)$r['amount'], 2)); ?></td>
                        <td><?php echo e($r['txn_id']); ?></td>
                        <td><?php echo e($r['payer_vpa']); ?></td>
                        <td><?php echo e($r['recorded_at']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
