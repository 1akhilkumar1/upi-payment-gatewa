<?php
require_once __DIR__ . '/../config.php';

require_admin();

$error = '';
$success = '';
$availableFeatures = available_features();
$selectedFeatures = [];
$editingPlan = null;

if (!empty($_GET['edit'])) {
    $editId = (int) $_GET['edit'];
    $editingPlan = get_plan_by_id($editId);
    if ($editingPlan) {
        $selectedFeatures = decode_features($editingPlan);
    }
}

if (is_post()) {
    $action = $_POST['action'] ?? '';
        if ($action === 'create_plan') {
            $slug = trim($_POST['slug'] ?? '');
            $name = trim($_POST['name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $billingCycle = ($_POST['billing_cycle'] ?? 'monthly') === 'yearly' ? 'yearly' : 'monthly';
            $monthlyPrice = (float)($_POST['monthly_price'] ?? 0);
            $annualPrice = $_POST['annual_price'] !== '' ? (float)$_POST['annual_price'] : null;
            $domainLimit = max(0, (int)($_POST['domain_limit'] ?? 0));
            $landingPagesLimit = max(0, (int)($_POST['landing_pages_limit'] ?? 3));
            $paymentLinksLimit = max(0, (int)($_POST['payment_links_limit'] ?? 10));
            $whitelistDomainsLimit = max(0, (int)($_POST['whitelist_domains_limit'] ?? 1));
            $additionalDomainFee = max(0, (float)($_POST['additional_domain_fee'] ?? 0));
            $selectedFeatures = $_POST['features'] ?? [];
            $features = is_array($selectedFeatures) ? $selectedFeatures : [];

            if ($slug === '' || $name === '') {
                $error = 'Slug and name are required.';
            } else {
                try {
                    create_plan($slug, $name, $description, $billingCycle, $monthlyPrice, $annualPrice, $domainLimit, $landingPagesLimit, $paymentLinksLimit, $whitelistDomainsLimit, $additionalDomainFee, $features);
                set_flash('success', 'Plan created successfully.');
                redirect('manage_plans.php');
            } catch (PDOException $e) {
                $error = 'Unable to create plan: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'toggle_plan') {
        $planId = (int)($_POST['plan_id'] ?? 0);
        $isActive = ($_POST['is_active'] ?? '') === '1';
        if ($planId > 0) {
            set_plan_active($planId, $isActive);
            set_flash('success', 'Plan status updated.');
            redirect('manage_plans.php');
        }
    } elseif ($action === 'edit_plan') {
        $planId = (int)($_POST['plan_id'] ?? 0);
        $slug = trim($_POST['slug'] ?? '');
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $billingCycle = ($_POST['billing_cycle'] ?? 'monthly') === 'yearly' ? 'yearly' : 'monthly';
        $monthlyPrice = (float)($_POST['monthly_price'] ?? 0);
        $annualPrice = $_POST['annual_price'] !== '' ? (float)$_POST['annual_price'] : null;
        $domainLimit = max(0, (int)($_POST['domain_limit'] ?? 0));
        $landingPagesLimit = max(0, (int)($_POST['landing_pages_limit'] ?? 3));
        $paymentLinksLimit = max(0, (int)($_POST['payment_links_limit'] ?? 10));
        $whitelistDomainsLimit = max(0, (int)($_POST['whitelist_domains_limit'] ?? 1));
        $additionalDomainFee = max(0, (float)($_POST['additional_domain_fee'] ?? 0));
        $selectedFeatures = $_POST['features'] ?? [];
        $features = is_array($selectedFeatures) ? $selectedFeatures : [];

        if ($planId <= 0 || $slug === '' || $name === '') {
            $error = 'Plan ID, slug, and name are required.';
        } else {
            try {
                update_plan($planId, $slug, $name, $description, $billingCycle, $monthlyPrice, $annualPrice, $domainLimit, $landingPagesLimit, $paymentLinksLimit, $whitelistDomainsLimit, $additionalDomainFee, $features);
                set_flash('success', 'Plan updated successfully.');
                redirect('manage_plans.php');
            } catch (PDOException $e) {
                $error = 'Unable to update plan: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'delete_plan') {
        $planId = (int)($_POST['plan_id'] ?? 0);
        if ($planId > 0) {
            delete_plan($planId);
            set_flash('success', 'Plan deleted.');
            redirect('manage_plans.php');
        }
    }
}

$plans = list_plans(false);
$flashes = pull_all_flash();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Plans - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin_dashboard.php">eGo Control Panel</a>
                <div class="d-flex gap-2">
                    <a href="admin_dashboard.php" class="btn btn-outline-light btn-sm">Back</a>
                    <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </nav>
        <div class="container-fluid py-2">
    <?php foreach ($flashes as $key => $message): ?>
        <div class="alert alert-<?php echo e($key === 'error' ? 'danger' : ($key === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
            <?php echo e($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo e($error); ?></div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow-sm mb-4">
                <div class="card-header">
                    <strong>Existing plans</strong>
                </div>
                <div class="card-body">
                    <?php if (empty($plans)): ?>
                        <p class="text-muted mb-0">No plans defined yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th>Slug</th>
                                        <th>Name</th>
                                        <th>Domains</th>
                                        <th>Landing Pages</th>
                                        <th>Payment Links</th>
                                        <th>Payment Linkh>
                                        <th>Price</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($plans as $plan): ?>
                                        <tr>
                                            <td><?php echo e($plan['slug']); ?></td>
                                            <td>
                                                <strong><?php echo e($plan['name']); ?></strong><br>
                                                <span class="small text-muted"><?php echo e($plan['description']); ?></span>
                                            </td>
                                            <td><?php echo e($plan['domain_limit'] > 0 ? $plan['domain_limit'] : 'Unlimited'); ?></td>
                                            <td><?php echo e($plan['landing_pages_limit']); ?></td>
                                            <td><?php echo e($plan['payment_links_limit']); ?></td>
                                            <td><?php echo e($plan['whitelist_domains_limit']); ?></td>
                                            <td>INR <?php echo e($plan['monthly_price']); ?> / mo</td>
                                            <td><span class="badge bg-<?php echo $plan['is_active'] ? 'success' : 'secondary'; ?>"><?php echo $plan['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                                            <td>
                                                <form method="post" class="d-flex gap-1 align-items-center">
                                                    <input type="hidden" name="action" value="toggle_plan">
                                                    <input type="hidden" name="plan_id" value="<?php echo e($plan['id']); ?>">
                                                    <input type="hidden" name="is_active" value="<?php echo $plan['is_active'] ? '0' : '1'; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-primary"><?php echo $plan['is_active'] ? 'Deactivate' : 'Activate'; ?></button>
                                                </form>
                                                <a href="manage_plans.php?edit=<?php echo e($plan['id']); ?>" class="btn btn-sm btn-outline-secondary mt-1">Edit</a>
                                                <form method="post" class="d-inline" onsubmit="return confirm('Delete this plan?');">
                                                    <input type="hidden" name="action" value="delete_plan">
                                                    <input type="hidden" name="plan_id" value="<?php echo e($plan['id']); ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger mt-1">Delete</button>
                                                </form>
                                                <?php
                                                    $planFeatures = decode_features($plan);
                                                ?>
                                                <?php if ($planFeatures): ?>
                                                    <div class="d-flex flex-wrap gap-1 mt-1">
                                                        <?php foreach ($planFeatures as $feature): ?>
                                                            <span class="badge border border-secondary text-secondary"><?php echo e(feature_label($feature)); ?></span>
                                                        <?php endforeach; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header">
                    <strong><?php echo $editingPlan ? 'Edit plan' : 'Create new plan'; ?></strong>
                </div>
                <div class="card-body">
                    <form method="post">
                        <input type="hidden" name="action" value="<?php echo $editingPlan ? 'edit_plan' : 'create_plan'; ?>">
                        <?php if ($editingPlan): ?>
                            <input type="hidden" name="plan_id" value="<?php echo e($editingPlan['id']); ?>">
                        <?php endif; ?>
                        <div class="mb-2">
                            <label class="form-label">Slug</label>
                            <input type="text" name="slug" class="form-control form-control-sm" required value="<?php echo e($editingPlan['slug'] ?? ''); ?>">
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control form-control-sm" required value="<?php echo e($editingPlan['name'] ?? ''); ?>">
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control form-control-sm" rows="2"><?php echo e($editingPlan['description'] ?? ''); ?></textarea>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Billing cycle</label>
                            <select name="billing_cycle" class="form-select form-select-sm">
                                <option value="monthly" <?php echo (isset($editingPlan['billing_cycle']) && $editingPlan['billing_cycle']==='monthly') ? 'selected' : ''; ?>>Monthly</option>
                                <option value="yearly" <?php echo (isset($editingPlan['billing_cycle']) && $editingPlan['billing_cycle']==='yearly') ? 'selected' : ''; ?>>Yearly</option>
                            </select>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Monthly price (INR)</label>
                            <input type="number" name="monthly_price" step="0.01" class="form-control form-control-sm" value="<?php echo e($editingPlan['monthly_price'] ?? '0'); ?>">
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Annual price (optional)</label>
                            <input type="number" name="annual_price" step="0.01" class="form-control form-control-sm" value="<?php echo isset($editingPlan['annual_price']) ? e($editingPlan['annual_price']) : ''; ?>">
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Domain limit (enter 0 for unlimited)</label>
                            <input type="number" name="domain_limit" class="form-control form-control-sm" value="<?php echo e($editingPlan['domain_limit'] ?? '1'); ?>" min="0">
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Landing pages limit</label>
                            <input type="number" name="landing_pages_limit" class="form-control form-control-sm" value="<?php echo e($editingPlan['landing_pages_limit'] ?? '3'); ?>" min="0">
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Payment links limit</label>
                            <input type="number" name="payment_links_limit" class="form-control form-control-sm" value="<?php echo e($editingPlan['payment_links_limit'] ?? '10'); ?>" min="0">
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Whitelist domains limit</label>
                            <input type="number" name="whitelist_domains_limit" class="form-control form-control-sm" value="<?php echo e($editingPlan['whitelist_domains_limit'] ?? '1'); ?>" min="0">
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Additional domain fee (INR)</label>
                            <input type="number" step="0.01" name="additional_domain_fee" class="form-control form-control-sm" value="<?php echo e($editingPlan['additional_domain_fee'] ?? '0'); ?>">
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Select featured capabilities</label>
                            <div class="d-flex flex-wrap gap-2">
                                <?php foreach ($availableFeatures as $slug => $label): ?>
                                    <?php $checked = in_array($slug, $selectedFeatures, true); ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="features[]" value="<?php echo e($slug); ?>" id="feature_<?php echo e($slug); ?>" <?php echo $checked ? 'checked' : ''; ?>>
                                        <label class="form-check-label text-muted" for="feature_<?php echo e($slug); ?>"><?php echo e($label); ?></label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-sm w-100" type="submit"><?php echo $editingPlan ? 'Update plan' : 'Create plan'; ?></button>
                        <?php if ($editingPlan): ?>
                            <div class="mt-2 text-center">
                                <a href="manage_plans.php" class="small text-muted">Cancel edit</a>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <div class="card shadow-sm">
                <div class="card-body">
                    <p class="small text-muted mb-0">Plans drive license creation and determine feature access. Use the table to toggle visibility.</p>
                </div>
            </div>
        </div>
    </div>
</div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
