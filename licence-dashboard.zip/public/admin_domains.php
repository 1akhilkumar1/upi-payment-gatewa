<?php
require_once __DIR__ . '/../config.php';
require_admin();

$flashes = pull_all_flash();
$host = parse_url(BASE_URL, PHP_URL_HOST) ?: ($_SERVER['HTTP_HOST'] ?? 'localhost');
$scheme = parse_url(BASE_URL, PHP_URL_SCHEME) ?: 'https';
$cnameTarget = $host;
$resolvedIp = filter_var($host, FILTER_VALIDATE_IP) ? $host : @gethostbyname($host);

if (is_post() && isset($_POST['domain_id'], $_POST['set_status'])) {
    $id = (int)$_POST['domain_id'];
    $status = $_POST['set_status'];
    $note = trim($_POST['admin_note'] ?? '');
    try {
        update_domain_request($id, $status, $note ?: null);
        set_flash('success', 'Domain status updated.');
    } catch (Throwable $e) {
        set_flash('error', 'Unable to update domain: ' . $e->getMessage());
    }
    redirect('admin_domains.php');
    exit;
}

$rows = db()->query("SELECT sd.*, u.email AS user_email, u.name AS user_name, s.license_key
                      FROM subscription_domains sd
                      JOIN subscriptions s ON s.id = sd.subscription_id
                      JOIN users u ON u.id = s.user_id
                      ORDER BY sd.requested_at DESC")->fetchAll();

function dns_status_label($domain, $expectedHost, $expectedIp) {
    $domain = normalize_domain($domain);
    if ($domain === '') return ['Unknown', 'secondary'];
    $records = @dns_get_record($domain, DNS_CNAME + DNS_A);
    if (!$records || !is_array($records)) return ['No DNS records found', 'secondary'];
    $matches = false;
    foreach ($records as $r) {
        if (isset($r['type']) && $r['type'] === 'CNAME' && !empty($r['target']) && normalize_domain($r['target']) === normalize_domain($expectedHost)) {
            $matches = true;
            break;
        }
        if (isset($r['type']) && $r['type'] === 'A' && !empty($r['ip']) && $expectedIp && $r['ip'] === $expectedIp) {
            $matches = true;
            break;
        }
    }
    return $matches ? ['DNS OK', 'success'] : ['Mismatch', 'warning'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Domain setup & approvals - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Domain setup & approvals</h3>
        <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back</a>
    </div>

    <?php foreach ($flashes as $type => $message): ?>
        <div class="alert alert-<?php echo e($type === 'error' ? 'danger' : ($type === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
            <?php echo e($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>

    <div class="row g-3">
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-header">
                    <strong>DNS targets</strong>
                </div>
                <div class="card-body">
                    <p class="small text-muted mb-2">Share this with customers so their custom domain points correctly.</p>
                    <div class="mb-2">
                        <div class="text-muted small">CNAME target</div>
                        <code><?php echo e($cnameTarget); ?></code>
                    </div>
                    <?php if ($resolvedIp): ?>
                    <div class="mb-2">
                        <div class="text-muted small">A record (if CNAME not possible)</div>
                        <code><?php echo e($resolvedIp); ?></code>
                    </div>
                    <?php endif; ?>
                    <ol class="small text-muted mt-3 mb-0">
                        <li>Create a CNAME for the customer domain pointing to <?php echo e($cnameTarget); ?>.</li>
                        <li>Ask them to add the domain in their dashboard (Domain whitelisting).</li>
                        <li>Approve the request here once DNS resolves to the target.</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Domain whitelist & approvals</strong>
                    <a href="pending_domains_all.php" class="btn btn-sm btn-outline-primary">Export / full view</a>
                </div>
                <div class="card-body">
                    <?php if (empty($rows)): ?>
                        <p class="text-muted mb-0">No domains submitted yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm table-striped align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th>Domain</th>
                                        <th>User</th>
                                        <th>Status</th>
                                        <th>DNS</th>
                                        <th>Requested</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($rows as $row): ?>
                                        <?php [$dnsLabel, $dnsBadge] = dns_status_label($row['domain'], $cnameTarget, $resolvedIp); ?>
                                        <tr>
                                            <td><?php echo e($row['domain']); ?></td>
                                            <td>
                                                <?php echo e($row['user_email']); ?>
                                                <div class="small text-muted"><?php echo e($row['user_name'] ?? ''); ?></div>
                                            </td>
                                            <td><span class="badge bg-<?php echo $row['status']==='approved'?'success':($row['status']==='pending'?'warning':'secondary'); ?>"><?php echo e($row['status']); ?></span></td>
                                            <td><span class="badge bg-<?php echo e($dnsBadge); ?>"><?php echo e($dnsLabel); ?></span></td>
                                            <td><?php echo e($row['requested_at']); ?></td>
                                            <td>
                                                <form method="post" class="d-flex gap-1 align-items-center">
                                                    <input type="hidden" name="domain_id" value="<?php echo e($row['id']); ?>">
                                                    <select name="set_status" class="form-select form-select-sm" style="width:120px;">
                                                        <option value="approved" <?php echo $row['status']==='approved'?'selected':''; ?>>Approve</option>
                                                        <option value="pending" <?php echo $row['status']==='pending'?'selected':''; ?>>Pending</option>
                                                        <option value="rejected" <?php echo $row['status']==='rejected'?'selected':''; ?>>Reject</option>
                                                    </select>
                                                    <input type="text" name="admin_note" class="form-control form-control-sm" placeholder="Note" style="width:140px;">
                                                    <button class="btn btn-sm btn-primary" type="submit">Save</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
