<?php
require_once __DIR__ . '/../config.php';

require_auth();
$user = current_user();
$subscription = get_active_subscription_for_user($user['id']);

if (!$subscription) {
    set_flash('error', 'No active subscription found. Please activate a plan before requesting domains.');
    redirect('dashboard.php');
}

if (is_post()) {
    $domain = $_POST['domain'] ?? '';
    $reason = null;
    if (request_domain_for_subscription($subscription['id'], $domain, $reason)) {
        set_flash('success', 'We received your domain request. An administrator will approve it shortly.');
    } else {
        $message = 'Unable to add the domain.';
        if ($reason === 'domain_limit_reached') {
            $message = 'You already reached the domain limit for your current plan.';
        } elseif ($reason === 'invalid_domain') {
            $message = 'Enter a valid domain name without http:// or https://.';
        }
        set_flash('error', $message);
    }
}

redirect('dashboard.php');
