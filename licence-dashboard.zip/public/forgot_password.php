<?php
require_once __DIR__ . '/../config.php';

$message = '';
if (is_post()) {
    $email = trim($_POST['email'] ?? '');
    if ($email !== '') {
        $reset = create_password_reset($email);
        if ($reset && function_exists('licd_send_mail')) {
            $resetUrl = function_exists('licd_public_url')
                ? licd_public_url('reset_password.php?token=' . urlencode($reset['token']))
                : (defined('BASE_URL') ? rtrim(BASE_URL, '/') . '/reset_password.php?token=' . urlencode($reset['token']) : '');
            $body = '<p>Hi ' . esc_html($reset['user']['name']) . ',</p>'
                  . '<p>Use the link below to reset your password. This link expires in 1 hour.</p>'
                  . ($resetUrl ? '<p><a href="' . esc_url($resetUrl) . '">Reset your password</a></p>' : '');
            licd_send_mail($reset['user']['email'], 'Reset your password', $body);
        }
        $message = 'If an account exists for that email, a reset link has been sent.';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reset password - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="auth-card card auth-paper">
        <div class="auth-header text-center mb-3">
            <h4 class="mb-1">Forgot password</h4>
            <p class="text-muted mb-0">We will email you a reset link.</p>
        </div>
        <?php if ($message): ?>
            <div class="alert alert-info text-center"><?php echo e($message); ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="mb-3">
                <label class="form-label text-muted">Email</label>
                <input type="email" name="email" class="form-control" placeholder="you@example.com" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Send reset link</button>
        </form>
        <div class="text-center mt-3">
            <a href="login.php" class="text-muted">Back to login</a>
        </div>
    </div>
</div>
</body>
</html>
