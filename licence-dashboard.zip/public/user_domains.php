<?php
require_once __DIR__ . '/../config.php';

require_auth();
$user = current_user();
$subscription = get_active_subscription_for_user($user['id']);
if (!$subscription) {
    set_flash('error', 'You need an active subscription to manage domains.');
    redirect('dashboard.php');
    exit;
}

// Handle submission
if (is_post() && isset($_POST['action']) && $_POST['action'] === 'domain_request') {
    $domainInput = trim($_POST['domain'] ?? '');
    if ($domainInput === '') {
        set_flash('error', 'Please enter a domain.');
    } else {
        $reason = null;
        if (request_domain_for_subscription($subscription['id'], $domainInput, $reason)) {
            set_flash('success', 'Domain request submitted. Auto-approve will run if within plan limit.');
        } else {
            set_flash('error', 'Domain request failed: ' . ($reason ?: 'unknown error'));
        }
    }
    redirect('user_domains.php');
    exit;
}

$licensePayload = build_subscription_payload($subscription);
$approvedDomains = $licensePayload['approved_domains_count'] ?? 0;
$pendingDomains = $licensePayload['pending_domains_count'] ?? 0;
$domainLimit = $licensePayload['plan']['domain_limit'] ?? 0;
$domains = $licensePayload['domains'] ?? [];
$dnsHost = parse_url(BASE_URL, PHP_URL_HOST) ?: ($_SERVER['HTTP_HOST'] ?? 'your-host');
$dnsScheme = parse_url(BASE_URL, PHP_URL_SCHEME) ?: 'https';
$dnsIp = filter_var($dnsHost, FILTER_VALIDATE_IP) ? $dnsHost : @gethostbyname($dnsHost);
$flashes = pull_all_flash();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Domains - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">eGo Customer Portal</a>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(licd_public_url('dashboard.php')); ?>" class="btn btn-outline-light btn-sm">Dashboard</a>
                    <a href="<?php echo e(licd_public_url('user_links.php')); ?>" class="btn btn-outline-light btn-sm">Links</a>
                    <a href="<?php echo e(licd_public_url('app_connect.php')); ?>" class="btn btn-outline-light btn-sm">App Connect</a>
                    <a href="<?php echo e(licd_public_url('profile.php')); ?>" class="btn btn-outline-light btn-sm">Profile</a>
                    <a href="<?php echo e(licd_public_url('logout.php')); ?>" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </nav>

        <div class="container-fluid py-2">
            <?php foreach ($flashes as $type => $message): ?>
                <div class="alert alert-<?php echo e($type === 'error' ? 'danger' : ($type === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
                    <?php echo e($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>

            <div class="card shadow-sm mb-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Domain whitelisting</strong>
                    <div class="d-flex align-items-center gap-2">
                        <span class="badge bg-dark border border-secondary text-secondary">Approved: <?php echo e($approvedDomains); ?></span>
                        <span class="badge bg-dark border border-warning text-warning">Pending: <?php echo e($pendingDomains); ?></span>
                        <span class="badge bg-dark border border-secondary text-secondary">Limit: <?php echo e($domainLimit > 0 ? $domainLimit : 'Unlimited'); ?></span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row g-3 mb-3">
                        <div class="col-lg-6">
                            <div class="border rounded p-3 h-100">
                                <div class="fw-semibold mb-1">DNS to point</div>
                                <div class="small text-muted">CNAME target:</div>
                                <code><?php echo e($dnsHost); ?></code>
                                <?php if ($dnsIp): ?>
                                <div class="small text-muted mt-2">A record (fallback):</div>
                                <code><?php echo e($dnsIp); ?></code>
                                <?php endif; ?>
                                <div class="small text-muted mt-2">Scheme: <?php echo e($dnsScheme); ?></div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="border rounded p-3 h-100">
                                <div class="fw-semibold mb-1">How to connect your domain</div>
                                <ol class="small text-muted mb-0 ps-3">
                                    <li>Create a CNAME to <code><?php echo e($dnsHost); ?></code> (or A to <?php echo e($dnsIp ?: 'your host'); ?> if CNAME not allowed).</li>
                                    <li>Submit the domain below. Auto-approve will run if under plan limit.</li>
                                    <li>After approval, pick the domain when creating links/landing pages.</li>
                                    <li>Limit: <?php echo e($domainLimit > 0 ? $domainLimit : 'Unlimited'); ?> (used: <?php echo e($approvedDomains); ?>).</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <form method="post" class="row g-2 mb-3">
                        <input type="hidden" name="action" value="domain_request">
                        <div class="col-md-8">
                            <input type="text" name="domain" class="form-control" placeholder="example.com" required>
                        </div>
        <div class="col-md-4 d-grid">
            <button type="submit" class="btn btn-primary">Submit domain</button>
        </div>
                    </form>
                    <?php if (!empty($domains)): ?>
                        <div class="table-responsive">
                            <table class="table table-sm table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th>Domain</th>
                                        <th>Status</th>
                                        <th>Requested</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($domains as $d): ?>
                                        <tr>
                                            <td><?php echo e($d['domain']); ?></td>
                                            <td><span class="badge bg-<?php echo $d['status']==='approved'?'success':($d['status']==='pending'?'warning':'secondary'); ?>"><?php echo e($d['status']); ?></span></td>
                                            <td><?php echo e($d['requested_at'] ?? ''); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted mb-0">No domains submitted yet.</p>
                    <?php endif; ?>
                    <p class="text-muted small mt-2">Primary domain from your profile is auto-whitelisted. Requests auto-approve after a few minutes if under plan limit.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
