<?php
require_once __DIR__ . '/../config.php';

$user = current_user();
$plans = list_plans(true);
$flashes = pull_all_flash();
$paymentLogo = get_payment_logo_url();

if (is_post() && isset($_POST['action']) && $_POST['action'] === 'buy_plan') {
    if (!$user) {
        set_flash('error', 'Please log in or sign up to continue.');
        redirect('register.php?plan=' . urlencode($_POST['plan_slug'] ?? ''));
    }
    $planSlug = trim($_POST['plan_slug'] ?? '');
    $cycle    = ($_POST['cycle'] ?? 'monthly') === 'yearly' ? 'yearly' : 'monthly';
    $plan     = $planSlug ? get_plan_by_slug($planSlug) : null;
    if ($plan) {
        $amount = plan_price_for_cycle($plan, $cycle);
        if ($amount > 0) {
            try {
                $note = $plan['name'] . ' - ' . ($user['email'] ?? $user['name']);
                $payReq = create_payment_request(
                    ['id' => null, 'user_id' => $user['id'], 'user' => $user['id']],
                    'subscription',
                    $amount,
                    $cycle,
                    $plan['slug'],
                    ['source' => 'pricing'],
                    null,
                    $note
                );
                set_flash('success', 'Payment link generated. Complete your payment to activate the plan.');
                redirect('checkout.php?id=' . $payReq['id']);
                exit;
            } catch (Exception $e) {
                set_flash('error', 'Could not create payment request: ' . $e->getMessage());
            }
        } else {
            set_flash('error', 'Invalid amount for the selected plan.');
        }
    } else {
        set_flash('error', 'Invalid plan.');
    }
    redirect('pricing.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Subscription plans - eGo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      :root {
        --bg: #050816;
        --bg-alt: #0b1020;
        --card-bg: #0f172a;
        --primary: #6366f1;
        --accent: #22c55e;
        --text: #e5e7eb;
        --muted: #9ca3af;
        --border: #1f2937;
        --radius-lg: 18px;
        --shadow-soft: 0 18px 45px rgba(0, 0, 0, 0.45);
      }
      * { box-sizing: border-box; }
      body {
        background: radial-gradient(circle at top, #111827 0, #020617 45%, #000 100%);
        color: var(--text);
        font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        margin: 0;
        padding: 0;
      }
      .hero {
        padding: 48px 16px 24px;
        text-align: center;
      }
      .hero h1 { margin: 0 0 8px; font-size: 34px; }
      .hero p { margin: 0; color: var(--muted); }
      .grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 16px;
        padding: 16px;
        max-width: 1100px;
        margin: 0 auto 48px;
      }
      .card {
        background: var(--card-bg);
        border: 1px solid var(--border);
        border-radius: var(--radius-lg);
        padding: 18px;
        box-shadow: var(--shadow-soft);
        display: flex;
        flex-direction: column;
        gap: 12px;
      }
      .price { font-size: 24px; font-weight: 700; }
      .muted { color: var(--muted); font-size: 14px; }
      .features { list-style: none; padding: 0; margin: 0; display: grid; gap: 6px; }
      .features li { display: flex; align-items: center; gap: 8px; }
      .pill { padding: 4px 10px; border-radius: 999px; background: rgba(99,102,241,0.15); color: var(--text); font-size: 12px; }
      .btn {
        display: inline-block;
        text-align: center;
        padding: 10px 14px;
        border-radius: 12px;
        font-weight: 600;
        text-decoration: none;
        border: none;
        cursor: pointer;
        transition: transform .1s ease;
      }
      .btn-primary { background: var(--primary); color: #fff; }
      .btn-secondary { background: #111827; color: #fff; border: 1px solid var(--border); }
      .btn:hover { transform: translateY(-1px); }
      .flash { max-width: 900px; margin: 8px auto; padding: 12px 14px; border-radius: 10px; }
      .flash.success { background: #0f172a; color: #16a34a; border: 1px solid #14532d; }
      .flash.error { background: #0f172a; color: #f87171; border: 1px solid #7f1d1d; }
    </style>
</head>
<body>
    <div class="hero">
        <h1>Choose your plan</h1>
        <p>Accept payments with zero processing fee and unlock premium tools.</p>
    </div>

    <?php foreach ($flashes as $type => $msg): ?>
        <div class="flash <?php echo $type === 'error' ? 'error' : 'success'; ?>"><?php echo e($msg); ?></div>
    <?php endforeach; ?>

    <div class="grid">
    <?php foreach ($plans as $plan): ?>
        <?php $features = decode_features($plan); ?>
        <div class="card">
            <div>
                <div class="muted">Plan</div>
                <h3><?php echo e($plan['name']); ?></h3>
                <div class="muted"><?php echo e($plan['description']); ?></div>
            </div>
            <div>
                <div class="price">INR <?php echo e(number_format((float)$plan['monthly_price'], 2)); ?> <span class="muted">/mo</span></div>
                <?php if (!empty($plan['annual_price'])): ?>
                    <div class="muted">or INR <?php echo e(number_format((float)$plan['annual_price'], 2)); ?> /yr</div>
                <?php endif; ?>
            </div>
            <div class="muted">Domains: <?php echo e($plan['domain_limit'] > 0 ? $plan['domain_limit'] : 'Unlimited'); ?> | Landing pages: <?php echo e($plan['landing_pages_limit']); ?> | Payment links: <?php echo e($plan['payment_links_limit']); ?> | Whitelist domains: <?php echo e($plan['whitelist_domains_limit']); ?></div>
            <ul class="features">
                <?php if ($features): ?>
                    <?php foreach ($features as $feature): ?>
                        <li><span class="pill"></span><span><?php echo e(feature_label($feature)); ?></span></li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <li class="muted">No features defined.</li>
                <?php endif; ?>
            </ul>
            <?php if ($user): ?>
                <form method="post">
                    <input type="hidden" name="action" value="buy_plan">
                    <input type="hidden" name="plan_slug" value="<?php echo e($plan['slug']); ?>">
                    <select name="cycle" class="form-select form-select-sm mb-2">
                        <option value="monthly">Monthly</option>
                        <option value="yearly">Yearly</option>
                    </select>
                    <button type="submit" class="btn btn-primary w-100">Start now</button>
                </form>
            <?php else: ?>
                <a class="btn btn-primary w-100" href="register.php?plan=<?php echo urlencode($plan['slug']); ?>">Start now</a>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div>

</body>
</html>

