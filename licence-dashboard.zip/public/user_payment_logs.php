<?php
require_once __DIR__ . '/../config.php';
require_auth();
$user = current_user();
$export = isset($_GET['export']) && $_GET['export'] === 'csv';

$stmt = db()->prepare("SELECT * FROM payment_sync_logs WHERE user_id = ? AND feature <> 'link_view' ORDER BY recorded_at DESC");
$stmt->execute([$user['id']]);
$rows = $stmt->fetchAll();

if ($export) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=my_payments.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID','Amount','Feature','Txn','Payer VPA','Recorded']);
    foreach ($rows as $r) {
        fputcsv($out, [$r['id'], $r['amount'], $r['feature'], $r['txn_id'], $r['payer_vpa'], $r['recorded_at']]);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>My Payments</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>My payments</h4>
        <div class="d-flex gap-2">
            <a href="dashboard.php" class="btn btn-outline-secondary btn-sm">Back</a>
            <a href="?export=csv" class="btn btn-outline-primary btn-sm">Export CSV</a>
        </div>
    </div>
    <?php if (empty($rows)): ?>
        <p class="text-muted">No payments recorded yet.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-sm table-striped">
                <thead>
                    <tr>
                        <th>Order</th>
                        <th>Amount</th>
                        <th>Feature</th>
                        <th>Payer UPI</th>
                        <th>Txn ID</th>
                        <th>Recorded</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td><?php echo e($r['id']); ?></td>
                            <td><?php echo e($r['amount']); ?></td>
                            <td><?php echo e($r['feature']); ?></td>
                            <td><?php echo e($r['payer_vpa']); ?></td>
                            <td><?php echo e($r['txn_id']); ?></td>
                            <td><?php echo e($r['recorded_at']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
