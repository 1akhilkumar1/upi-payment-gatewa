<?php
require_once __DIR__ . '/../config.php';

require_auth();
$user = current_user();
$subscription = get_active_subscription_for_user($user['id']);

if (!$subscription) {
    set_flash('error', 'No active subscription found.');
    redirect('dashboard.php');
    exit;
}

$stmt = db()->prepare("SELECT * FROM payment_sync_logs WHERE user_id = ? AND feature = 'lead_capture' ORDER BY recorded_at DESC");
$stmt->execute([$user['id']]);
$leads = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Leads - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">eGo Customer Portal</a>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(licd_public_url('dashboard.php')); ?>" class="btn btn-outline-light btn-sm">Dashboard</a>
                    <a href="<?php echo e(licd_public_url('user_links.php')); ?>" class="btn btn-outline-light btn-sm">Links</a>
                    <a href="<?php echo e(licd_public_url('user_link_orders.php')); ?>" class="btn btn-outline-light btn-sm">Orders</a>
                    <a href="<?php echo e(licd_public_url('app_connect.php')); ?>" class="btn btn-outline-light btn-sm">App Connect</a>
                    <a href="<?php echo e(licd_public_url('user_domains.php')); ?>" class="btn btn-outline-light btn-sm">Domains</a>
                    <a href="<?php echo e(licd_public_url('profile.php')); ?>" class="btn btn-outline-light btn-sm">Profile</a>
                    <a href="<?php echo e(licd_public_url('logout.php')); ?>" class="btn btn-outline-light btn-sm">Logout</a>
                </div>
            </div>
        </nav>

        <div class="container-fluid py-2">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h4 class="mb-1">Leads</h4>
                    <p class="text-muted small mb-0">Newest leads appear first.</p>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-body">
                    <?php if (empty($leads)): ?>
                        <p class="text-muted mb-0">No leads submitted yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th>Submitted</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>Link</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($leads as $lead): ?>
                                        <?php
                                            $meta = $lead['metadata'] ? json_decode($lead['metadata'], true) : [];
                                            $leadData = is_array($meta) && isset($meta['lead']) && is_array($meta['lead']) ? $meta['lead'] : [];
                                            $linkSlug = $lead['product'] ?? '';
                                            $domain = $lead['domain'] ?? '';
                                            $linkUrl = '';
                                            if ($linkSlug !== '') {
                                                $base = rtrim($domain !== '' ? $domain : DEFAULT_HOSTED_DOMAIN, '/');
                                                $linkUrl = $base . '/link/' . urlencode($linkSlug);
                                            }
                                        ?>
                                        <tr>
                                            <td><?php echo e($lead['recorded_at']); ?></td>
                                            <td><?php echo e($leadData['name'] ?? ''); ?></td>
                                            <td><?php echo e($leadData['email'] ?? ''); ?></td>
                                            <td><?php echo e($leadData['phone'] ?? ''); ?></td>
                                            <td><?php echo e($leadData['address'] ?? ''); ?></td>
                                            <td>
                                                <?php if ($linkUrl): ?>
                                                    <a href="<?php echo e($linkUrl); ?>" target="_blank" rel="noopener">Open</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
