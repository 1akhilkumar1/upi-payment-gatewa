<?php
require_once __DIR__ . '/../config.php';

require_admin();

if (is_post() && isset($_POST['action']) && $_POST['action'] === 'clear_logs') {
    $path = function_exists('licd_log_file_path') ? licd_log_file_path() : '';
    if ($path) {
        @file_put_contents($path, '');
    }
    set_flash('success', 'Logs cleared.');
    redirect('admin_logs.php');
    exit;
}

$logs = function_exists('licd_read_logs') ? licd_read_logs(300) : [];
$flashes = pull_all_flash();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Logs - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark rounded-4 shadow-sm mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin_dashboard.php">eGo Admin</a>
                <div class="d-flex gap-2">
                    <a class="btn btn-outline-light btn-sm" href="admin_dashboard.php">Back</a>
                    <a class="btn btn-outline-light btn-sm" href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
        <div class="container-fluid py-2">
            <?php foreach ($flashes as $key => $message): ?>
                <div class="alert alert-<?php echo e($key === 'error' ? 'danger' : ($key === 'success' ? 'success' : 'info')); ?> alert-dismissible fade show" role="alert">
                    <?php echo e($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endforeach; ?>

            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>App & Payment Logs</strong>
                    <form method="post" class="mb-0">
                        <input type="hidden" name="action" value="clear_logs">
                        <button type="submit" class="btn btn-sm btn-outline-danger">Clear logs</button>
                    </form>
                </div>
                <div class="card-body p-0">
                    <?php if (empty($logs)): ?>
                        <div class="p-3 text-muted">No log entries yet.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-sm table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th style="width:160px;">Time (UTC)</th>
                                        <th style="width:160px;">Type</th>
                                        <th>Message</th>
                                        <th>Context</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($logs as $row): ?>
                                        <tr>
                                            <td><?php echo e($row['ts'] ?? ''); ?></td>
                                            <td><?php echo e($row['type'] ?? ''); ?></td>
                                            <td><?php echo e($row['message'] ?? ''); ?></td>
                                            <td><code class="small"><?php echo e(json_encode($row['context'] ?? [], JSON_UNESCAPED_SLASHES)); ?></code></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
