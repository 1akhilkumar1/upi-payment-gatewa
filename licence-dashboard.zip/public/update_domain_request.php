<?php
require_once __DIR__ . '/../config.php';

require_admin();

if (!is_post()) {
    redirect('admin_dashboard.php');
}

$domainId = (int)($_POST['domain_id'] ?? 0);
$action = $_POST['action'] ?? '';
$adminNote = trim($_POST['admin_note'] ?? '');

$allowed = ['approve' => 'approved', 'reject' => 'rejected', 'pending' => 'pending'];

if ($domainId > 0 && isset($allowed[$action])) {
    update_domain_request($domainId, $allowed[$action], $adminNote ?: null);
    set_flash('success', 'Request updated.');
} else {
    set_flash('error', 'Invalid request selection.');
}

redirect('admin_dashboard.php');
