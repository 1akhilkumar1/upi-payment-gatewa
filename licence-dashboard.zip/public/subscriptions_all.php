<?php
require_once __DIR__ . '/../config.php';
require_admin();
$export = isset($_GET['export']) && $_GET['export'] === 'csv';
$subs = list_subscriptions();

if ($export) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=subscriptions.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID','User','Plan','Status','License','Valid until']);
    foreach ($subs as $s) {
        fputcsv($out, [$s['id'], $s['email'], $s['plan_name'] . ' (' . $s['plan_slug'] . ')', $s['status'], $s['license_key'], $s['valid_until']]);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Subscriptions - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>All subscriptions</h3>
        <div class="d-flex gap-2">
            <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back</a>
            <a href="?export=csv" class="btn btn-outline-primary btn-sm">Export CSV</a>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>Plan</th>
                    <th>Status</th>
                    <th>License</th>
                    <th>Valid until</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($subs as $row): ?>
                    <tr>
                        <td><?php echo e($row['id']); ?></td>
                        <td><?php echo e($row['email']); ?></td>
                        <td><?php echo e($row['plan_name']); ?> (<?php echo e($row['plan_slug']); ?>)</td>
                        <td><span class="badge bg-<?php echo e($row['status'] === 'active' ? 'success' : 'warning'); ?>"><?php echo e($row['status']); ?></span></td>
                        <td><code><?php echo e($row['license_key']); ?></code></td>
                        <td><?php echo e($row['valid_until'] ?? ''); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
