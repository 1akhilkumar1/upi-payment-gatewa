<?php
require_once __DIR__ . '/../config.php';
require_admin();
$export = isset($_GET['export']) && $_GET['export'] === 'csv';
$stats = hosted_link_stats();

if ($export) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=hosted_links_usage.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Subscription','User','Link ID','Views','Payments','Revenue','Last paid']);
    foreach ($stats as $s) {
        fputcsv($out, [$s['subscription_id'], $s['user_email'], $s['slug'], $s['views'], $s['payments'], $s['revenue'], $s['last_paid']]);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Hosted link usage - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Hosted link usage</h3>
        <div class="d-flex gap-2">
            <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back</a>
            <a href="?export=csv" class="btn btn-outline-primary btn-sm">Export CSV</a>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-sm table-striped">
            <thead>
                <tr>
                    <th>Subscription</th>
                    <th>User</th>
                    <th>Link ID</th>
                    <th>Views</th>
                    <th>Payments</th>
                    <th>Revenue</th>
                    <th>Last paid</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($stats as $s): ?>
                    <tr>
                        <td><?php echo e($s['subscription_id']); ?></td>
                        <td><?php echo e($s['user_email']); ?></td>
                        <td><?php echo e($s['slug']); ?></td>
                        <td><?php echo e($s['views']); ?></td>
                        <td><?php echo e($s['payments']); ?></td>
                        <td><?php echo e(number_format((float)$s['revenue'], 2)); ?></td>
                        <td><?php echo e($s['last_paid']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
