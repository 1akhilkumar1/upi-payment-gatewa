<?php
require_once __DIR__ . '/../config.php';

$slug = isset($_GET['slug']) ? trim($_GET['slug']) : '';
if ($slug === '') {
    http_response_code(404);
    echo "Link not found";
    exit;
}

$stmt = db()->prepare("SELECT * FROM hosted_links WHERE slug = ? LIMIT 1");
$stmt->execute([$slug]);
$link = $stmt->fetch();
if (!$link) {
    http_response_code(404);
    echo "Link not found";
    exit;
}

$payload = [];
if (!empty($link['payload'])) {
    $decoded = json_decode($link['payload'], true);
    $payload = is_array($decoded) ? $decoded : [];
}
$subscription = get_subscription_by_id($link['subscription_id']);
$captureFields = $payload['capture_fields'] ?? [];
$collectPayment = !empty($payload['collect_payment']);
$regularPrice = (float)($payload['regular_price'] ?? 0);
$salePrice = (float)($payload['sale_price'] ?? 0);
$linkType = $payload['link_type'] ?? '';
if ($linkType === '') {
    $fallbackAmount = isset($payload['payment_amount']) ? (float)$payload['payment_amount'] : 0.0;
    if ($fallbackAmount > 0 && $regularPrice <= 0 && $salePrice <= 0) {
        $linkType = 'payment_link';
    } else {
        $linkType = $collectPayment ? 'payment_page' : 'landing_page';
    }
}
if (!in_array($linkType, ['landing_page', 'payment_page', 'payment_link'], true)) {
    $linkType = $collectPayment ? 'payment_page' : 'landing_page';
}
$collectPayment = in_array($linkType, ['payment_page', 'payment_link'], true);
$heroImage = $payload['hero_image_url'] ?? ($link['image_url'] ?? '');
$digitalFile = $payload['digital_file_url'] ?? '';
$ctaText = trim((string)($payload['cta_text'] ?? ''));
if ($ctaText === '') {
    if ($linkType === 'landing_page') {
        $ctaText = 'Learn more';
    } elseif ($linkType === 'payment_link') {
        $ctaText = 'Pay now';
    } else {
        $ctaText = 'Proceed to payment';
    }
}
$primaryUrl = trim((string)($payload['primary_url'] ?? ''));
$secondaryText = trim((string)($payload['secondary_text'] ?? ''));
if ($secondaryText === '') {
    $secondaryText = 'Submit details';
}
$payAmount = 0;
if ($linkType === 'payment_page') {
    $payAmount = ($salePrice > 0 ? $salePrice : ($regularPrice > 0 ? $regularPrice : (float)$link['amount']));
} elseif ($linkType === 'payment_link') {
    $payAmount = (float)($payload['payment_amount'] ?? ($link['amount'] ?? 0));
}
if ($linkType === 'payment_page') {
    $fallbackPay = (float)($payload['payment_amount'] ?? 0);
    if ($fallbackPay > 0 && $regularPrice <= 0 && $salePrice <= 0) {
        $linkType = 'payment_link';
        $collectPayment = true;
        $payAmount = $fallbackPay;
    }
}
$captureLeads = ($linkType === 'landing_page' && !empty($captureFields));
if ($collectPayment && empty($captureFields)) {
    $captureFields = ['name', 'email', 'phone', 'address'];
}
if ($linkType === 'payment_link') {
    $captureFields = [];
}
$title = e($link['title']);
$descRaw = (string)($link['description'] ?? '');
$descHtml = $descRaw !== '' ? (function_exists('wpautop') ? wpautop(esc_html($descRaw)) : nl2br(e($descRaw))) : '';
$purpose = e($link['purpose'] ?? '');
$domain = $link['domain'] ?: '';
$currentHost = isset($_SERVER['HTTP_HOST']) ? strtolower(preg_replace('/:\\d+$/', '', $_SERVER['HTTP_HOST'])) : '';
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$baseHost = $domain ?: ($currentHost ? $scheme . $currentHost : DEFAULT_HOSTED_DOMAIN);
$domain = $baseHost;
$approvedHost = null;
if ($subscription) {
    $domains = get_domains_for_subscription($subscription['id']);
    foreach ($domains as $d) {
        if (($d['status'] ?? '') === 'approved') {
            $hostOnly = strtolower(preg_replace('/^https?:\\/\\//', '', $d['domain']));
            $hostOnly = preg_replace('/:\\d+$/', '', $hostOnly);
            if ($currentHost && $currentHost === $hostOnly) {
                $approvedHost = $currentHost;
                break;
            }
        }
    }
}
if ($approvedHost) {
    $domain = (stripos($domain, 'http') === 0 ? '' : 'https://') . $approvedHost;
}
if (stripos($domain, 'http') !== 0) {
    $domain = 'https://' . $domain;
}
$discountPct = 0;
if ($linkType === 'payment_page' && $regularPrice > 0 && $salePrice > 0 && $salePrice < $regularPrice) {
    $discountPct = round((($regularPrice - $salePrice) / $regularPrice) * 100);
}
$subscription = $link['subscription_id'] ? get_subscription_by_id($link['subscription_id']) : null;
$isPaid = !empty($payload['paid']);
$checkoutUrl = rtrim(defined('LICD_PLUGIN_URL') ? LICD_PLUGIN_URL : (BASE_URL . '/wp-content/plugins/licence-dashboard/'), '/');
$checkoutUrl .= '/public/link_checkout.php?slug=' . urlencode($slug);

$leadSaved = false;
$leadError = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'lead') {
    if ($linkType !== 'landing_page' || !$captureLeads) {
        $leadError = 'Lead capture is not enabled for this link.';
    }
    $lead = [
        'name' => trim($_POST['name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'address' => trim($_POST['address'] ?? ''),
    ];
    if (empty($leadError) && !array_filter($lead)) {
        $leadError = 'Please fill at least one field before submitting.';
    } elseif (empty($leadError)) {
        if ($subscription) {
            record_payment_sync(
                $subscription['id'],
                $subscription['user_id'],
                $subscription['license_key'],
                'link',
                'lead_capture',
                0,
                uniqid('lead_', true),
                null,
                ['lead' => $lead],
                $lead,
                $domain,
                $slug
            );
        }
        $leadSaved = true;
    }
}

if ($leadSaved && $linkType === 'landing_page' && $primaryUrl !== '') {
    header('Location: ' . $primaryUrl);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'checkout' && $collectPayment) {
    $lead = [
        'name' => trim($_POST['name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'address' => trim($_POST['address'] ?? ''),
    ];
    if (!$subscription) {
        $leadError = 'Payment cannot be started right now.';
    } else {
        $ownerProfile = get_user_profile($subscription['user_id']) ?: [];
        $merchantUpi = trim((string)($ownerProfile['upi_id'] ?? ''));
        $merchantName = trim((string)($ownerProfile['upi_name'] ?? ''));
        if ($merchantUpi === '' || $merchantName === '') {
            $leadError = 'Merchant UPI details are missing. Please ask the seller to update their UPI name and ID.';
        }
    }
    if (empty($leadError) && $subscription) {
        $meta = [
            'link_title' => $link['title'] ?? '',
            'product' => $slug,
            'link_slug' => $slug,
            'customer_name' => $lead['name'],
            'customer_email' => $lead['email'],
            'customer_phone' => $lead['phone'],
            'customer_address' => $lead['address'],
            'capture_fields' => $captureFields,
            'merchant_name' => $merchantName,
            'merchant_upi' => $merchantUpi,
        ];
        $note = $link['title'] ?? 'Payment link';
        $payment = create_payment_request(
            $subscription,
            'link',
            $payAmount,
            'one_time',
            $subscription['plan_slug'] ?? null,
            $meta,
            null,
            $note
        );
        if (!empty($payment['id'])) {
            $token = generate_public_checkout_token($payment['id'], $subscription['user_id']);
            $url = 'checkout.php?id=' . urlencode($payment['id']) . '&public=1&token=' . urlencode($token);
            header('Location: ' . $url);
            exit;
        }
        $leadError = 'Could not start checkout. Please try again.';
    }
}

// If not marked paid yet, check logs for any completed payment on this product slug.
if (!$isPaid && $subscription) {
    $st = db()->prepare("SELECT COUNT(*) FROM payment_sync_logs WHERE subscription_id = ? AND product = ? AND feature <> 'link_view' AND amount > 0");
    $st->execute([$subscription['id'], $slug]);
    if ((int)$st->fetchColumn() > 0) {
        $isPaid = true;
        mark_hosted_link_paid($subscription['id'], $slug, $payAmount, null, null);
    }
}

$deeplink = (!$isPaid && $collectPayment && $payAmount > 0) ? generate_payment_deeplink($payAmount, $title ?: 'Payment', $purpose ?: $title) : '';
$amountFormatted = $payAmount > 0 ? number_format((float)$payAmount, 2, '.', '') : '0.00';

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo $title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: 'Inter', Arial, sans-serif; background: radial-gradient(circle at 20% 20%, #0b1220, #0a0f1a); margin:0; color:#e5e7eb; }
        .shell { max-width: 1080px; margin:24px auto; padding:12px; }
        .grid { display:grid; grid-template-columns: 1fr; gap:16px; }
        @media (min-width: 900px) { .grid { grid-template-columns: 1fr 0.8fr; } }
        .card { background: rgba(15,23,42,0.9); border:1px solid #111827; border-radius:16px; padding:18px; box-shadow: 0 16px 60px rgba(0,0,0,0.35); }
        .price-row { display:flex; align-items:center; gap:10px; margin-top:12px; flex-wrap:wrap; }
        .price-main { font-size:28px; font-weight:800; color:#22c55e; }
        .price-strike { text-decoration:line-through; color:#94a3b8; }
        .badge { display:inline-flex; align-items:center; gap:4px; background:#0f5132; color:#c7f9cc; padding:6px 10px; border-radius:999px; font-size:12px; }
        .btn { display:inline-flex; align-items:center; justify-content:center; gap:6px; padding:12px 14px; border-radius:10px; border:0; font-weight:700; cursor:pointer; text-decoration:none; }
        .btn-primary { background:#2563eb; color:#fff; box-shadow:0 10px 40px rgba(37,99,235,0.35); }
        .btn-secondary { background:#111827; color:#cbd5e1; border:1px solid #1f2937; }
        .hero { width:100%; border-radius:14px; object-fit:cover; max-height:320px; }
        .muted { color:#94a3b8; font-size:14px; }
        .field { display:flex; flex-direction:column; margin-bottom:10px; }
        .field label { font-size:13px; color:#cbd5e1; margin-bottom:6px; }
        .field input, .field textarea { background:#0b1220; border:1px solid #1f2937; border-radius:10px; padding:10px 12px; color:#e5e7eb; }
        .pill { display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border-radius:999px; background:#111827; border:1px solid #1f2937; color:#cbd5e1; font-size:12px; }
        .divider { height:1px; background:#1f2937; margin:14px 0; }
        .lead-result { padding:10px 12px; border-radius:10px; background:#0f5132; color:#dcfce7; border:1px solid #16a34a; }
        .d-none { display:none; }
        .landing-layout { width: 90vw; margin: 24px auto; padding: 0 5vw; max-width: 1400px; }
        @media (max-width: 900px) { .landing-layout { width: 100%; padding: 0 12px; } }
        .lead-modal { position: fixed; inset: 0; background: rgba(2,6,23,0.7); display: flex; align-items: center; justify-content: center; padding: 16px; z-index: 1000; }
        .lead-modal.d-none { display: none; }
        .lead-modal .card { width: min(520px, 100%); }
        .link-compact { max-width: 520px; margin: 0 auto; text-align: center; }
    </style>
</head>
<body>
    <div class="shell <?php echo $linkType === 'landing_page' ? 'landing-layout' : ''; ?>">
        <div class="grid" id="page-grid">
            <div class="card<?php echo $linkType === 'payment_link' ? ' link-compact' : ''; ?>">
                <?php if ($heroImage && $linkType !== 'payment_link'): ?>
                    <img src="<?php echo e($heroImage); ?>" alt="" class="hero">
                <?php endif; ?>
                <h1 style="margin:12px 0 6px;font-size:26px;"><?php echo $title; ?></h1>
                <?php if ($descHtml && $linkType !== 'payment_link'): ?><div class="muted" style="margin:0 0 8px;"><?php echo $descHtml; ?></div><?php endif; ?>
                <?php if ($linkType !== 'landing_page'): ?>
                    <div class="price-row">
                        <?php if ($linkType === 'payment_page' && $regularPrice > 0): ?>
                            <span class="<?php echo $discountPct > 0 ? 'price-strike' : 'price-main'; ?>"><?php echo 'INR ' . number_format($regularPrice, 2); ?></span>
                        <?php endif; ?>
                        <?php if ($collectPayment): ?>
                            <span class="price-main"><?php echo 'INR ' . $amountFormatted; ?></span>
                            <?php if ($linkType === 'payment_page' && $discountPct > 0): ?><span class="badge">-<?php echo $discountPct; ?>%</span><?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <?php if ($purpose && $linkType === 'landing_page'): ?><div class="pill" style="margin-top:8px;"><?php echo $purpose; ?></div><?php endif; ?>
                <?php if ($linkType === 'landing_page'): ?>
                    <div class="divider"></div>
                    <?php if ($captureLeads): ?>
                        <button class="btn btn-primary" type="button" id="open-lead-form"><?php echo e($ctaText); ?></button>
                    <?php elseif ($primaryUrl): ?>
                        <a class="btn btn-primary" href="<?php echo e($primaryUrl); ?>" target="_blank" rel="noopener"><?php echo e($ctaText); ?></a>
                    <?php endif; ?>
                <?php elseif ($linkType === 'payment_link'): ?>
                    <div class="divider"></div>
                    <a class="btn btn-primary" href="<?php echo e($checkoutUrl); ?>"><?php echo e($ctaText); ?></a>
                <?php elseif ($linkType === 'payment_page'): ?>
                    <div class="divider"></div>
                    <a class="btn btn-primary" href="<?php echo e($checkoutUrl); ?>"><?php echo e($ctaText); ?></a>
                <?php elseif ($collectPayment): ?>
                    <div class="divider"></div>
                <?php endif; ?>
                <?php if ($isPaid): ?>
                    <div class="divider"></div>
                    <span class="badge">Paid</span>
                <?php endif; ?>
                <?php if ($digitalFile): ?>
                    <div class="divider"></div>
                    <?php if ($isPaid): ?>
                        <a class="btn btn-secondary" href="<?php echo e($digitalFile); ?>" target="_blank" rel="noopener">Download</a>
                    <?php else: ?>
                        <button class="btn btn-secondary" type="button" disabled>Download available after payment</button>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <?php
            $showForm = ($collectPayment || $captureLeads);
            $hideLeadForm = ($linkType === 'landing_page' && $captureLeads && !$leadSaved && !$leadError);
            $showLeadCard = ($linkType !== 'landing_page' && $linkType !== 'payment_link' && $linkType !== 'payment_page') || $captureLeads || $leadSaved || $leadError;
            $openLeadModal = ($linkType === 'landing_page' && $captureLeads && ($leadSaved || $leadError));
            ?>
            <?php if ($showLeadCard && $linkType !== 'landing_page' && $linkType !== 'payment_link' && $linkType !== 'payment_page' && $showForm): ?>
            <div class="card" id="lead-card">
                <h4 style="margin:0 0 10px;"><?php echo $collectPayment ? 'Enter your details' : 'Share your details'; ?></h4>
                <?php if ($linkType === 'landing_page' && $captureLeads): ?>
                    <p class="muted" style="margin-top:-4px;">We will send you to the destination after you submit.</p>
                <?php endif; ?>
                <?php if ($leadSaved): ?>
                    <div class="lead-result">Details received. We will process your request.</div>
                <?php elseif ($leadError): ?>
                    <div class="alert alert-danger" role="alert" style="background:#7f1d1d;color:#fecdd3;border:1px solid #ef4444;padding:10px;border-radius:10px;"><?php echo e($leadError); ?></div>
                <?php endif; ?>
                <?php if ($showForm && $linkType !== 'payment_link'): ?>
                    <form method="post" style="margin-top:10px;" id="lead-form-wrap" class="<?php echo $hideLeadForm ? 'd-none' : ''; ?>">
                        <input type="hidden" name="action" value="<?php echo $collectPayment ? 'checkout' : 'lead'; ?>">
                        <?php foreach ($captureFields as $field): ?>
                            <?php if ($field === 'name'): ?>
                                <div class="field">
                                    <label>Name</label>
                                    <input type="text" name="name" placeholder="Your full name">
                                </div>
                            <?php elseif ($field === 'email'): ?>
                                <div class="field">
                                    <label>Email</label>
                                    <input type="email" name="email" placeholder="name@example.com">
                                </div>
                            <?php elseif ($field === 'phone'): ?>
                                <div class="field">
                                    <label>Phone</label>
                                    <input type="text" name="phone" placeholder="10-digit mobile number">
                                </div>
                            <?php elseif ($field === 'address'): ?>
                                <div class="field">
                                    <label>Address</label>
                                    <textarea name="address" rows="2" placeholder="Address"></textarea>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <button class="btn btn-primary w-100" type="submit"><?php echo e($collectPayment ? $ctaText : $secondaryText); ?></button>
                    </form>
                <?php else: ?>
                    <p class="muted">No form fields configured.</p>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php if ($linkType === 'landing_page' && $showLeadCard): ?>
    <div class="lead-modal<?php echo $openLeadModal ? '' : ' d-none'; ?>" id="lead-modal">
        <div class="card">
            <h4 style="margin:0 0 10px;">Share your details</h4>
            <p class="muted" style="margin-top:-4px;">We will send you to the destination after you submit.</p>
            <?php if ($leadSaved): ?>
                <div class="lead-result">Details received. We will process your request.</div>
            <?php elseif ($leadError): ?>
                <div class="alert alert-danger" role="alert" style="background:#7f1d1d;color:#fecdd3;border:1px solid #ef4444;padding:10px;border-radius:10px;"><?php echo e($leadError); ?></div>
            <?php endif; ?>
            <?php if ($showForm): ?>
                <form method="post" style="margin-top:10px;">
                    <input type="hidden" name="action" value="lead">
                    <?php foreach ($captureFields as $field): ?>
                        <?php if ($field === 'name'): ?>
                            <div class="field">
                                <label>Name</label>
                                <input type="text" name="name" placeholder="Your full name">
                            </div>
                        <?php elseif ($field === 'email'): ?>
                            <div class="field">
                                <label>Email</label>
                                <input type="email" name="email" placeholder="name@example.com">
                            </div>
                        <?php elseif ($field === 'phone'): ?>
                            <div class="field">
                                <label>Phone</label>
                                <input type="text" name="phone" placeholder="10-digit mobile number">
                            </div>
                        <?php elseif ($field === 'address'): ?>
                            <div class="field">
                                <label>Address</label>
                                <textarea name="address" rows="2" placeholder="Address"></textarea>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <button class="btn btn-primary w-100" type="submit"><?php echo e($secondaryText); ?></button>
                </form>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    <script>
    (function(){
      try {
        fetch('/api/link_event.php', {
          method: 'POST',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify({ link_id: '<?php echo e($slug); ?>' })
        });
      } catch(e){}

      <?php if ($linkType === 'landing_page' && $captureLeads): ?>
      const openBtn = document.getElementById('open-lead-form');
      const leadModal = document.getElementById('lead-modal');
      if (openBtn && leadModal) {
        openBtn.addEventListener('click', () => {
          leadModal.classList.remove('d-none');
        });
      }
      <?php endif; ?>
    })();
    </script>
</body>
</html>

