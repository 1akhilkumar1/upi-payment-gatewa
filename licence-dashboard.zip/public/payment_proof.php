<?php
require_once __DIR__ . '/../config.php';

require_auth();
$user = current_user();

if (!is_post()) {
    redirect('dashboard.php');
}

$paymentId = (int)($_POST['payment_id'] ?? 0);
$payerName = trim($_POST['payer_name'] ?? '');
$payerUpi  = trim($_POST['payer_upi'] ?? '');
$txnId     = trim($_POST['txn_id'] ?? '');

if ($paymentId <= 0 || $payerName === '' || $payerUpi === '' || $txnId === '') {
    set_flash('error', 'All fields are required.');
    redirect('dashboard.php');
}

$proofPath = null;
if (!empty($_FILES['screenshot']['name'])) {
    $uploadsDir = __DIR__ . '/../logs/payment_proofs';
    if (!is_dir($uploadsDir)) {
        @mkdir($uploadsDir, 0755, true);
    }
    $ext = pathinfo($_FILES['screenshot']['name'], PATHINFO_EXTENSION);
    $filename = 'proof_' . $paymentId . '_' . time() . '.' . $ext;
    $dest = $uploadsDir . '/' . $filename;
    if (move_uploaded_file($_FILES['screenshot']['tmp_name'], $dest)) {
        $proofPath = rtrim(defined('LICD_PLUGIN_URL') ? LICD_PLUGIN_URL : (BASE_URL . '/wp-content/plugins/licence-dashboard/'), '/');
        $proofPath .= '/logs/payment_proofs/' . $filename;
    }
}

$stmt = db()->prepare("SELECT pr.*, COALESCE(s.user_id, pr.user_id) AS user_id FROM payment_requests pr LEFT JOIN subscriptions s ON s.id = pr.subscription_id WHERE pr.id = ? LIMIT 1");
$stmt->execute([$paymentId]);
$req = $stmt->fetch();
if (!$req || $req['user_id'] != $user['id']) {
    set_flash('error', 'Payment request not found.');
    redirect('dashboard.php');
}

mark_payment_request($paymentId, 'submitted', $txnId, [
    'payer_name' => $payerName,
    'payer_upi'  => $payerUpi,
    'txn_id'     => $txnId,
    'screenshot' => $proofPath,
]);
if (function_exists('licd_log_event')) {
    licd_log_event('payment_proof', 'Payment proof submitted', [
        'payment_id' => $paymentId,
        'user_id' => $user['id'],
        'amount' => $req['amount'] ?? null,
        'txn' => $txnId ? substr($txnId, 0, 6) . '...' : '',
    ]);
}

set_flash('success', 'Payment details submitted. Awaiting confirmation.');
redirect('dashboard.php');
