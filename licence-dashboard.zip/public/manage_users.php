<?php
require_once __DIR__ . '/../config.php';
require_admin();

// Handle status / role updates
if (is_post()) {
    $userId = (int)($_POST['user_id'] ?? 0);
    if (isset($_POST['make_admin'])) {
        $stmt = db()->prepare("UPDATE users SET role = 'admin' WHERE id = ?");
        $stmt->execute([$userId]);
    } elseif (isset($_POST['make_customer'])) {
        $stmt = db()->prepare("UPDATE users SET role = 'customer' WHERE id = ?");
        $stmt->execute([$userId]);
    } elseif (isset($_POST['deactivate'])) {
        $stmt = db()->prepare("UPDATE users SET status = 'inactive' WHERE id = ?");
        $stmt->execute([$userId]);
    } elseif (isset($_POST['activate'])) {
        $stmt = db()->prepare("UPDATE users SET status = 'active' WHERE id = ?");
        $stmt->execute([$userId]);
    } elseif (isset($_POST['delete_user'])) {
        $stmt = db()->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        set_flash('success', 'User deleted.');
        redirect('manage_users.php');
        exit;
    }
}

$users = db()->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Users - eGo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/theme.css">
</head>
<body>
<div class="page-shell">
    <div class="dashboard-shell">
        <div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>User Management</h3>
        <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">Back to Dashboard</a>
    </div>
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
<?php foreach ($users as $u): ?>
                            <tr>
                                <td><?php echo e($u['id']); ?></td>
                                <td><?php echo e($u['name']); ?></td>
                                <td><?php echo e($u['email']); ?></td>
                                <td><?php echo e($u['role']); ?></td>
                                <td><?php echo e($u['status']); ?></td>
                                <td><?php echo e($u['created_at']); ?></td>
                                <td>
                                    <div class="d-flex flex-wrap gap-1">
                                        <a href="admin_user_edit.php?id=<?php echo e($u['id']); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                                        <a href="act_as_user.php?id=<?php echo e($u['id']); ?>" class="btn btn-sm btn-outline-info">Login as</a>
                                    <form method="post" class="d-flex gap-1 flex-wrap">
                                        <input type="hidden" name="user_id" value="<?php echo e($u['id']); ?>">
                                        <?php if ($u['role'] !== 'admin'): ?>
                                            <button name="make_admin" class="btn btn-sm btn-outline-primary">Make admin</button>
                                        <?php else: ?>
                                            <button name="make_customer" class="btn btn-sm btn-outline-secondary">Make customer</button>
                                        <?php endif; ?>
                                        <?php if ($u['status'] === 'active'): ?>
                                            <button name="deactivate" class="btn btn-sm btn-outline-danger">Deactivate</button>
                                        <?php else: ?>
                                            <button name="activate" class="btn btn-sm btn-outline-success">Activate</button>
                                        <?php endif; ?>
                                        <button name="delete_user" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this user?')">Delete</button>
                                    </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
</div>

</body>
</html>
