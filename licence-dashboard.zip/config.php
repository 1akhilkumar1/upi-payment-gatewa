<?php
// eGo Control Panel config (WordPress-aware)

// Try to bootstrap WordPress when accessed directly (iframe access to public/*.php).
if (!defined('ABSPATH')) {
    $maybe_wp = dirname(__DIR__, 3) . '/wp-load.php'; // wp-content/plugins/<plugin>/ => up 3 levels
    if (file_exists($maybe_wp)) {
        require_once $maybe_wp;
    }
}

// Derive plugin URL when running inside WordPress.
if (!defined('LICD_PLUGIN_URL') && function_exists('plugins_url')) {
    define('LICD_PLUGIN_URL', trailingslashit(plugins_url('', __FILE__)));
}

// Prefer WordPress DB constants if available so we share the WP database.
if (class_exists('wpdb')) {
    global $wpdb;
    if (!defined('DB_HOST') && !empty($wpdb->dbhost)) { define('DB_HOST', $wpdb->dbhost); }
    if (!defined('DB_NAME') && !empty($wpdb->dbname)) { define('DB_NAME', $wpdb->dbname); }
    if (!defined('DB_USER') && !empty($wpdb->dbuser)) { define('DB_USER', $wpdb->dbuser); }
    if (!defined('DB_PASSWORD') && !empty($wpdb->dbpassword)) { define('DB_PASSWORD', $wpdb->dbpassword); }
}

// Fallbacks if not running inside WP (for CLI/testing)
if (!defined('DB_HOST')) { define('DB_HOST', '127.0.0.1'); }
if (!defined('DB_NAME')) { define('DB_NAME', 'licd'); }
if (!defined('DB_USER')) { define('DB_USER', 'root'); }
if (!defined('DB_PASS')) {
    if (defined('DB_PASSWORD')) { define('DB_PASS', DB_PASSWORD); }
    else { define('DB_PASS', ''); }
}

// Base URL (no trailing slash) - prefer WordPress site URL.
if (!defined('BASE_URL')) {
    if (function_exists('site_url')) {
        define('BASE_URL', rtrim(site_url(), '/'));
    } else {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
        $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
        define('BASE_URL', $scheme . $host);
    }
}

// Default hosted links domain
if (!defined('DEFAULT_HOSTED_DOMAIN')) {
    define('DEFAULT_HOSTED_DOMAIN', BASE_URL);
}

// Dev token for app keyset refresh (can override in wp-config.php).
if (!defined('LICD_DEV_KEY_TOKEN')) {
    define('LICD_DEV_KEY_TOKEN', 'licd-dev');
}

if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
    session_start();
}

date_default_timezone_set('UTC');

require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/helpers.php';
require_once __DIR__ . '/lib/settings.php';
require_once __DIR__ . '/lib/subscription.php';
require_once __DIR__ . '/lib/payments.php';
require_once __DIR__ . '/lib/profile.php';
require_once __DIR__ . '/lib/auth.php';
